"""Aggregate eval_results.json into named systems (mean/std over seeds) -> results/summary.json,
and add paired-bootstrap confidence intervals for the main comparisons using saved probabilities."""
import json, re, glob
import numpy as np

R = json.load(open("results/eval_results.json"))
SETS = R["sets"]; M = R["models"]
CORR = [s for s in SETS if s != "clean"]

SYSTEMS = {  # display name -> list of model keys (seeds)
    "RF (clean, 24 feats)": ["RandomForest"],
    "SVM (clean, 24 feats)": ["SVM_RBF"],
    "RF (clean, 18 robust feats)": ["RandomForest_robustfeats"],
    "RF (aug, 24 feats)": ["RandomForest_aug"],
    "RF (aug, 18 robust feats)": ["RandomForest_aug_robustfeats"],
    "SVM (aug, 18 robust feats)": ["SVM_RBF_aug_robustfeats"],
    "PointNet (clean, rot-aug)": ["rot_s0|plain"],
    "PCA-PointNet (clean) TTA": ["pca_s0|tta"],
    "PCA-PointNet (clean) single pose": ["pca_s0|single"],
    "CF-PointNet (clean, 24 feats) TTA": ["cf_s0|tta"],
    "PointNet (aug)": ["rot_aug_s0|plain", "rot_aug_s1|plain"],
    "PCA-PointNet (aug) TTA": ["pca_aug_s0|tta", "pca_aug_s1|tta"],
    "PCA-PointNet (aug) single pose": ["pca_aug_s0|single", "pca_aug_s1|single"],
    "CF-PointNet-A (aug, 24 feats) TTA": ["cfa_aug_s0|tta", "cfa_aug_s1|tta"],
    "CF-PointNet-A (aug, 24 feats) single pose": ["cfa_aug_s0|single", "cfa_aug_s1|single"],
    "CF-PointNet-A no sign-aug, TTA": ["cfa_nosign_s0|tta"],
    "CF-PointNet-A no sign-aug, single": ["cfa_nosign_s0|single"],
    "CF-PointNet-A (aug w/o zblur) TTA": ["cfa_aug_nozblur_s0|tta"],
    "CF-PointNet-R (aug, 18 feats) TTA": ["cfr_aug_s0|tta"],
    "CF-PointNet-R (aug, 18 feats) single pose": ["cfr_aug_s0|single"],
    "CF-PointNet-R (aug w/o zblur) TTA": ["cfr_aug_nozblur_s0|tta"],
}

out = {"sets": SETS, "systems": {}}
for name, keys in SYSTEMS.items():
    keys = [k for k in keys if k in M]
    if not keys:
        continue
    A = np.array([[M[k]["runs"]["seed0"][s]["acc"] for s in SETS] for k in keys]) * 100
    F = np.array([[M[k]["runs"]["seed0"][s]["f1"] for s in SETS] for k in keys]) * 100
    mean = A.mean(0); sd = A.std(0, ddof=1) if len(keys) > 1 else np.zeros(len(SETS))
    ci = CORR  # mean corrupted accuracy over the 10 corrupted sets
    mca = A[:, 1:].mean(1)
    out["systems"][name] = dict(n_seeds=len(keys), keys=keys, acc=dict(zip(SETS, mean.round(2))), acc_sd=dict(zip(SETS, sd.round(2))),
                                f1=dict(zip(SETS, F.mean(0).round(2))), clean=float(mean[0].round(2)), clean_sd=float(sd[0].round(2)),
                                mca=float(mca.mean().round(2)), mca_sd=float(mca.std(ddof=1).round(2)) if len(keys) > 1 else 0.0,
                                worst=float(mean[1:].min().round(2)),
                                mild=float(np.mean([mean[SETS.index(s)] for s in CORR if s.endswith("1")]).round(2)),
                                strong=float(np.mean([mean[SETS.index(s)] for s in CORR if s.endswith("2")]).round(2)))

# conformal summary (alpha = 0.1): use seed 0 of the main model and the PointNet baselines
conf = R.get("conformal", {})
out["conformal"] = {k: v for k, v in conf.items()}

# paired bootstrap CI for accuracy difference main vs baselines on each of clean / mean-corrupted
def correct(key, s):
    if "|" in key:
        nm, v = key.split("|"); return (np.load(f"results/probs_{nm}_{v}.npz")[s].argmax(1) == y)
    return (np.load(f"results/preds_{key}.npz")[s] == y)

y = np.load("data_large/testing data/test.npz")["labels"]
def boot(a_key, b_key, n=1000, seed=0):
    try:
        res = {}; rng = np.random.default_rng(seed); idx = rng.integers(0, len(y), (n, len(y)))
        for grp, sets in [("clean", ["clean"]), ("corrupted_mean", CORR)]:
            ca = np.mean([correct(a_key, s) for s in sets], 0); cb = np.mean([correct(b_key, s) for s in sets], 0)
            d = (ca - cb)[idx].mean(1) * 100
            res[grp] = dict(diff=float(((ca - cb).mean() * 100).round(2)), lo=float(np.percentile(d, 2.5).round(2)), hi=float(np.percentile(d, 97.5).round(2)))
        return res
    except FileNotFoundError:
        return None
out["bootstrap"] = {}
for a, b in [("cfa_aug_s0|tta", "RandomForest_aug"), ("cfa_aug_s0|tta", "rot_aug_s0|plain"), ("cfa_aug_s0|tta", "pca_aug_s0|tta"),
             ("cfa_aug_s0|tta", "cfr_aug_s0|tta"), ("cfa_aug_s0|tta", "cfa_aug_s0|single"), ("cfa_aug_s0|tta", "cfa_nosign_s0|tta"),
             ("pca_aug_s0|tta", "pca_aug_s0|single"), ("RandomForest_aug", "RandomForest"), ("cfa_aug_s0|tta", "cf_s0|tta")]:
    r = boot(a, b)
    if r: out["bootstrap"][f"{a} - {b}"] = r
def san(o):
    if isinstance(o, dict): return {k: san(v) for k, v in o.items()}
    if isinstance(o, list): return [san(v) for v in o]
    if isinstance(o, float) and o != o: return None
    return o
json.dump(san(out), open("results/summary.json", "w"), indent=1)
for n, s in out["systems"].items():
    print(f"{n:44s} clean {s['clean']:6.2f}  mean-corrupt {s['mca']:6.2f}  mild {s['mild']:6.2f} strong {s['strong']:6.2f} worst {s['worst']:6.2f} (n={s['n_seeds']})")
