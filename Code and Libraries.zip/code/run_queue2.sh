#!/bin/bash
# Resumable training queue (skips finished runs). 20 epochs, 256 points, batch 64.
cd /home/claude/project55
E=20
[ -f results/val_bank.npz ] || python3 build_train_bank.py
[ -f results/val_bank_no_zblur.npz ] || python3 build_train_bank.py zblur
run() { name=$1; shift; [ -f results/models/$name.json ] || python3 cfpn.py --name $name --epochs $E "$@"; }
run pca_s0        --mode pca --fused 0 --seed 0
run cfr_aug_s0    --mode pca --fused 1 --feats robust --aug 1 --seed 0
run pca_aug_s0    --mode pca --fused 0 --aug 1 --seed 0
run rot_aug_s0    --mode rot --fused 0 --aug 1 --seed 0
run cfa_aug_s0    --mode pca --fused 1 --feats all --aug 1 --seed 0
run rot_s0        --mode rot --fused 0 --seed 0
run cfr_aug_nozblur_s0 --mode pca --fused 1 --feats robust --aug 1 --holdout zblur --seed 0
run cfr_nosign_s0 --mode pca --fused 1 --feats robust --aug 1 --nosignaug 1 --seed 0
run cfr_aug_s1    --mode pca --fused 1 --feats robust --aug 1 --seed 1
run pca_aug_s1    --mode pca --fused 0 --aug 1 --seed 1
run rot_aug_s1    --mode rot --fused 0 --aug 1 --seed 1
echo ALLDONE
