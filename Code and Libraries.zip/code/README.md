# Project 55 (extended): code, data and run order
Setup: Python 3, numpy, scipy, scikit-learn, matplotlib; node + pptxgenjs/docx for the deck and article. No GitHub code was used.
Run order (2 CPU cores, about 1 day of training in total):
1. `python3 generate_large.py`  -> data_large/training data/ (train, val, cal) and data_large/testing data/ (test)
2. `python3 features_large.py`, `python3 build_corrupt_sets.py`, `python3 build_train_bank.py`
3. `./run_queue2.sh`, `./run_queue3.sh` (train all neural models; resumable)
4. `python3 evaluate_all.py`, `python3 summarize.py`, `python3 make_figs_static.py`, `python3 make_figs_results.py`
5. `node build_deck2.js`, `node build_article2.js`
Before submitting: fill in name and enrolment number everywhere, write the declaration (section 5.4), verify every reference, record the VideoPPT (run code live), build the Drive zip (code, "training data", "testing data", pptx, video, article, declaration) and share it only with the instructor. Deadline: before 31 October 00:00 IST.

## Data folders
- `data_large/training data/` (train.npz 28,000, val.npz 4,000, cal.npz 4,000 particles) and `data_large/testing data/` (test.npz 4,000 particles): the FULL data. Supplied as split archive `Project55_full_data.zip.001 ...` (open the .001 file with 7-Zip, or `cat Project55_full_data.zip.* > full.zip`). It can also be regenerated exactly with `python3 code/generate_large.py` (fixed seed 7).
- `data_large_sample/`: a small stratified sample with the same folder names, for quick checks. To run the code on it, copy `training data` and `testing data` into `data_large/`.
- Each .npz holds `points` (N x 1024 x 3, float16), `labels` (0 rounded, 1 elongated, 2 platy, 3 angular, 4 irregular) and `particle_ids`.
- Trained model weights (about 150 MB) are not included; `code/results/models/*.json` holds the logs. Re-train with the queues in the run order.

## Live demo for the video
From this folder run: `python3 code/demo_live.py` (about 15 s on the sample data, a minute or two on the full data). It prints accuracy, macro-F1 and the confusion matrix. Needs numpy, scipy, scikit-learn.
