"""
Project 55 - Step 2: classical baselines (Random Forest, SVM) on handcrafted,
rotation-invariant geometric features computed from each point cloud.
Outputs: results/baseline_metrics.json, results/cm_rf.png, results/cm_svm.png
"""
import json
import os

import numpy as np
from scipy.spatial import ConvexHull
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CLASS_NAMES = ["rounded", "elongated", "platy", "angular", "irregular"]
FEATURE_NAMES = [
    "pca_l1", "pca_l2", "pca_l3", "elongation", "flatness", "sphericity_axes",
    "r_mean", "r_std", "r_skew", "r_kurt", "r_min", "r_max", "r_p10", "r_p90",
    "hull_vol", "hull_area", "compactness", "hull_solidity_proxy",
    "n_hull_facets", "normal_var",
    "d2_mean", "d2_std", "d2_p10", "d2_p90",
]


def features(P):
    P = P - P.mean(0)
    cov = np.cov(P.T)
    ev, evec = np.linalg.eigh(cov)
    ev = np.sort(ev)[::-1]
    ev = np.clip(ev, 1e-9, None)
    l1, l2, l3 = ev
    r = np.linalg.norm(P, axis=1)
    rn = r / r.max()
    m, s = rn.mean(), rn.std() + 1e-9
    skew = ((rn - m) ** 3).mean() / s ** 3
    kurt = ((rn - m) ** 4).mean() / s ** 4

    hull = ConvexHull(P)
    vol, area = hull.volume, hull.area
    compact = 36 * np.pi * vol ** 2 / area ** 3  # 1 for a sphere
    # facet normal diversity: angular/faceted shapes have few large facets
    eq = hull.equations[:, :3]
    normal_var = eq.std(0).mean()
    # solidity proxy: fraction of points close to hull surface (rough surfaces dip inside)
    dist_to_hull = -(P @ eq.T + hull.equations[:, 3]).max(1) * -1  # distance inside hull
    inside = np.abs(np.max(P @ eq.T + hull.equations[:, 3], axis=1))
    solidity_proxy = (inside < 0.01).mean()

    # D2 shape distribution (pairwise distances of random point pairs)
    rng = np.random.default_rng(0)
    i = rng.integers(0, len(P), 2000)
    j = rng.integers(0, len(P), 2000)
    d2 = np.linalg.norm(P[i] - P[j], axis=1)
    d2 = d2 / d2.max()

    return [
        l1, l2, l3, np.sqrt(l1 / l3), np.sqrt(l3 / l1), (l2 * l3) ** 0.5 / l1,
        m, s, skew, kurt, rn.min(), rn.max(), np.percentile(rn, 10), np.percentile(rn, 90),
        vol, area, compact, solidity_proxy,
        len(hull.simplices), normal_var,
        d2.mean(), d2.std(), np.percentile(d2, 10), np.percentile(d2, 90),
    ]


def load(split, folder):
    z = np.load(os.path.join("data", folder, f"{split}.npz"))
    return z["points"], z["labels"]


def feats_for(P):
    return np.array([features(p) for p in P])


def plot_cm(cm, title, path):
    fig, ax = plt.subplots(figsize=(5, 4.5))
    cmn = cm / cm.sum(1, keepdims=True)
    ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(5)); ax.set_xticklabels(CLASS_NAMES, rotation=40, ha="right")
    ax.set_yticks(range(5)); ax.set_yticklabels(CLASS_NAMES)
    for a in range(5):
        for b in range(5):
            ax.text(b, a, cm[a, b], ha="center", va="center",
                    color="white" if cmn[a, b] > 0.5 else "black", fontsize=8)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title)
    fig.tight_layout(); fig.savefig(path, dpi=160); plt.close(fig)


def main():
    os.makedirs("results", exist_ok=True)
    Ptr, ytr = load("train", "training data")
    Pva, yva = load("val", "training data")
    Pte, yte = load("test", "testing data")
    print("Extracting features...")
    Ftr, Fva, Fte = feats_for(Ptr), feats_for(Pva), feats_for(Pte)
    np.savez_compressed("results/features.npz", Ftr=Ftr, ytr=ytr, Fva=Fva, yva=yva,
                        Fte=Fte, yte=yte, names=np.array(FEATURE_NAMES))

    out = {}
    models = {
        "RandomForest": RandomForestClassifier(n_estimators=400, random_state=42, n_jobs=-1),
        "SVM_RBF": make_pipeline(StandardScaler(), SVC(C=10, gamma="scale", random_state=42)),
    }
    for name, mdl in models.items():
        mdl.fit(Ftr, ytr)
        val_acc = accuracy_score(yva, mdl.predict(Fva))
        pred = mdl.predict(Fte)
        cm = confusion_matrix(yte, pred)
        out[name] = dict(
            val_accuracy=float(val_acc),
            test_accuracy=float(accuracy_score(yte, pred)),
            test_macro_f1=float(f1_score(yte, pred, average="macro")),
            confusion_matrix=cm.tolist(),
        )
        plot_cm(cm, f"{name} (test)", f"results/cm_{name}.png")
        print(name, {k: v for k, v in out[name].items() if k != "confusion_matrix"})

    rf = models["RandomForest"]
    imp = sorted(zip(FEATURE_NAMES, rf.feature_importances_), key=lambda t: -t[1])
    out["RandomForest_top_features"] = [(n, float(v)) for n, v in imp[:8]]
    with open("results/baseline_metrics.json", "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
