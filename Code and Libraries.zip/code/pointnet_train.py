"""
Project 55 - Step 3: PointNet classifier (PyTorch) on the synthetic particle point clouds.

Run (after generate_dataset.py):
    pip install torch
    python pointnet_train.py --epochs 60

Same train/val/test split and same metrics as baselines.py:
accuracy, macro-F1, confusion matrix. Model selection uses the validation set only;
the test set is evaluated once at the end with the best-validation checkpoint.
Outputs: results/pointnet_metrics.json, results/cm_PointNet.png, results/pointnet_curves.png
"""
import argparse
import json
import os

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CLASS_NAMES = ["rounded", "elongated", "platy", "angular", "irregular"]


class TNet(nn.Module):
    """Input/feature alignment network (as in the original PointNet)."""
    def __init__(self, k):
        super().__init__()
        self.k = k
        self.conv = nn.Sequential(
            nn.Conv1d(k, 64, 1), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 1), nn.BatchNorm1d(128), nn.ReLU(),
            nn.Conv1d(128, 512, 1), nn.BatchNorm1d(512), nn.ReLU())
        self.fc = nn.Sequential(
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(),
            nn.Linear(256, 128), nn.BatchNorm1d(128), nn.ReLU(),
            nn.Linear(128, k * k))
        nn.init.zeros_(self.fc[-1].weight); nn.init.zeros_(self.fc[-1].bias)

    def forward(self, x):  # x: B,k,N
        b = x.size(0)
        h = self.conv(x).max(2)[0]
        m = self.fc(h).view(b, self.k, self.k) + torch.eye(self.k, device=x.device)
        return m


class PointNet(nn.Module):
    def __init__(self, n_classes=5):
        super().__init__()
        self.tnet3 = TNet(3)
        self.tnet64 = TNet(64)
        self.mlp1 = nn.Sequential(nn.Conv1d(3, 64, 1), nn.BatchNorm1d(64), nn.ReLU(),
                                  nn.Conv1d(64, 64, 1), nn.BatchNorm1d(64), nn.ReLU())
        self.mlp2 = nn.Sequential(nn.Conv1d(64, 128, 1), nn.BatchNorm1d(128), nn.ReLU(),
                                  nn.Conv1d(128, 1024, 1), nn.BatchNorm1d(1024), nn.ReLU())
        self.head = nn.Sequential(nn.Linear(1024, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.3),
                                  nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.3),
                                  nn.Linear(256, n_classes))

    def forward(self, x):  # x: B,N,3
        x = x.transpose(1, 2)
        t3 = self.tnet3(x)
        x = torch.bmm(t3, x)
        x = self.mlp1(x)
        t64 = self.tnet64(x)
        x = torch.bmm(t64, x)
        x = self.mlp2(x).max(2)[0]
        return self.head(x), t64


def feat_transform_reg(t):
    I = torch.eye(t.size(1), device=t.device)
    return torch.mean(torch.norm(torch.bmm(t, t.transpose(1, 2)) - I, dim=(1, 2)))


def load(split, folder):
    z = np.load(os.path.join("data", folder, f"{split}.npz"))
    return torch.from_numpy(z["points"]), torch.from_numpy(z["labels"])


def augment(x):
    # small random anisotropy-free perturbations only: jitter. (Rotation is NOT removed on
    # purpose: the data are already randomly rotated, so the net must learn rotation robustness.)
    return x + 0.005 * torch.randn_like(x)


@torch.no_grad()
def predict(model, X, dev, bs=256):
    model.eval()
    out = []
    for i in range(0, len(X), bs):
        out.append(model(X[i:i + bs].to(dev))[0].argmax(1).cpu())
    return torch.cat(out).numpy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    torch.manual_seed(args.seed); np.random.seed(args.seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", dev)
    os.makedirs("results", exist_ok=True)

    Xtr, ytr = load("train", "training data")
    Xva, yva = load("val", "training data")
    Xte, yte = load("test", "testing data")

    model = PointNet(len(CLASS_NAMES)).to(dev)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, args.epochs)

    best_val, best_state = -1, None
    hist = dict(train_loss=[], val_acc=[])
    for ep in range(args.epochs):
        model.train()
        perm = torch.randperm(len(Xtr))
        tot = 0.0
        for i in range(0, len(perm) - args.bs + 1, args.bs):
            idx = perm[i:i + args.bs]
            xb, yb = augment(Xtr[idx]).to(dev), ytr[idx].to(dev)
            logits, t64 = model(xb)
            loss = F.cross_entropy(logits, yb) + 0.001 * feat_transform_reg(t64)
            opt.zero_grad(); loss.backward(); opt.step()
            tot += loss.item() * len(idx)
        sched.step()
        va = accuracy_score(yva.numpy(), predict(model, Xva, dev))
        hist["train_loss"].append(tot / len(perm)); hist["val_acc"].append(va)
        if va > best_val:
            best_val = va
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        print(f"epoch {ep+1:3d}/{args.epochs}  loss {hist['train_loss'][-1]:.4f}  val_acc {va:.4f}")

    model.load_state_dict(best_state)
    torch.save(best_state, "results/pointnet_best.pt")
    pred = predict(model, Xte, dev)
    cm = confusion_matrix(yte.numpy(), pred)
    metrics = dict(best_val_accuracy=float(best_val),
                   test_accuracy=float(accuracy_score(yte.numpy(), pred)),
                   test_macro_f1=float(f1_score(yte.numpy(), pred, average="macro")),
                   confusion_matrix=cm.tolist(), epochs=args.epochs)
    json.dump(metrics, open("results/pointnet_metrics.json", "w"), indent=2)
    print({k: v for k, v in metrics.items() if k != "confusion_matrix"})

    # confusion matrix figure
    fig, ax = plt.subplots(figsize=(5, 4.5))
    cmn = cm / cm.sum(1, keepdims=True)
    ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(5)); ax.set_xticklabels(CLASS_NAMES, rotation=40, ha="right")
    ax.set_yticks(range(5)); ax.set_yticklabels(CLASS_NAMES)
    for a in range(5):
        for b in range(5):
            ax.text(b, a, cm[a, b], ha="center", va="center",
                    color="white" if cmn[a, b] > 0.5 else "black", fontsize=8)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title("PointNet (test)")
    fig.tight_layout(); fig.savefig("results/cm_PointNet.png", dpi=160); plt.close(fig)

    # training curves
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.5))
    ax[0].plot(hist["train_loss"]); ax[0].set_title("Training loss"); ax[0].set_xlabel("epoch")
    ax[1].plot(hist["val_acc"]); ax[1].set_title("Validation accuracy"); ax[1].set_xlabel("epoch")
    fig.tight_layout(); fig.savefig("results/pointnet_curves.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
