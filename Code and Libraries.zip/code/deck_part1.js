// Sections 1-5 of the extended deck: introduction, problem, theory, previous work, method (result-independent).
const { DK, TEAL, AMB, PALE, MUT, DEEP, RED } = require("./deck_lib");

module.exports = function part1(pres, H, S) {
  let s;
  // 1 ---------------------------------------------------------------- title
  s = H.slide("Hello, and welcome. This project asks a practical question: can a computer reliably tell what shape a tiny particle has, even when the 3D scan is noisy, sparse or partly cut off? I build a large synthetic benchmark of CT-style artifacts, test classical and deep models on it, and add a way for the system to say I am not sure instead of guessing.", true);
  s.addText("Corruption-Robust 3D Particle Morphology Classification", { x: 0.8, y: 1.5, w: 11.7, h: 2.0, fontFace: "Cambria", fontSize: 42, bold: true, color: "FFFFFF", margin: 0, isTextBox: true, valign: "top" });
  s.addText("A CT-artifact benchmark, pose-canonical PointNet with feature fusion, and conformal abstention", { x: 0.8, y: 3.7, w: 11.2, h: 0.9, fontSize: 22, color: "BFE0DC", margin: 0, isTextBox: true, valign: "top" });
  s.addText("Virender   |   Enrolment No. 24324027   |   AI for 3D Morphology and Material Characterization", { x: 0.8, y: 5.7, w: 11.7, h: 0.4, fontSize: 16, color: "FFFFFF", margin: 0, isTextBox: true });

  // 2 ---------------------------------------------------------------- agenda
  s = H.slide("Here is the road map. First the introduction and the problem, then the theory I need, then previous work, then my method, results, and finally discussion with ethics, limitations and the conclusion. The order follows the course template.");
  H.title(s, "Roadmap");
  const ag = ["Introduction", "Problem and objectives", "Theory", "Previous work", "Method", "Results", "Discussion and conclusion"];
  ag.forEach((t, i) => {
    const col = i % 4, row = Math.floor(i / 4);
    const x = 0.6 + col * 3.1, y = 1.7 + row * 2.4;
    s.addShape(pres.ShapeType.roundRect, { x, y, w: 2.9, h: 2.1, rectRadius: 0.08, fill: { color: i % 2 ? PALE : DEEP }, line: { color: i % 2 ? PALE : DEEP } });
    s.addText(String(i + 1), { x: x + 0.25, y: y + 0.15, w: 1, h: 0.8, fontFace: "Cambria", fontSize: 40, bold: true, color: i % 2 ? TEAL : AMB, margin: 0, isTextBox: true });
    s.addText(t, { x: x + 0.25, y: y + 1.0, w: 2.5, h: 1.0, fontSize: 19, bold: true, color: i % 2 ? DK : "FFFFFF", margin: 0, valign: "top", isTextBox: true });
  });

  // ================================================================ SECTION 1
  H.divider(1, "Introduction", "Why particle shape matters and what a point cloud is", "Section one: the introduction.");

  s = H.slide("Particle shape controls how powders and granular materials behave. Round grains flow and pack well. Flat or elongated grains jam, pack loosely and can weaken a part. Angular grains interlock. So knowing the shape distribution of a batch is a real quality-control question in additive manufacturing, ceramics, pharmaceuticals, mining and soil mechanics.");
  H.title(s, "Why does particle shape matter?");
  H.bullets(s, ["Flow and packing: round grains pour and pack densely; flat or needle-like grains jam.", "Strength: angular grains interlock; platy grains can create weak planes.", "Industries: metal powder for 3D printing, ceramics, pharmaceutical tablets, sand and soil, battery materials.", "Today most shape grading is by eye or from 2D images, which is slow and subjective."], { x: 0.6, y: 1.5, w: 7.2, h: 5 });
  H.stat(s, 8.4, 1.5, 4.3, 1.5, "flow", "round vs flat grains behave differently", true);
  H.stat(s, 8.4, 3.2, 4.3, 1.5, "packing", "shape sets how densely grains fit");
  H.stat(s, 8.4, 4.9, 4.3, 1.5, "strength", "interlocking vs weak planes");

  s = H.slide("A micro-CT scanner builds a 3D image. A segmentation step finds each particle, and its surface can be written as a cloud of points. A classifier takes that cloud and outputs a shape class. This project studies the classifier and, importantly, what happens when the scan is imperfect.");
  H.title(s, "From a CT scan to a shape label");
  H.img(s, "figs/pipeline.png", 0.5, 1.6, 12.3, 3.4);
  H.bullets(s, ["Input: the surface points of one particle. Output: one of five morphology classes, plus a confidence-aware set.", "Real scans are imperfect, so the benchmark tests five kinds of CT-style artifact."], { x: 0.6, y: 5.3, w: 12.1, h: 1.5, fontSize: 18 });

  s = H.slide("A point cloud is just a list of x, y, z coordinates, with no order and no connections. Shuffle the list and it is the same particle. Rotate the particle and the numbers all change, but the particle does not. A good classifier must respect both facts.");
  H.title(s, "What is a point cloud?");
  H.card(s, 0.6, 1.5, 3.9, 4.9, "A set of points", "Each particle is N points (x, y, z) sampled on its surface, here N = 256 to 1,024. There is no grid and no ordering of the points.");
  H.card(s, 4.7, 1.5, 3.9, 4.9, "Order does not matter", "Shuffling the list must not change the answer. This is called permutation invariance and it shapes the network design.", { fill: "FFFFFF", size: 17 });
  H.card(s, 8.8, 1.5, 3.9, 4.9, "Orientation is arbitrary", "A scanned grain lies at any angle, so the same shape gives completely different coordinates. We must handle rotation.", H.dark());

  s = H.slide("These are the five classes. Rounded particles are close to spheres. Elongated particles are stretched like rice grains. Platy particles are flat like flakes. Angular particles have flat faces and sharp edges. Irregular particles have a rough, bumpy surface. All of these are generated by code, so the true label is known exactly.");
  H.title(s, "The five morphology classes");
  H.img(s, "results/particle_gallery.png", 0.6, 1.4, 7.6, 3.29);
  H.img(s, "figs/class_table.png", 0.6, 4.85, 7.6, 2.0);
  H.bullets(s, ["Rounded: near-sphere", "Elongated: rice-like, stretched", "Platy: flake-like, flat", "Angular: flat faces and sharp edges", "Irregular: rough, bumpy surface", "Classes overlap on purpose, so the task is not trivial."], { x: 8.6, y: 1.5, w: 4.2, h: 5, fontSize: 18 });

  // ================================================================ SECTION 2
  H.divider(2, "Problem and objectives", "What exactly is solved, why it is hard, and why it needs solving", "Section two: the problem and the objectives.");

  s = H.slide("The problem statement. Given the 3D surface points of one particle, predict its morphology class. The input can be in any orientation, at any size, and may be corrupted by CT artifacts. The output should be a class, and when the model is unsure it should say so by returning more than one class or by abstaining.");
  H.title(s, "Problem statement");
  H.card(s, 0.6, 1.5, 5.9, 2.35, "Input", "A point cloud of one particle: any orientation, any size, possibly noisy, sparse, blurred, voxelised or partly cut off.", { size: 18 });
  H.card(s, 6.8, 1.5, 5.9, 2.35, "Output", "A class among five, plus a set of plausible classes with a statistical coverage target, so uncertain cases can go to a human.", { size: 18 });
  H.card(s, 0.6, 4.1, 12.1, 2.3, "Success means", "High accuracy and macro-F1 on clean data AND graceful behaviour when the data degrade, AND honest reporting of when the model should not be trusted.", H.dark({ size: 19 }));

  s = H.slide("Why is this hard? Four things. Orientation: a grain can lie any way. Size: absolute size is removed so shape is what matters. Noise and sparsity: real scans are imperfect. And partial views: particles may touch or be clipped by the scan volume. Each of these breaks a model trained only on clean, tidy data.");
  H.title(s, "Why is it hard?");
  const hard = [["Orientation", "Same shape, different coordinates after rotation."], ["Class overlap", "A slightly flattened round grain looks like a platy one."], ["Acquisition artifacts", "Noise, low point density, anisotropic blur, voxel steps."], ["Partial views", "Touching or clipped particles lose a cap of their surface."]];
  hard.forEach(([h, b], i) => H.card(s, 0.6 + (i % 2) * 6.2, 1.5 + Math.floor(i / 2) * 2.7, 5.9, 2.5, h, b, i === 3 ? H.dark({ size: 18 }) : { size: 18 }));

  s = H.slide("Why does this need solving? Manual grading does not scale and differs between people. Automated grading is only useful if it is reliable on real, imperfect scans, but most published models are tested on clean data only. A benchmark that shows how models degrade, and a model that knows when it is unsure, closes that gap.");
  H.title(s, "Why it needs solving");
  H.bullets(s, ["Manual grading is slow and differs between people.", "Models are usually tested on clean data only, so reported accuracy may not survive a real scanner.", "Wrong labels can pass defective batches: failures should be visible, not silent.", "Synthetic data gives exact ground truth for controlled studies that real scans cannot provide."], { x: 0.6, y: 1.5, w: 12.1, h: 4.6, fontSize: 21 });

  s = H.slide("These are the four research questions. One: how large is the accuracy gap between clean and corrupted data for standard models. Two: does corruption-aware training and a robust feature subset close it. Three: does handling the PCA sign ambiguity by augmentation and test-time averaging help. Four: can conformal prediction give honest abstention under shift.");
  H.title(s, "Research questions");
  const rq = [["RQ1", "How much do clean-trained classifiers lose on CT-style artifacts?"], ["RQ2", "Do corruption-aware training and robust features close the gap?"], ["RQ3", "Does sign-pose augmentation plus 4-pose averaging help PCA-canonical networks?"], ["RQ4", "Can conformal abstention stay trustworthy when the data shift?"]];
  rq.forEach(([a, b], i) => {
    const y = 1.5 + i * 1.3;
    s.addShape(pres.ShapeType.ellipse, { x: 0.6, y: y + 0.1, w: 0.9, h: 0.9, fill: { color: i % 2 ? AMB : TEAL }, line: { color: i % 2 ? AMB : TEAL } });
    s.addText(a, { x: 0.6, y: y + 0.1, w: 0.9, h: 0.9, align: "center", valign: "middle", fontSize: 15, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
    s.addText(b, { x: 1.8, y, w: 10.8, h: 1.1, fontSize: 21, color: DK, margin: 0, valign: "middle", isTextBox: true });
  });

  s = H.slide("My contributions are four. A new benchmark of five CT-style corruption families at two severities for single-particle point clouds. A systematic comparison of classical and deep models across clean and corrupted data. A pose-canonical PointNet that fuses robust features and averages over the four sign poses. And a conformal abstention analysis with corruption-aware calibration. I claim these as engineering contributions on synthetic data, not as a proven real-world result.");
  H.title(s, "Contributions");
  H.card(s, 0.6, 1.5, 2.9, 4.9, "1  Benchmark", "ParticleCT-C: five CT-style corruption families, two severities, on 40,000 synthetic particles.", { size: 16 });
  H.card(s, 3.65, 1.5, 2.9, 4.9, "2  Evidence", "Clean-trained models collapse; the size and cause of the collapse are measured per family.", { fill: "FFFFFF", size: 16 });
  H.card(s, 6.7, 1.5, 2.9, 4.9, "3  Model", "CF-PointNet-A: PCA-canonical frame, 4-pose averaging, 24 fused features, corruption-aware training.", { size: 16 });
  H.card(s, 9.75, 1.5, 2.95, 4.9, "4  Abstention", "Conformal sets with corruption-aware calibration for human-in-the-loop quality control.", H.dark({ size: 16 }));

  // ================================================================ SECTION 3
  H.divider(3, "Theory", "The ideas behind features, classifiers, pose canonicalisation and conformal prediction", "Section three: the theory I rely on.");

  s = H.slide("The first tool is principal component analysis of the points. The covariance matrix of the cloud has three eigenvalues, which are the variances along the three principal axes. Their ratios give elongation and flatness, and they do not change when the particle is rotated. The eigenvectors give a natural coordinate frame for the particle.");
  H.title(s, "Shape from the covariance matrix (PCA)");
  H.card(s, 0.6, 1.5, 6.0, 4.9, "Method", "Centre the cloud, compute C = (1/N) sum of p pT, take eigenvalues l1 >= l2 >= l3.\n\nElongation = sqrt(l1 / l3).\nFlatness = sqrt(l3 / l1).\n\nThe eigenvalues are rotation-invariant. The eigenvectors give a canonical frame, up to the sign of each axis.", { size: 18 });
  H.card(s, 6.9, 1.5, 5.8, 4.9, "What it tells us", "Rice-like grain: l1 much larger than l2, l3.\n\nFlake: l1 close to l2, l3 much smaller.\n\nSphere: all three nearly equal.\n\nWeakness: noise adds variance to every axis and shifts the eigenvalues, so features based on raw eigenvalues move under corruption.", H.dark({ size: 18 }));

  s = H.slide("Next is the convex hull, the smallest convex shape containing all the points. Its volume and area give compactness, which is one for a sphere. The number of hull facets and the fraction of points lying on the hull describe how faceted or rough the surface is. These are powerful on clean data but, as I will show, they are the most fragile under noise.");
  H.title(s, "Convex hull descriptors");
  H.bullets(s, ["Hull volume V and surface area A.", "Compactness 36 pi V^2 / A^3: equals 1 for a sphere, smaller for irregular shapes.", "Facet count and the fraction of points close to the hull surface: high for faceted or rough particles.", "Strength: separates angular from irregular on clean data.", "Weakness: a few noisy points can create dozens of new facets."], { x: 0.6, y: 1.5, w: 7.4, h: 5 });
  H.stat(s, 8.4, 1.6, 4.3, 1.9, "= 1", "compactness of a perfect sphere", true);
  H.stat(s, 8.4, 3.8, 4.3, 1.9, "fragile", "facet count under noise");

  s = H.slide("Two more families of descriptors. Radial statistics: the distribution of distances from the centre, normalised by the largest one, capture how bumpy the particle is. And the D2 shape distribution of Osada and colleagues: the histogram of distances between random pairs of surface points is a classic rotation-invariant fingerprint of a 3D shape.");
  H.title(s, "Radial and D2 shape distributions");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "Radial statistics", "Distance of each point from the centroid, divided by the maximum.\n\nMean, standard deviation, skewness, kurtosis, minimum, maximum, 10th and 90th percentiles.\n\nBumpy shapes have a wider spread; spheres a narrow one.", { size: 18 });
  H.card(s, 6.8, 1.5, 5.9, 4.9, "D2 distribution", "Draw random pairs of points and record their distance.\n\nThe histogram is invariant to rotation and translation and stable when points are subsampled.\n\nWe use its mean, standard deviation, 10th and 90th percentile.", H.dark({ size: 18 }));

  s = H.slide("Random Forest is an ensemble of many decision trees, each trained on a random sample of the data and a random subset of features. Each tree votes and the majority wins. Averaging many noisy trees reduces variance. It is a strong, robust baseline on tabular features and also gives feature importances.");
  H.title(s, "Random Forest");
  H.bullets(s, ["Many decision trees, each on a bootstrap sample and random feature subsets.", "Prediction = majority vote (or average of class probabilities).", "Reduces variance; handles different feature scales without standardising.", "Gives feature importance, which we use to discuss what the model relies on.", "Limit: trees split on thresholds, so a feature that shifts under noise can mislead them."], { x: 0.6, y: 1.5, w: 12.1, h: 4.8, fontSize: 21 });

  s = H.slide("A support vector machine finds the boundary with the largest margin between classes. With the RBF kernel it can draw smooth curved boundaries, because it measures similarity between points in feature space with a Gaussian bump. The parameter C trades margin width against training errors. Features are standardised first.");
  H.title(s, "Support Vector Machine (RBF kernel)");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "Idea", "Maximise the margin between classes.\n\nKernel K(x, x') = exp(-gamma ||x - x'||^2) gives smooth non-linear boundaries.\n\nC = 10 balances margin and errors.", { size: 19 });
  H.card(s, 6.8, 1.5, 5.9, 4.9, "In this project", "Same 24 (or 18 robust) features, standardised.\n\nOne-vs-one multi-class scheme.\n\nOn very large training sets the fit is slow, so for the corruption-augmented SVM we use a 30,000-sample subset.", H.dark({ size: 19 }));

  s = H.slide("PointNet works directly on the raw points. A small network is applied to every point separately, with the same weights, and then a max over all points collects the strongest response for each feature. Because max does not care about order, shuffling the points changes nothing. That is the key idea: f of P equals g of the max over points of h of each point.");
  H.title(s, "PointNet: learning directly on points");
  H.card(s, 0.6, 1.5, 6.0, 3.0, "Core formula", "f(P) = g( max over i of h(p_i) )\n\nh: shared per-point network\nmax: symmetric pooling\ng: classifier head", { size: 20 });
  H.card(s, 6.9, 1.5, 5.8, 3.0, "Why it works", "Max pooling is symmetric, so permuting the points gives the same output. Each channel records the strongest evidence anywhere on the surface.", H.dark({ size: 18 }));
  H.card(s, 0.6, 4.7, 12.1, 1.7, "Limitations used in this project", "No built-in rotation invariance (needs augmentation or a canonical frame); no local neighbourhood structure (PointNet++ adds it); sensitive to the distribution of the training data.", { size: 17, fill: "FFFFFF" });

  s = H.slide("Rotation is the next issue. We can either augment with random rotations and hope the network learns invariance, or we can put every particle into a canonical frame first. PCA gives such a frame: axes sorted by variance. The remaining problem is the sign of each axis, because the eigenvectors are only defined up to plus or minus.");
  H.title(s, "Handling rotation: canonical frames");
  H.card(s, 0.6, 1.5, 3.9, 4.9, "Option A: augment", "Train on random rotations. Simple, but the network must spend capacity learning invariance and invariance is only approximate.", { size: 17 });
  H.card(s, 4.7, 1.5, 3.9, 4.9, "Option B: canonical frame", "Rotate each cloud into its PCA frame: axis 1 = largest variance, axis 3 = smallest. The remaining freedom is the sign of each axis.", { size: 17, fill: "FFFFFF" });
  H.card(s, 8.8, 1.5, 3.9, 4.9, "Used here", "Option B with 4 proper sign poses (right-handed frames) and random sign augmentation; compared against option A.", H.dark({ size: 17 }));

  s = H.slide("This chart is a key measurement. If you rotate a clean cloud exactly, the PCA frame is perfectly consistent. But for symmetric particles the third moment along an axis is nearly zero, so the sign chosen by skewness is decided by noise. When I simply resample 256 points, or add mild corruption, the canonical pose changes in about two thirds of cases. So I do not trust one pose: I train on all four sign poses and average predictions over them at test time.");
  H.title(s, "The sign ambiguity is real");
  H.img(s, "figs/pose_ambiguity.png", 0.6, 1.4, 7.4, 3.7);
  H.bullets(s, ["Exact rotation: pose is consistent (0% change).", "A different random 256-point sample of the same particle: about 65% change.", "Cause: skewness along symmetric axes is near zero, so its sign is random.", "Remedy: 4 proper sign poses (determinant +1) as augmentation and as test-time average."], { x: 8.3, y: 1.5, w: 4.5, h: 5, fontSize: 17 });
  H.src(s, "Measured on 1,500 test particles. Change = a sign flip on axis 1 or 2, or an axis swap.");

  s = H.slide("Test-time averaging. Because the sign is unreliable, I run the network four times on the same cloud, once for each proper sign pose, and average the class probabilities. This costs four forward passes but removes dependence on a coin-flip. Training with random sign poses makes sure the network has seen all four.");
  H.title(s, "Test-time averaging over four sign poses");
  H.bullets(s, ["Poses: (+,+,+), (-,+,-), (+,-,-), (-,-,+): all rotations (determinant +1), no mirror images.", "Training: pick one pose at random for each particle in each step.", "Testing: average the softmax over the four poses.", "Ablation: train without sign augmentation, and compare single-pose vs 4-pose testing."], { x: 0.6, y: 1.5, w: 7.2, h: 5, fontSize: 19 });
  H.card(s, 8.2, 1.5, 4.5, 4.9, "Why not use mirrors?", "Reflections would also map a particle to its mirror image. These shape classes are mirror-symmetric as distributions, but proper rotations are the physically meaningful group, so we stay with them.", H.dark({ size: 17 }));

  s = H.slide("How do we measure performance? Accuracy is the fraction correct. Macro F1 averages the F1 score of each class equally, so no class is neglected. The confusion matrix shows which classes are mistaken for which. For the corruption benchmark I also report the mean accuracy over the ten corrupted test sets, and the worst case.");
  H.title(s, "Metrics");
  H.card(s, 0.6, 1.5, 3.9, 4.9, "Accuracy and macro-F1", "Accuracy: fraction of correct labels.\n\nMacro-F1: mean of per-class F1, so every class counts equally.", { size: 17 });
  H.card(s, 4.7, 1.5, 3.9, 4.9, "Confusion matrix", "Rows are true classes, columns predictions. Shows which shapes are mistaken for which.", { size: 17, fill: "FFFFFF" });
  H.card(s, 8.8, 1.5, 3.9, 4.9, "Robustness", "Mean corrupted accuracy over 10 corrupted sets (mCA), worst-case set, and clean-to-corrupted gap.", H.dark({ size: 17 }));

  s = H.slide("Conformal prediction wraps any classifier. On a held-out calibration set, I compute a score for each particle, here one minus the probability given to its true class. I take the right quantile of these scores. At test time, the prediction set contains every class whose probability clears that threshold. If calibration and test data are exchangeable, the set contains the true class with probability at least one minus alpha. I use alpha of 0.1, i.e. 90 percent coverage.");
  H.title(s, "Conformal prediction (split, LAC score)");
  H.card(s, 0.6, 1.5, 6.0, 4.9, "Recipe", "1. Score s = 1 - p(true class) on a calibration set of n particles.\n2. q = the ceil((n+1)(1-alpha))/n quantile of the scores.\n3. For a new particle, set = { classes with p >= 1 - q }.\n\nGuarantee: P(true class in set) >= 1 - alpha, if calibration and test data are exchangeable.", { size: 17 });
  H.card(s, 6.9, 1.5, 5.8, 4.9, "Why we care", "The guarantee is about data of the same kind as the calibration data. Under a scanner artifact the data shift, so the guarantee can break.\n\nIdea tested here: calibrate on a mixture of mildly corrupted data (corruption-aware calibration).", H.dark({ size: 17 }));

  s = H.slide("Selective classification. A prediction set of exactly one class is accepted automatically. A set with two or more classes, or an empty set, is sent for human review. The useful numbers are the coverage, the average set size, the fraction accepted automatically, and the accuracy among the accepted ones.");
  H.title(s, "Accept or send to a human");
  H.bullets(s, ["Set size 1: accept automatically.", "Set size 0 or 2+: abstain and send to a human.", "Coverage: fraction of particles whose true class is inside the set (target 90%).", "Auto-accept rate and accuracy when accepted: the practical trade-off.", "Under corruption a good system abstains more instead of making confident errors."], { x: 0.6, y: 1.5, w: 12.1, h: 4.8, fontSize: 21 });

  // ================================================================ SECTION 4
  H.divider(4, "Previous work", "What has been done, and where the gap is", "Section four: previous work.");

  s = H.slide("PointNet by Qi and colleagues, 2017, showed that a network can learn directly from unordered point sets with a shared per-point function and max pooling. PointNet plus plus added local neighbourhoods at several scales. ModelNet40 became the standard benchmark. These works use clean, general objects such as chairs and airplanes, not particles.");
  H.title(s, "Deep learning on point clouds");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "PointNet (2017)", "Qi, Su, Mo, Guibas. Shared per-point MLP + max pooling gives permutation invariance; input and feature alignment networks (T-Nets) add some pose robustness.", { size: 18 });
  H.card(s, 6.8, 1.5, 5.9, 4.9, "PointNet++ (2017)", "Qi, Yi, Su, Guibas. Hierarchical sampling and grouping capture local structure at several scales. Benchmarks: ModelNet40 and ShapeNet objects, not microscopic particles.", H.dark({ size: 18 }));

  s = H.slide("Rotation-invariant point cloud learning is a large field. Li and colleagues at ICCV 2021 studied PCA-based canonical poses and the ambiguity they carry, and proposed a pose selector. Another line, PaRI-Conv, builds rotation invariance into the convolution through pose-aware features. My contribution here is not a new general rotation-invariant architecture. It is measuring how the PCA ambiguity behaves on particles under corruption, and pairing a simple four-pose scheme with robust features.");
  H.title(s, "Rotation-invariant point cloud learning");
  H.bullets(s, ["Li et al., ICCV 2021: PCA-based canonical poses carry ambiguity; a pose selector module resolves it and gains about 5% on a real-world dataset.", "PaRI-Conv (arXiv 2205.15210): pose-aware rotation-invariant convolution with Augmented Point Pair Features.", "Common finding: canonical poses help but the ambiguity must be handled explicitly.", "Our angle: quantify the ambiguity on particles under CT-style corruption; use 4 proper sign poses plus feature fusion."], { x: 0.6, y: 1.5, w: 12.1, h: 5, fontSize: 19 });

  s = H.slide("Robustness benchmarks. ModelNet-C by Ren, Pan and Liu at ICML 2022 defines seven corruption types, each with five severities, for general point cloud classification, and shows that models with higher clean accuracy are not always more robust. My benchmark follows the same idea but for single particles and with corruptions that mimic CT acquisition: noise, sparsity, anisotropic z-blur, occlusion by clipping, and voxelisation.");
  H.title(s, "Corruption benchmarks");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "ModelNet-C (ICML 2022)", "Seven corruptions (scale, jitter, drop global, drop local, add global, add local, rotate), five severities, on ModelNet40 objects. Message: clean accuracy does not predict robustness.", { size: 18 });
  H.card(s, 6.8, 1.5, 5.9, 4.9, "This work: ParticleCT-C", "Five CT-motivated corruptions on single particles: noise, sparse, z-blur, occlusion, voxel. Two severities each. Applied to held-out test data only; training banks use different seeds.", H.dark({ size: 18 }));

  s = H.slide("Machine learning for particle morphology. A December 2025 arXiv study clustered about 126 thousand 316L powder particle images unsupervised, using Fourier descriptors, and noted that the shape groups are not yet linked to flowability. A 2024 Mendeley dataset provides 1,551 real micro-CT sand grains and 50 thousand synthetic grains as 3D meshes, which could be used to extend this work. Most such work is on 2D images or on clean data.");
  H.title(s, "Machine learning for particle morphology");
  H.bullets(s, ["Akeweje et al., arXiv 2512.06012 (2025): unsupervised morphology profiling of 316L powder; Fourier descriptors + k-means best on internal validity; no link yet to flowability.", "Vlassis et al., Mendeley Data (2024): 1,551 real synchrotron-CT sand grains and 50,000 synthetic grains (CC BY 4.0).", "Gap: few studies test 3D morphology classifiers under controlled acquisition artifacts, or report abstention."], { x: 0.6, y: 1.5, w: 12.1, h: 5, fontSize: 19 });

  s = H.slide("Conformal prediction is well established as a way to get set-valued predictions with a coverage guarantee under exchangeability, and its behaviour under distribution shift is an active research topic. I use the simple split version with the least ambiguous class score, and test what happens under CT-style shift, which is the practical question for quality control.");
  H.title(s, "Conformal prediction and distribution shift");
  H.bullets(s, ["Split conformal prediction: marginal coverage 1 - alpha under exchangeability (Vovk et al.; Angelopoulos and Bates tutorial).", "Under distribution shift the guarantee can fail; current research adapts calibration to the shift.", "Our test: does calibrating on mildly corrupted data restore coverage on corrupted and unseen-severity data?"], { x: 0.6, y: 1.5, w: 12.1, h: 5, fontSize: 20 });

  s = H.slide("Putting this together, the gap is clear. General point cloud work is evaluated on everyday objects. Particle work often uses 2D images or clean data. Few studies combine 3D particle classification, controlled artifact benchmarks, pose handling and calibrated abstention. That intersection is where this project sits, and I make no claim of beating any published number, because the datasets differ.");
  H.title(s, "Gap analysis");
  H.table(s, ["Topic", "General point clouds", "Particle morphology", "This work"], [
    ["3D point-cloud learning", "Yes (ModelNet, ShapeNet)", "Rare", "Yes"],
    ["Rotation / pose handling", "Yes (PCA, pose-aware convs)", "Rarely studied", "4 sign poses + TTA"],
    ["Corruption benchmark", "ModelNet-C", "Not found", "ParticleCT-C"],
    ["Feature + point fusion", "Rare", "Hand-crafted only", "24 descriptors fused with points"],
    ["Conformal abstention", "Emerging", "Not found", "Corruption-aware calibration"],
  ], { x: 0.6, y: 1.6, w: 12.1, colW: [2.9, 3.1, 2.8, 3.3], fs: 16, rowH: 0.7 });
  H.src(s, "'Not found' = I did not find it in a limited web search; this is not a proof of absence.");

  // ================================================================ SECTION 5
  H.divider(5, "Method", "Data, corruptions, features, models, training and evaluation", "Section five: my method.");

  s = H.slide("This is the overall pipeline of the experiment. A procedural generator produces forty thousand clean particles. For training, I add corrupted copies from a separate bank. For testing, I corrupt held-out particles in ten fixed ways. Models see a PCA-canonical frame, produce probabilities, and a conformal step turns those into sets, so uncertain cases are flagged.");
  H.title(s, "Experiment pipeline");
  H.img(s, "figs/pipeline.png", 0.5, 1.5, 12.3, 3.4);
  H.bullets(s, ["Training data: 28,000 clean + corrupted copies (2 per particle, random family and severity).", "Test data: 4,000 clean + 10 corrupted sets of the same 4,000 particles.", "Split by particle ID: no particle appears in two splits."], { x: 0.6, y: 5.1, w: 12.1, h: 1.8, fontSize: 18 });

  s = H.slide("Here is how particles are generated. Rounded, elongated and platy are ellipsoids with different axis ratios plus small smooth bumps. Angular particles are random convex hulls with fourteen to forty-four vertices, sampled uniformly by facet area. Irregular particles are ellipsoids multiplied by a smooth random radial field. Every particle is centred, scaled to the unit sphere to remove absolute size, randomly rotated, and given a little Gaussian surface noise.");
  H.title(s, "Synthetic particle generator");
  H.bullets(s, ["Ellipsoids: rounded (axes 0.7-1.0), elongated (aspect 1.25-2.6), platy (thickness 0.3-0.7).", "Angular: random convex hull, 14-44 vertices, uniform-by-area surface sampling.", "Irregular: radial perturbation, 5-9 random waves.", "All: centre, scale to unit sphere, random proper rotation, Gaussian noise sigma = 0.02.", "Parameter ranges overlap between classes by design."], { x: 0.6, y: 1.5, w: 7.4, h: 5, fontSize: 18 });
  H.card(s, 8.3, 1.5, 4.4, 4.9, "Why synthetic?", "The class label is exact. Difficulty, noise and overlap can be controlled. No scanner time or manual annotation.\n\nCost: real particles are more diverse, so results must be validated on real data.", H.dark({ size: 17 }));

  s = H.slide("The dataset is large. Eight thousand particles per class, forty thousand in total, each with 1,024 surface points. The split is by particle ID: seventy percent train, ten percent validation, ten percent calibration for conformal prediction, and ten percent test. The data are generated with fixed seeds so they can be regenerated exactly.");
  H.title(s, "Dataset");
  H.stat(s, 0.6, 1.5, 3.9, 1.7, "40,000", "particles (8,000 per class)", true);
  H.stat(s, 4.7, 1.5, 3.9, 1.7, "1,024", "surface points per particle");
  H.stat(s, 8.8, 1.5, 3.9, 1.7, "5", "morphology classes");
  H.table(s, ["Split", "Particles", "Used for"], [["Train", "28,000", "fitting models"], ["Validation", "4,000", "choosing the best epoch"], ["Calibration", "4,000", "conformal thresholds only"], ["Test", "4,000", "reported once"]], { x: 0.6, y: 3.6, w: 12.1, colW: [3, 3, 6.1], fs: 17, rowH: 0.62 });
  H.src(s, "Seed 7, stratified by class; regenerated identically by generate_large.py.");

  s = H.slide("These are the five CT-style corruptions. Noise adds extra Gaussian noise. Sparse keeps only a few points. Z-blur adds noise only along the scan axis, imitating coarser resolution along one axis. Occlusion removes a cap of the particle, as when particles touch or are clipped. Voxel snaps points to a coarse grid. After each corruption the cloud is re-centred and re-scaled, just as a real pipeline would.");
  H.title(s, "Five CT-style corruption families");
  H.img(s, "figs/corruption_gallery.png", 0.5, 1.4, 12.3, 4.92);
  H.src(s, "The same irregular particle under all ten corruption settings (families x two severities).");

  s = H.slide("The exact settings. Two severities per family, mild and strong. Mild means the cloud is clearly degraded but a human could still tell the shape. Strong means a hard case. The models never see these exact test corruptions in training: training uses separate random copies with continuous random severities.");
  H.title(s, "Corruption settings");
  H.table(s, ["Family", "Mimics", "Severity 1", "Severity 2"], [
    ["noise", "reconstruction noise", "sigma +0.04", "sigma +0.08"],
    ["sparse", "low point density", "96 points", "32 points"],
    ["zblur", "anisotropic resolution", "z sigma 0.06", "z sigma 0.12"],
    ["occlusion", "clipped / touching", "15% removed", "35% removed"],
    ["voxel", "coarse CT voxels", "20 voxels / diameter", "10 voxels / diameter"],
  ], { x: 0.6, y: 1.6, w: 12.1, colW: [2.2, 3.6, 3.15, 3.15], fs: 18, rowH: 0.75 });
  H.src(s, "Reference: particle unit-sphere radius 1; base noise sigma 0.02 is already present in clean data.");

  s = H.slide("The features. I compute 24 rotation-invariant features: PCA based, radial, convex-hull based and D2. But I found that hull-based features such as the number of hull facets and the fraction of points on the hull change by forty to fifty percent under mild extra noise. So I define an 18-feature robust subset that drops all six hull-derived features, and compare the two sets.");
  H.title(s, "Features and the robust-subset hypothesis");
  H.img(s, "figs/feature_fragility.png", 0.5, 1.4, 7.4, 4.7);
  H.bullets(s, ["24 features = 6 PCA + 8 radial + 6 hull + 4 D2.", "Hypothesis: a robust subset (18) without the six hull-derived features generalises better.", "The drop is conservative; some PCA eigenvalues also move, but ratios are stable.", "Both sets are tested; the data decide (see results)."], { x: 8.2, y: 1.5, w: 4.6, h: 5, fontSize: 17 });

  s = H.slide("This is the CF-PointNet architecture. The top branch takes 256 points, rotates them into the PCA frame with a chosen sign pose, applies a shared network with three layers of 64, 128 and 256 units, and max-pools. The bottom branch takes the 24 shape features through a small dense layer of 64 units (the 18-feature robust variant, CF-PointNet-R, is an ablation). The two are concatenated and a small head with 128 hidden units gives five class probabilities. At test time, I average over the four sign poses.");
  H.title(s, "CF-PointNet architecture");
  H.img(s, "figs/architecture.png", 0.5, 1.4, 12.3, 4.35);
  H.bullets(s, ["About 85,000 parameters; implemented in NumPy with manual backpropagation, checked against finite differences."], { x: 0.6, y: 6.0, w: 12.1, h: 0.8, fontSize: 18 });

  s = H.slide("Training details. Adam optimiser with a cosine decayed learning rate starting at two times ten to the minus three, batch size 64, twenty epochs, 256 points per particle drawn at random each step. Small jitter noise is added to clean samples. The best epoch is chosen on a validation set that contains both clean and corrupted particles. Everything is seeded.");
  H.title(s, "Training protocol");
  H.table(s, ["Setting", "Value"], [["Optimiser", "Adam, cosine learning-rate decay from 2e-3"], ["Batch size / epochs", "64 / 20"], ["Points per particle", "256 (random subset each step)"], ["Loss", "Softmax cross-entropy"], ["Model selection", "Best validation accuracy (clean + corrupted validation)"], ["Seeds", "0 and 1 for the main comparisons"], ["Implementation", "NumPy, manual backprop (PyTorch unavailable)"]], { x: 0.6, y: 1.6, w: 12.1, colW: [4, 8.1], fs: 17, rowH: 0.62 });

  s = H.slide("Corruption-aware training. For every training particle I precompute two corrupted copies, each with a random family and a continuous random severity covering and exceeding the two test severities. During training, each sample is replaced by one of its corrupted copies with probability seventy-five percent. The features of corrupted samples are computed from the corrupted cloud so the feature branch also sees corrupted data.");
  H.title(s, "Corruption-aware training");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "Augmentation bank", "2 corrupted copies per training particle.\n\nRandom family; continuous severity range per family (for example noise sigma 0.01-0.09, sparse 28-160 points, voxel 8-24).\n\nFeatures computed on the corrupted cloud.", { size: 17 });
  H.card(s, 6.8, 1.5, 5.9, 4.9, "During training", "Each step: 75% corrupted copy, 25% clean.\n\nNo test set particle or test corruption seed is used.\n\nA variant leaves one family out (z-blur) to test generalisation to an unseen corruption.", H.dark({ size: 17 }));

  s = H.slide("These are the systems compared. Random Forest and SVM on features, clean-trained and corruption-trained. PointNet with random rotation augmentation. PCA-canonical PointNet without features. And the proposed CF-PointNet-R with robust features. Both clean-trained and corruption-aware versions are included so we can separate the effect of the training data from the effect of the architecture.");
  H.title(s, "Systems compared");
  H.table(s, ["System", "Input", "Rotation handling", "Training data"], [
    ["Random Forest, SVM", "24 or 18 features", "invariant features", "clean; or clean + corrupted"],
    ["PointNet", "256 points", "random rotations", "clean; or clean + corrupted"],
    ["PCA-PointNet", "256 points", "PCA frame + 4 sign poses", "clean; or clean + corrupted"],
    ["CF-PointNet-A (proposed)", "points + 24 features", "PCA frame + 4 sign poses", "clean-trained; or clean + corrupted"],
    ["CF-PointNet-R (ablation)", "points + 18 robust features", "PCA frame + 4 sign poses", "clean + corrupted"],
  ], { x: 0.6, y: 1.6, w: 12.1, colW: [3.2, 3.0, 3.1, 2.8], fs: 15, rowH: 0.72 });

  s = H.slide("The ablations. I test whether the sign augmentation matters, whether averaging over four poses matters, whether the robust feature subset matters compared with all 24 features, whether the point branch and the feature branch each matter, and whether corruption-aware training generalises to a corruption family that was left out of training.");
  H.title(s, "Ablation design");
  H.bullets(s, ["Sign augmentation: with vs without.", "Test-time averaging: 4 poses vs a single canonical pose.", "Features: 18 robust vs all 24.", "Architecture: PointNet (rotation augmentation) vs PCA-PointNet vs CF-PointNet.", "Training data: clean-only vs corruption-aware.", "Unseen corruption: leave z-blur out of training and test on z-blur."], { x: 0.6, y: 1.5, w: 12.1, h: 5, fontSize: 21 });

  s = H.slide("The conformal protocol. I use alpha of 0.1. The first calibration uses clean calibration particles only. The second uses a mixture of mildly corrupted calibration particles from all five families. Both are tested on every test set, including the strong corruptions that never appear in calibration. I report coverage, set size, auto-accept rate, and accuracy of the auto-accepted predictions.");
  H.title(s, "Conformal abstention protocol");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "Two calibrations", "Clean-calibrated: threshold from 4,000 clean calibration particles.\n\nMix-calibrated: threshold from 4,000 mildly corrupted calibration particles (800 per family).", { size: 18 });
  H.card(s, 6.8, 1.5, 5.8, 4.9, "Reported per test set", "Coverage (target 90%), mean set size, auto-accept rate (set size = 1), accuracy among auto-accepted, abstain rate.", H.dark({ size: 18 }));

  s = H.slide("Reproducibility and compute. Everything runs on two CPU cores with NumPy. The dataset is regenerated from fixed seeds, the corruption seeds are fixed, and I provide the scripts for every step. Each model trains in about fifteen minutes. The same code can be moved to PyTorch for larger models.");
  H.title(s, "Compute and reproducibility");
  H.bullets(s, ["2 CPU cores, NumPy only; ~15 min per model run.", "Seeds fixed for data (7), corruptions (2024 test, separate bank seeds) and models (0, 1).", "Gradients verified against finite differences.", "No code or data downloaded from GitHub; all code written for this project.", "Scripts: generate_large.py, features_large.py, build_corrupt_sets.py, build_train_bank.py, cfpn.py, evaluate_all.py."], { x: 0.6, y: 1.5, w: 12.1, h: 5, fontSize: 20 });
};
