"""Build the ParticleCT-C test sets: 5 corruption families x 2 severities on the 4,000 clean test particles,
plus a mild-corruption mixture of the calibration split (for corruption-aware conformal calibration).
Features are computed from the full corrupted cloud; network input is a 256-point (or fewer) sample."""
import numpy as np
import corruptions as cr
import baselines as b

def feats(clouds):
    out = []
    for c in clouds:
        try: out.append(b.features(c.astype(np.float64)))
        except Exception: out.append([np.nan] * len(b.FEATURE_NAMES))
    return np.array(out)

def fixed(clouds, rng, n=256):
    L = {len(c) for c in clouds}
    if len(L) == 1:
        L = L.pop()
        if L <= n: return np.stack(clouds).astype(np.float16)
    return cr.to_fixed(clouds, n, rng).astype(np.float16)

if __name__ == "__main__":
    te = np.load("data_large/testing data/test.npz"); X = te["points"].astype(np.float32); y = te["labels"]
    rng = np.random.default_rng(999)
    out = {"y": y}
    sub = rng.choice(1024, 256, replace=False)
    out["clean_X"] = X[:, sub].astype(np.float16)
    out["clean_F"] = np.load("results/features_large.npz")["F_test"]
    for fam in cr.FAMILIES:
        for sev in (0, 1):
            clouds = cr.corrupt_set(X, fam, sev, seed=2024)
            out[f"{fam}{sev+1}_X"] = fixed(clouds, rng); out[f"{fam}{sev+1}_F"] = feats(clouds)
            print(fam, sev + 1, out[f"{fam}{sev+1}_X"].shape, flush=True)
    ca = np.load("data_large/training data/cal.npz"); Xc = ca["points"].astype(np.float32); yc = ca["labels"]
    r2 = np.random.default_rng(5); idx = r2.permutation(len(Xc))
    parts, Fs, ys = [], [], []
    for k, fam in enumerate(cr.FAMILIES):
        ii = idx[k * 800:(k + 1) * 800]
        clouds = cr.corrupt_set(Xc[ii], fam, 0, seed=77)
        parts.append(fixed(clouds, r2)); Fs.append(feats(clouds)); ys.append(yc[ii])
    # pad to common point count (sparse family has fewer points): resample each part to 96 points -> instead store as list
    for k, fam in enumerate(cr.FAMILIES):
        out[f"calmix_{fam}_X"] = parts[k]; out[f"calmix_{fam}_F"] = Fs[k]; out[f"calmix_{fam}_y"] = ys[k]
    np.savez_compressed("results/corrupt_sets.npz", **out)
    print("saved")
