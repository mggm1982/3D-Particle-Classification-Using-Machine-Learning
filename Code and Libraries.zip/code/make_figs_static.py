"""Figures that do not depend on trained models: corruption gallery, feature fragility, pose ambiguity, pipeline, architecture."""
import numpy as np, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import corruptions as cr
import cfpn

OUT = "figs"
import os; os.makedirs(OUT, exist_ok=True)
TEAL, AMB, DEEP, GREY, RED = "#1F8A83", "#E39A2D", "#0F3D47", "#5B6E75", "#D2603F"
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
NAMES = ["rounded", "elongated", "platy", "angular", "irregular"]

# ---------- 1. corruption gallery (same particle, 11 conditions)
te = np.load("data_large/testing data/test.npz"); X = te["points"].astype(np.float32); y = te["labels"]
i = int(np.where(y == 4)[0][3])
conds = [("clean", None, None)] + [(f"{f} {s+1}", f, s) for f in cr.FAMILIES for s in (0, 1)]
fig = plt.figure(figsize=(14, 5.6))
for k, (lab, f, s) in enumerate(conds):
    ax = fig.add_subplot(2, 6, k + 1, projection="3d")
    if f is None:
        p = X[i][np.random.default_rng(0).choice(1024, 256, replace=False)]
    else:
        p = cr.corrupt_set(X[i:i + 1], f, s, 2024)[0]
    ax.scatter(p[:, 0], p[:, 1], p[:, 2], s=3, c=p[:, 2], cmap="viridis")
    ax.set_xlim(-1, 1); ax.set_ylim(-1, 1); ax.set_zlim(-1, 1); ax.set_axis_off(); ax.set_title(lab, fontsize=11)
fig.tight_layout(); fig.savefig(f"{OUT}/corruption_gallery.png", dpi=150); plt.close(fig)

# ---------- 2. feature fragility under mild noise
Z = np.load("results/corrupt_sets.npz"); ft = np.load("results/features_large.npz")
Fc = ft["F_test"]
rows = {}
for tag in ["noise1", "zblur1", "sparse1", "occlusion1", "voxel1"]:
    Fk = Z[f"{tag}_F"]
    rel = np.nanmedian(np.abs(Fk - Fc) / (np.abs(Fc) + 1e-9), axis=0)
    rows[tag] = rel
names = cfpn.FEATURE_NAMES
order = np.argsort(-rows["noise1"])
fig, ax = plt.subplots(figsize=(8.5, 5.4))
cols = [RED if names[j] in cfpn.HULL else TEAL for j in order]
ax.barh([names[j] for j in order][::-1], [100 * rows["noise1"][j] for j in order][::-1], color=cols[::-1])
ax.set_xlabel("median relative change of the feature under mild extra noise (%)")
ax.set_title("Feature change under mild extra noise (red = hull-derived)")
fig.tight_layout(); fig.savefig(f"{OUT}/feature_fragility.png", dpi=160); plt.close(fig)
json.dump({t: {names[j]: float(v[j]) for j in range(24)} for t, v in rows.items()}, open("results/feature_fragility.json", "w"), indent=1)

# ---------- 3. PCA pose stability under perturbation (not under exact rotation, where it is perfectly consistent)
def canon_axes(Xb):
    Xc = Xb - Xb.mean(1, keepdims=True)
    cov = np.einsum("bni,bnj->bij", Xc, Xc) / Xb.shape[1]
    w, V = np.linalg.eigh(cov.astype(np.float64)); V = V[:, :, ::-1].copy()
    V[:, :, 2] *= np.where(np.linalg.det(V) < 0, -1.0, 1.0)[:, None]
    C = np.einsum("bni,bij->bnj", Xc, V.astype(np.float32)); sk = np.sign((C ** 3).mean(1)); sk[sk == 0] = 1
    S = np.stack([sk[:, 0], sk[:, 1], sk[:, 0] * sk[:, 1]], 1)
    return V * S[:, None, :], w[:, ::-1]

rng = np.random.default_rng(5)
sel = np.concatenate([np.where(y == c)[0][:300] for c in range(5)])
Xfull = X[sel]
sub1 = np.stack([x[rng.choice(1024, 256, replace=False)] for x in Xfull]); V1, w1 = canon_axes(sub1)
def flip_rate(Vb):
    d = np.einsum("bij,bij->bj", V1, Vb)               # cosine between corresponding axes
    return (d[:, :2] < 0).any(1) | (np.abs(d).min(1) < 0.7)   # sign flip or axis swap
res_amb = {}
sub2 = np.stack([x[rng.choice(1024, 256, replace=False)] for x in Xfull]); res_amb["resample"] = flip_rate(canon_axes(sub2)[0])
for fam, sev in [("noise", 0), ("zblur", 0), ("occlusion", 0), ("voxel", 0), ("sparse", 0)]:
    cl = cr.corrupt_set(Xfull, fam, sev, 2024)
    cc = cr.to_fixed(cl, 256 if fam != "sparse" else 96, rng) if len({len(c) for c in cl}) > 1 or len(cl[0]) > 256 else np.stack(cl)
    res_amb[fam + "1"] = flip_rate(canon_axes(cc.astype(np.float32))[0])
ysel = y[sel]
summary = {k: dict(overall=float(v.mean()), per_class=[float(v[ysel == c].mean()) for c in range(5)]) for k, v in res_amb.items()}
json.dump(summary, open("results/pose_ambiguity.json", "w"), indent=1)
fig, ax = plt.subplots(figsize=(8, 4))
ks = list(res_amb); vals = [100 * res_amb[k].mean() for k in ks]
ax.bar(ks, vals, color=[GREY] + [AMB] * (len(ks) - 1)); ax.set_ylabel("canonical pose changes (%)"); ax.set_ylim(0, max(vals) * 1.25)
ax.set_title("PCA pose is unstable under perturbation, not under exact rotation")
plt.setp(ax.get_xticklabels(), rotation=25); fig.tight_layout(); fig.savefig(f"{OUT}/pose_ambiguity.png", dpi=160); plt.close(fig)
print("pose instability", {k: round(v["overall"], 3) for k, v in summary.items()})


# ---------- 4. pipeline diagram
def box(ax, x, y, w, h, text, fc, tc="white", fs=10.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec="none"))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", color=tc, fontsize=fs, wrap=True)

def arrow(ax, x0, y0, x1, y1):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=14, color=GREY, lw=1.4))

fig, ax = plt.subplots(figsize=(13.6, 3.6)); ax.set_xlim(0, 13.6); ax.set_ylim(0, 3.6); ax.axis("off")
items = [("Procedural\nparticle\ngenerator", DEEP), ("40,000 clean\npoint clouds\n(5 classes)", TEAL), ("CT-artifact\ncorruptions\n(5 families)", RED),
         ("PCA canonical\npose +\nsign poses", AMB), ("Point branch\n+ feature\nbranch", TEAL), ("Class\nprobabilities", DEEP), ("Conformal\nset / abstain", AMB)]
w = 1.55; gap = 0.33
for k, (t, c) in enumerate(items):
    x = 0.2 + k * (w + gap); box(ax, x, 1.1, w, 1.5, t, c, fs=10.5)
    if k: arrow(ax, x - gap + 0.02, 1.85, x - 0.02, 1.85)
ax.text(6.8, 0.45, "train: clean + corrupted copies        test: clean + 10 held-out corrupted sets", ha="center", color=GREY, fontsize=11)
fig.savefig(f"{OUT}/pipeline.png", dpi=160, bbox_inches="tight"); plt.close(fig)

# ---------- 5. architecture diagram
fig, ax = plt.subplots(figsize=(13, 4.6)); ax.set_xlim(0, 13); ax.set_ylim(0, 4.6); ax.axis("off")
box(ax, 0.2, 2.9, 1.7, 1.0, "256 points\n(x, y, z)", DEEP)
box(ax, 2.3, 2.9, 1.7, 1.0, "PCA canonical\nframe\n+ sign pose", AMB, fs=10)
box(ax, 4.4, 2.9, 1.9, 1.0, "shared MLP\n3-64-128-256\n(per point)", TEAL, fs=10)
box(ax, 6.7, 2.9, 1.5, 1.0, "max-pool\n(256-d)", TEAL)
box(ax, 0.2, 0.7, 1.7, 1.0, "24 shape\nfeatures\n(PCA, radial, hull, D2)", DEEP, fs=9.5)
box(ax, 2.3, 0.7, 1.7, 1.0, "standardise\n+ clip", GREY)
box(ax, 4.4, 0.7, 1.9, 1.0, "dense 24-64\n(64-d)", TEAL, fs=10)
box(ax, 8.7, 1.8, 1.5, 1.0, "concat\n(320-d)", AMB)
box(ax, 10.5, 1.8, 1.4, 1.0, "MLP\n128-5", TEAL)
box(ax, 12.0, 1.8, 0.9, 1.0, "softmax", DEEP, fs=9.5)
for (a, b_, c, d) in [(1.9, 3.4, 2.3, 3.4), (4.0, 3.4, 4.4, 3.4), (6.3, 3.4, 6.7, 3.4), (1.9, 1.2, 2.3, 1.2), (4.0, 1.2, 4.4, 1.2),
                      (8.2, 3.2, 8.7, 2.5), (6.3, 1.2, 8.7, 2.0), (10.2, 2.3, 10.5, 2.3), (11.9, 2.3, 12.0, 2.3)]:
    arrow(ax, a, b_, c, d)
ax.text(4.4, 4.25, "test time: average over the 4 proper sign poses (TTA)", color=AMB, fontsize=11, ha="left")
fig.savefig(f"{OUT}/architecture.png", dpi=160, bbox_inches="tight"); plt.close(fig)

# ---------- 6. generator parameter table figure (class overview)
fig, ax = plt.subplots(figsize=(11, 3.2)); ax.axis("off")
rows_ = [["rounded", "near-sphere ellipsoid", "axes 0.7-1.0", "low-amplitude bumps"],
         ["elongated", "prolate ellipsoid", "aspect 1.25-2.6", "low-amplitude bumps"],
         ["platy", "oblate ellipsoid", "thickness 0.3-0.7", "low-amplitude bumps"],
         ["angular", "random convex hull", "14-44 vertices", "flat facets, sharp edges"],
         ["irregular", "ellipsoid + radial field", "5-9 waves, amp 0.11", "rough, bumpy surface"]]
tb = ax.table(cellText=rows_, colLabels=["class", "base shape", "key parameter", "surface"], loc="center", cellLoc="left")
tb.auto_set_font_size(False); tb.set_fontsize(12); tb.scale(1, 1.8)
for (r, c), cell in tb.get_celld().items():
    cell.set_edgecolor("#D9E3E5")
    if r == 0: cell.set_facecolor(DEEP); cell.get_text().set_color("white")
fig.savefig(f"{OUT}/class_table.png", dpi=160, bbox_inches="tight"); plt.close(fig)
print("static figures done")
