"""
Corruption-augmentation bank for training (the benchmark TEST sets use different seeds and fixed severities).
For every training particle, K random corrupted copies with random family and a continuous random severity
drawn from the ranges below (which bracket, but are not limited to, the two benchmark severities).
Stores 256-point (or fewer, resampled to 256) float16 clouds and the 24 features of the full corrupted cloud.
"""
import sys
from multiprocessing import Pool
import numpy as np
import corruptions as cr
import baselines as b

RANGES = {"noise": (0.01, 0.09), "sparse": (28, 160), "zblur": (0.02, 0.13), "occlusion": (0.05, 0.40), "voxel": (8, 24)}


def level(fam, rng):
    lo, hi = RANGES[fam]
    if fam == "sparse":
        return int(np.exp(rng.uniform(np.log(lo), np.log(hi))))
    if fam == "voxel":
        return float(rng.uniform(lo, hi))
    return float(rng.uniform(lo, hi))


def work(args):
    X, seed, families = args
    rng = np.random.default_rng(seed)
    outX = np.zeros((len(X), 256, 3), np.float16); outF = np.zeros((len(X), 24)); fams = np.zeros(len(X), np.int8)
    for i, x in enumerate(X):
        k = int(rng.integers(0, len(families))); fam = families[k]
        c = cr.corrupt_one(x.astype(np.float32), fam, level(fam, rng), rng)
        try: outF[i] = b.features(c.astype(np.float64))
        except Exception: outF[i] = np.nan
        outX[i] = c[rng.choice(len(c), 256, replace=len(c) < 256)]
        fams[i] = cr.FAMILIES.index(fam)
    return outX, outF, fams


def build(X, K, seed, families, procs=2, chunk=500):
    jobs = []; ss = np.random.SeedSequence(seed)
    for k in range(K):
        for s in range(0, len(X), chunk):
            jobs.append((X[s:s + chunk], ss.spawn(1)[0], families))
    with Pool(procs) as p:
        res = p.map(work, jobs)
    n_chunks = (len(X) + chunk - 1) // chunk
    Xs, Fs, fm = [], [], []
    for k in range(K):
        part = res[k * n_chunks:(k + 1) * n_chunks]
        Xs.append(np.concatenate([r[0] for r in part])); Fs.append(np.concatenate([r[1] for r in part])); fm.append(np.concatenate([r[2] for r in part]))
    return np.stack(Xs, 1), np.stack(Fs, 1), np.stack(fm, 1)   # (N,K,256,3), (N,K,24), (N,K)


if __name__ == "__main__":
    # holdout family option: python build_train_bank.py [holdout_family]
    fams = [f for f in cr.FAMILIES if f != (sys.argv[1] if len(sys.argv) > 1 else None)]
    tag = "" if len(sys.argv) < 2 else "_no_" + sys.argv[1]
    tr = np.load("data_large/training data/train.npz"); va = np.load("data_large/training data/val.npz")
    Xb, Fb, fm = build(tr["points"], 2, 11, fams)
    np.savez_compressed(f"results/train_bank{tag}.npz", X=Xb, F=Fb, fam=fm)
    print("train bank", Xb.shape, "nan feature rows", int(np.isnan(Fb).any(2).sum()), flush=True)
    Xv, Fv, fv = build(va["points"], 1, 12, fams)
    np.savez_compressed(f"results/val_bank{tag}.npz", X=Xv, F=Fv, fam=fv)
    print("val bank", Xv.shape)
