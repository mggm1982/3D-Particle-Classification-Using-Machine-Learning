"""
CT-artifact corruption benchmark for single-particle point clouds ("ParticleCT-C").

Five corruption families, each with two severities, applied to clean test clouds in the
scanner frame (the particle is already randomly oriented, so the scan axis is arbitrary
relative to the particle). After corruption the cloud is re-centred and re-scaled to the
unit sphere, exactly as a real pipeline would do before classification.

  noise      : extra isotropic Gaussian noise, sigma 0.04 / 0.08   (reconstruction noise)
  sparse     : random subsample to 96 / 32 points                  (low point density)
  zblur      : extra Gaussian noise on the scan (z) axis only, sigma 0.06 / 0.12 (anisotropic resolution)
  occlusion  : remove points beyond a random cutting plane, ~15% / ~35% of the points (clipped / touching particles)
  voxel      : snap points to a voxel grid of 20 / 10 voxels across the unit-sphere diameter (coarse CT voxels)

Severity 1 is "mild" and severity 2 is "strong". Models are trained on clean data only,
except where a result explicitly says corruption-augmented.
"""
import numpy as np

FAMILIES = ["noise", "sparse", "zblur", "occlusion", "voxel"]
LEVELS = {
    "noise": [0.04, 0.08],
    "sparse": [96, 32],
    "zblur": [0.06, 0.12],
    "occlusion": [0.15, 0.35],
    "voxel": [20, 10],
}


def renorm(P):
    P = P - P.mean(0)
    return P / max(np.linalg.norm(P, axis=1).max(), 1e-9)


def corrupt_one(P, family, level, rng):
    """P: (N,3) float32. Returns corrupted (M,3) re-normalised cloud."""
    if family == "noise":
        Q = P + rng.normal(scale=level, size=P.shape)
    elif family == "sparse":
        Q = P[rng.choice(len(P), int(level), replace=False)]
    elif family == "zblur":
        Q = P.copy(); Q[:, 2] += rng.normal(scale=level, size=len(P))
    elif family == "occlusion":
        d = rng.normal(size=3); d /= np.linalg.norm(d)
        proj = P @ d
        thr = np.quantile(proj, 1.0 - level)
        keep = proj <= thr
        Q = P[keep]
    elif family == "voxel":
        h = 2.0 / level
        Q = (np.floor(P / h) + 0.5) * h
    else:
        raise ValueError(family)
    return renorm(Q.astype(np.float64)).astype(np.float32)


def corrupt_set(X, family, sev, seed):
    """X: (B,N,3). Returns list of arrays (some families change N; all clouds in a set share N except occlusion)."""
    rng = np.random.default_rng([seed, FAMILIES.index(family), sev])
    lvl = LEVELS[family][sev]
    out = [corrupt_one(x.astype(np.float32), family, lvl, rng) for x in X]
    return out


def to_fixed(clouds, n, rng):
    """Resample a list of variable-size clouds to exactly n points (with replacement if fewer)."""
    out = np.zeros((len(clouds), n, 3), np.float32)
    for i, c in enumerate(clouds):
        idx = rng.choice(len(c), n, replace=len(c) < n)
        out[i] = c[idx]
    return out
