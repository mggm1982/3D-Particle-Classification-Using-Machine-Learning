"""
Project 55 (extended) - large synthetic particle dataset, v2.
40,000 particles (8,000 per class), 1,024 surface points each, 5 morphology classes.
Reuses the particle generators of generate_dataset.py. New seed (7) and reproducible
per-chunk seeding (SeedSequence), so the result is identical regardless of worker count.

Splits (by particle ID, stratified): 70% train / 10% val / 10% calibration / 10% test.
  - val        : model selection
  - calibration: conformal prediction thresholds only (never used for training)
  - test       : reported once
Stored as float16 (unit-sphere coordinates, error < 1e-3, far below the 0.02 noise).
"""
import json, os, sys
from multiprocessing import Pool
import numpy as np
import generate_dataset as g

N_PER_CLASS = 8000
N_POINTS = 1024
SEED = 7
CHUNK = 200


def job(args):
    cls, chunk, seq = args
    rng = np.random.default_rng(seq)
    return cls, chunk, np.stack([g.make_particle(cls, N_POINTS, rng) for _ in range(CHUNK)])


if __name__ == "__main__":
    n_cls = len(g.CLASS_NAMES)
    root = np.random.SeedSequence(SEED)
    n_chunks = N_PER_CLASS // CHUNK
    seqs = root.spawn(n_cls * n_chunks)
    jobs = [(c, k, seqs[c * n_chunks + k]) for c in range(n_cls) for k in range(n_chunks)]
    X = np.zeros((n_cls * N_PER_CLASS, N_POINTS, 3), np.float16)
    y = np.repeat(np.arange(n_cls), N_PER_CLASS).astype(np.int64)
    with Pool(2) as p:
        for i, (c, k, arr) in enumerate(p.imap_unordered(job, jobs)):
            s = c * N_PER_CLASS + k * CHUNK
            X[s:s + CHUNK] = arr.astype(np.float16)
            if i % 20 == 0:
                print(f"{i}/{len(jobs)}", flush=True)
    rng = np.random.default_rng(SEED + 1)
    split = np.empty(len(y), dtype="<U5")
    for c in range(n_cls):
        idx = rng.permutation(np.where(y == c)[0])
        n = len(idx); a, b, d = int(.7 * n), int(.8 * n), int(.9 * n)
        split[idx[:a]] = "train"; split[idx[a:b]] = "val"; split[idx[b:d]] = "cal"; split[idx[d:]] = "test"
    out = "data_large"
    for name, folder in [("train", "training data"), ("val", "training data"), ("cal", "training data"), ("test", "testing data")]:
        os.makedirs(os.path.join(out, folder), exist_ok=True)
        m = split == name
        np.savez_compressed(os.path.join(out, folder, f"{name}.npz"), points=X[m], labels=y[m], particle_ids=np.where(m)[0])
    meta = dict(seed=SEED, n_per_class=N_PER_CLASS, n_points=N_POINTS, class_names=g.CLASS_NAMES,
                counts={s: int((split == s).sum()) for s in ["train", "val", "cal", "test"]})
    json.dump(meta, open(os.path.join(out, "dataset_info.json"), "w"), indent=2)
    print(meta)
