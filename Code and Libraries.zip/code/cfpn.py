"""
CF-PointNet: PCA-canonical, feature-fused PointNet with sign-ambiguity test-time averaging.
Pure NumPy, manual back-propagation (PyTorch is not available in the build environment).

Variants (all share the same per-point shared MLP 3-64-128-256 + max-pool + MLP head):
  mode="rot"  : raw points, random 3D rotation augmentation     (PointNet baseline)
  mode="pca"  : PCA-canonical frame (axes sorted by variance, signs fixed by skewness, proper rotation),
                random sign-flip augmentation (the 4 proper sign poses) during training;
                optional 4-pose test-time averaging (TTA)        (PCA-PointNet)
  fused=True  : the 24 rotation-invariant geometric features pass through a small branch
                (24-64, ReLU) and are concatenated to the max-pooled embedding  (CF-PointNet = pca + fused)
"""
import json, os, time, argparse
import numpy as np

SIGN_POSES = np.array([[1, 1, 1], [-1, 1, -1], [1, -1, -1], [-1, -1, 1]], np.float32)  # det = +1
D_FEAT = 24
FEATURE_NAMES = ["pca_l1", "pca_l2", "pca_l3", "elongation", "flatness", "sphericity_axes",
    "r_mean", "r_std", "r_skew", "r_kurt", "r_min", "r_max", "r_p10", "r_p90",
    "hull_vol", "hull_area", "compactness", "hull_solidity_proxy", "n_hull_facets", "normal_var",
    "d2_mean", "d2_std", "d2_p10", "d2_p90"]
HULL = {"hull_vol", "hull_area", "compactness", "hull_solidity_proxy", "n_hull_facets", "normal_var"}
ROBUST_IDX = [i for i, n in enumerate(FEATURE_NAMES) if n not in HULL]   # 18 features: PCA, radial, D2


def feat_idx(kind):
    return ROBUST_IDX if kind == "robust" else list(range(D_FEAT))


# ---------------------------------------------------------------- geometry
def pca_canon(X):
    """X (B,N,3) -> canonical coordinates (B,N,3) in a right-handed PCA frame with skewness-fixed signs."""
    Xc = X - X.mean(1, keepdims=True)
    cov = np.einsum("bni,bnj->bij", Xc, Xc) / X.shape[1]
    w, V = np.linalg.eigh(cov.astype(np.float64))        # ascending
    V = V[:, :, ::-1].copy()                              # descending variance
    det = np.linalg.det(V)
    V[:, :, 2] *= np.where(det < 0, -1.0, 1.0)[:, None]  # proper rotation
    C = np.einsum("bni,bij->bnj", Xc, V.astype(np.float32))
    sk = np.sign((C ** 3).mean(1))                        # (B,3)
    sk[sk == 0] = 1
    s0, s1 = sk[:, 0], sk[:, 1]
    S = np.stack([s0, s1, s0 * s1], 1).astype(np.float32)  # keeps determinant +1
    return C * S[:, None, :]


def rand_rot(B, rng):
    q, r = np.linalg.qr(rng.normal(size=(B, 3, 3)))
    q = q * np.sign(np.diagonal(r, axis1=1, axis2=2))[:, None, :]
    q[np.linalg.det(q) < 0, :, 0] *= -1          # proper rotations only (det = +1), no reflections
    return q.astype(np.float32)


# ---------------------------------------------------------------- network
def init(rng, fused, d_feat=D_FEAT):
    P = {}
    sizes = [("1", 3, 64), ("2", 64, 128), ("3", 128, 256)]
    head_in = 256 + (64 if fused else 0)
    sizes += [("4", head_in, 128), ("5", 128, 5)]
    if fused:
        sizes += [("f", d_feat, 64)]
    for k, a, b in sizes:
        P["W" + k] = (rng.normal(size=(a, b)) * np.sqrt(2.0 / a)).astype(np.float32)
        P["b" + k] = np.zeros(b, np.float32)
    return P


def forward(P, X, F=None, cache=False):
    B, N, _ = X.shape
    x = X.reshape(B * N, 3)
    h1 = np.maximum(x @ P["W1"] + P["b1"], 0)
    h2 = np.maximum(h1 @ P["W2"] + P["b2"], 0)
    h3 = np.maximum(h2 @ P["W3"] + P["b3"], 0)
    h3r = h3.reshape(B, N, -1)
    arg = h3r.argmax(1)
    g = np.take_along_axis(h3r, arg[:, None, :], 1)[:, 0, :]
    if "Wf" in P:
        u = np.maximum(F @ P["Wf"] + P["bf"], 0)
        hin = np.concatenate([g, u], 1)
    else:
        u = None; hin = g
    f = np.maximum(hin @ P["W4"] + P["b4"], 0)
    logits = f @ P["W5"] + P["b5"]
    if cache:
        return logits, (x, h1, h2, h3, arg, g, u, hin, f, F)
    return logits


def backward(P, cache, logits, y):
    x, h1, h2, h3, arg, g, u, hin, f, F = cache
    B = len(y); N = h3.shape[0] // B
    p = np.exp(logits - logits.max(1, keepdims=True)); p /= p.sum(1, keepdims=True)
    loss = -np.log(p[np.arange(B), y] + 1e-9).mean()
    d = p.copy(); d[np.arange(B), y] -= 1; d /= B
    G = {"W5": f.T @ d, "b5": d.sum(0)}
    df = (d @ P["W5"].T) * (f > 0)
    G["W4"] = hin.T @ df; G["b4"] = df.sum(0)
    dh = df @ P["W4"].T
    dg = dh[:, :256]
    if u is not None:
        du = dh[:, 256:] * (u > 0)
        G["Wf"] = F.T @ du; G["bf"] = du.sum(0)
    dh3 = np.zeros((B, N, 256), np.float32)
    dh3[np.arange(B)[:, None], arg, np.arange(256)[None, :]] = dg
    dh3 = dh3.reshape(B * N, -1) * (h3 > 0)
    G["W3"] = h2.T @ dh3; G["b3"] = dh3.sum(0)
    dh2 = (dh3 @ P["W3"].T) * (h2 > 0)
    G["W2"] = h1.T @ dh2; G["b2"] = dh2.sum(0)
    dh1 = (dh2 @ P["W2"].T) * (h1 > 0)
    G["W1"] = x.T @ dh1; G["b1"] = dh1.sum(0)
    return loss, G


def softmax(l):
    p = np.exp(l - l.max(1, keepdims=True)); return p / p.sum(1, keepdims=True)


# ---------------------------------------------------------------- inference
def predict_proba(P, X, F=None, mode="pca", tta=True, bs=200):
    """X (B,N,3) raw (uncanonicalised) clouds. Returns (B,5) class probabilities."""
    out = []
    for i in range(0, len(X), bs):
        xb = X[i:i + bs].astype(np.float32)
        fb = None if F is None else F[i:i + bs]
        if mode == "pca":
            C = pca_canon(xb)
            if tta:
                pr = sum(softmax(forward(P, C * s, fb)) for s in SIGN_POSES) / 4.0
            else:
                pr = softmax(forward(P, C, fb))
        else:
            pr = softmax(forward(P, xb, fb))
        out.append(pr)
    return np.concatenate(out)


# ---------------------------------------------------------------- features
class FeatScaler:
    def __init__(self, F):
        self.mu = np.nanmean(F, 0); self.sd = np.nanstd(F, 0) + 1e-9

    def __call__(self, F):
        F = np.where(np.isnan(F), self.mu, F)
        return np.clip((F - self.mu) / self.sd, -6, 6).astype(np.float32)


# ---------------------------------------------------------------- training
def train(args):
    rng = np.random.default_rng(args.seed)
    z = np.load("results/features_large.npz")
    tr = np.load("data_large/training data/train.npz"); va = np.load("data_large/training data/val.npz")
    Xtr, ytr = tr["points"], tr["labels"]; yva = va["labels"]
    fi = feat_idx(args.feats)
    sc = FeatScaler(z["F_train"][:, fi])
    Ftr, Fva = sc(z["F_train"][:, fi]), sc(z["F_val"][:, fi])
    fused = bool(args.fused)
    P = init(rng, fused, len(fi))
    m = {k: np.zeros_like(v) for k, v in P.items()}; v = {k: np.zeros_like(x) for k, x in P.items()}
    steps = len(Xtr) // args.bs; total = steps * args.epochs; t = 0
    best, bestP, hist = -1, None, dict(train_loss=[], val_acc=[])
    sub_va = np.random.default_rng(123).choice(1024, args.npts, replace=False)
    Xva_s = va["points"][:, sub_va].astype(np.float32)
    if args.aug:
        tag = "" if not args.holdout else "_no_" + args.holdout
        bk = np.load(f"results/train_bank{tag}.npz"); Xb, Fb = bk["X"], sc(bk["F"].reshape(-1, 24)[:, fi]).reshape(len(Xtr), 2, len(fi))
        vb = np.load(f"results/val_bank{tag}.npz"); Xvb = vb["X"][:, 0].astype(np.float32); Fvb = sc(vb["F"][:, 0][:, fi])
        Xval_all = np.concatenate([Xva_s, Xvb]); Fval_all = np.concatenate([Fva, Fvb]); yval_all = np.concatenate([yva, yva])
    else:
        Xval_all, Fval_all, yval_all = Xva_s, Fva, yva
    for ep in range(args.epochs):
        t0 = time.time(); perm = rng.permutation(len(Xtr)); tot = 0.0
        for i in range(steps):
            idx = perm[i * args.bs:(i + 1) * args.bs]
            pts = np.zeros((len(idx), args.npts, 3), np.float32); fb = Ftr[idx].copy()
            use_b = (rng.random(len(idx)) < args.aug_frac) if args.aug else np.zeros(len(idx), bool)
            for r, j in enumerate(idx):
                if use_b[r]:
                    k = rng.integers(0, 2); pts[r] = Xb[j, k][rng.choice(256, args.npts, replace=False)] if args.npts < 256 else Xb[j, k]
                    fb[r] = Fb[j, k]
                else:
                    pts[r] = Xtr[j][rng.choice(1024, args.npts, replace=False)]
                    pts[r] += 0.005 * rng.normal(size=(args.npts, 3)).astype(np.float32)
            if args.mode == "pca":
                C = pca_canon(pts)
                if not args.nosignaug:
                    C = C * SIGN_POSES[rng.integers(0, 4, len(idx))][:, None, :]
                pts = C
            else:
                pts = np.einsum("bnk,bjk->bnj", pts, rand_rot(len(idx), rng))
            logits, cache = forward(P, pts, fb if fused else None, cache=True)
            loss, G = backward(P, cache, logits, ytr[idx]); tot += loss; t += 1
            lr = args.lr * 0.5 * (1 + np.cos(np.pi * t / total))
            for k in P:
                m[k] = 0.9 * m[k] + 0.1 * G[k]; v[k] = 0.999 * v[k] + 0.001 * G[k] ** 2
                P[k] -= (lr * (m[k] / (1 - 0.9 ** t)) / (np.sqrt(v[k] / (1 - 0.999 ** t)) + 1e-8)).astype(np.float32)
        pr = predict_proba(P, Xval_all, Fval_all if fused else None, args.mode, tta=False)
        va_acc = float((pr.argmax(1) == yval_all).mean())
        hist["train_loss"].append(float(tot / steps)); hist["val_acc"].append(va_acc)
        if va_acc > best:
            best = va_acc; bestP = {k: x.copy() for k, x in P.items()}
        print(f"[{args.name}] epoch {ep+1}/{args.epochs} loss {tot/steps:.4f} val {va_acc:.4f} ({time.time()-t0:.0f}s)", flush=True)
    os.makedirs("results/models", exist_ok=True)
    np.savez(f"results/models/{args.name}.npz", **bestP)
    json.dump(dict(name=args.name, mode=args.mode, fused=fused, seed=args.seed, epochs_run=len(hist["val_acc"]),
                   best_val=best, npts=args.npts, hist=hist, nosignaug=bool(args.nosignaug), aug=bool(args.aug),
                   feats=args.feats, holdout=args.holdout),
              open(f"results/models/{args.name}.json", "w"), indent=1)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True); ap.add_argument("--mode", default="pca", choices=["rot", "pca"])
    ap.add_argument("--fused", type=int, default=0); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=20); ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--npts", type=int, default=256); ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--nosignaug", type=int, default=0)
    ap.add_argument("--aug", type=int, default=0); ap.add_argument("--aug_frac", type=float, default=0.75)
    ap.add_argument("--feats", default="all", choices=["all", "robust"]); ap.add_argument("--holdout", default="")
    a = ap.parse_args(); a.t_start = time.time()
    train(a)
