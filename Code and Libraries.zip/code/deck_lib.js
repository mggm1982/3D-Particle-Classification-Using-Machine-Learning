// Shared helpers for the extended deck (Project 55).
const pptxgen = require("pptxgenjs");

const DK = "17262F", TEAL = "1F8A83", AMB = "E39A2D", PALE = "EDF3F4", MUT = "5B6E75", DEEP = "0F3D47", RED = "D2603F";

function makePres() {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5
  pres.theme = { headFontFace: "Cambria", bodyFontFace: "Calibri" };
  pres.title = "Corruption-robust 3D particle morphology classification";
  pres.defineSlideMaster({ title: "DARK", background: { color: DEEP }, objects: [],
    slideNumber: { x: 12.4, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: "9FC2C6" } });
  pres.defineSlideMaster({ title: "LIGHT", background: { color: "FFFFFF" }, objects: [],
    slideNumber: { x: 12.4, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: "6B7F86" } });
  return pres;
}

const L = (pres) => {
  const H = {};
  H.title = (s, text, color) => s.addText(text, { x: 0.6, y: 0.4, w: 12.1, h: 0.9, fontFace: "Cambria", fontSize: 32, bold: true,
    color: color || DK, margin: 0, valign: "top", isTextBox: true, objectName: "Title" });
  H.bullets = (s, items, o) => {
    const arr = items.map((t, i) => ({ text: t, options: { bullet: { indent: 16 }, breakLine: i < items.length - 1, paraSpaceAfter: 9 } }));
    s.addText(arr, Object.assign({ fontFace: "Calibri", fontSize: 19, color: DK, valign: "top", margin: 0, isTextBox: true }, o, { fontSize: Math.round(((o && o.fontSize) || 19) * 1.2) }));
  };
  H.card = (s, x, y, w, h, head, body, o = {}) => {
    s.addShape(pres.ShapeType.roundRect, { x, y, w, h, rectRadius: 0.08, fill: { color: o.fill || PALE }, line: { color: o.fill || PALE } });
    s.addText(head, { x: x + 0.25, y: y + 0.18, w: w - 0.5, h: 0.45, fontFace: "Cambria", fontSize: o.hsize || 19, bold: true,
      color: o.headColor || TEAL, margin: 0, isTextBox: true });
    s.addText(body, { x: x + 0.25, y: y + 0.72, w: w - 0.5, h: h - 0.9, fontFace: "Calibri", fontSize: Math.round((o.size || 17) * 1.22),
      color: o.bodyColor || DK, margin: 0, valign: "top", isTextBox: true });
  };
  H.img = (s, path, x, y, w, h) => {
    const b = require("fs").readFileSync(path); const iw = b.readUInt32BE(16), ih = b.readUInt32BE(20);
    const r = Math.min(w / iw, h / ih); const ww = iw * r, hh = ih * r;
    s.addImage({ path, x: x + (w - ww) / 2, y: y + (h - hh) / 2, w: ww, h: hh });
  };
  H.dark = (o = {}) => Object.assign({ fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF" }, o);
  H.src = (s, text) => s.addText(text, { x: 0.6, y: 6.95, w: 11.6, h: 0.3, fontSize: 11, color: MUT, margin: 0, isTextBox: true });
  H.slide = (notes, dark) => { const s = pres.addSlide({ masterName: dark ? "DARK" : "LIGHT" }); if (notes) s.addNotes(notes); return s; };
  H.divider = (num, text, sub, notes) => {
    const s = H.slide(notes, true);
    s.addText(String(num).padStart(2, "0"), { x: 0.8, y: 1.6, w: 3, h: 1.6, fontFace: "Cambria", fontSize: 88, bold: true, color: AMB, margin: 0, isTextBox: true });
    s.addText(text, { x: 0.8, y: 3.4, w: 11.5, h: 1.1, fontFace: "Cambria", fontSize: 44, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
    s.addText(sub, { x: 0.8, y: 4.6, w: 11, h: 0.9, fontSize: 20, color: "BFE0DC", margin: 0, isTextBox: true, valign: "top" });
    return s;
  };
  H.table = (s, header, rows, o) => {
    const hdr = header.map((t) => ({ text: t, options: { bold: true, color: "FFFFFF", fill: { color: DEEP }, fontFace: "Calibri", fontSize: o.fs || 14, align: "left", valign: "middle" } }));
    const body = rows.map((r, i) => r.map((t, j) => ({ text: String(t), options: { color: DK, fill: { color: i % 2 ? "FFFFFF" : PALE }, fontFace: "Calibri", fontSize: o.fs || 14, align: j ? (o.align || "left") : "left", valign: "middle", bold: o.boldFirst && j === 0 } })));
    s.addTable([hdr, ...body], { x: o.x, y: o.y, w: o.w, colW: o.colW, rowH: o.rowH || 0.42, border: { type: "solid", color: "D9E3E5", pt: 0.5 }, margin: [0.04, 0.1, 0.04, 0.1] });
  };
  H.stat = (s, x, y, w, h, big, label, dark) => {
    s.addShape(pres.ShapeType.roundRect, { x, y, w, h, rectRadius: 0.08, fill: { color: dark ? DEEP : PALE }, line: { color: dark ? DEEP : PALE } });
    s.addText(big, { x: x + 0.2, y: y + 0.12, w: w - 0.4, h: h * 0.55, fontFace: "Cambria", fontSize: 40, bold: true, color: dark ? "FFFFFF" : TEAL, margin: 0, valign: "middle", isTextBox: true });
    s.addText(label, { x: x + 0.2, y: y + h * 0.62, w: w - 0.4, h: h * 0.32, fontSize: 15, color: dark ? "BFE0DC" : DK, margin: 0, valign: "top", isTextBox: true });
  };
  return H;
};

module.exports = { makePres, L, DK, TEAL, AMB, PALE, MUT, DEEP, RED };
