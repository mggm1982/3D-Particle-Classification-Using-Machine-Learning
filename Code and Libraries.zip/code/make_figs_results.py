"""Result figures from results/summary.json, eval_results.json and saved probabilities."""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

TEAL, AMB, DEEP, GREY, RED, PURP = "#1F8A83", "#E39A2D", "#0F3D47", "#8A9BA1", "#D2603F", "#6B5B7B"
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
OUT = "figs"; os.makedirs(OUT, exist_ok=True)
S = json.load(open("results/summary.json")); R = json.load(open("results/eval_results.json"))
SETS = S["sets"]; SYS = S["systems"]
y = np.load("data_large/testing data/test.npz")["labels"]
NAMES = ["rounded", "elongated", "platy", "angular", "irregular"]
FAMS = ["noise", "sparse", "zblur", "occlusion", "voxel"]
MAIN = "CF-PointNet-A (aug, 24 feats) TTA"

def have(*n): return [k for k in n if k in SYS]

# ---- 1. heatmap
rows = have("RF (clean, 24 feats)", "SVM (clean, 24 feats)", "PointNet (clean, rot-aug)", "PCA-PointNet (clean) TTA", "CF-PointNet (clean, 24 feats) TTA",
            "RF (aug, 24 feats)", "PointNet (aug)", "PCA-PointNet (aug) TTA", "CF-PointNet-R (aug, 18 feats) TTA", MAIN)
M = np.array([[SYS[r]["acc"][s] for s in SETS] for r in rows])
fig, ax = plt.subplots(figsize=(11.5, 5.2))
im = ax.imshow(M, cmap="YlGnBu", vmin=20, vmax=95, aspect="auto")
ax.set_xticks(range(len(SETS))); ax.set_xticklabels(SETS, rotation=40, ha="right"); ax.set_yticks(range(len(rows))); ax.set_yticklabels(rows)
for i in range(len(rows)):
    for j in range(len(SETS)):
        ax.text(j, i, f"{M[i,j]:.0f}", ha="center", va="center", fontsize=9, color="white" if M[i, j] > 62 else "#0F3D47")
ax.set_title("Test accuracy (%) per system and test condition"); plt.colorbar(im, fraction=0.03)
fig.tight_layout(); fig.savefig(f"{OUT}/heatmap.png", dpi=160); plt.close(fig)

# ---- 2. clean vs mean corrupted
rows2 = have("RF (clean, 24 feats)", "SVM (clean, 24 feats)", "PointNet (clean, rot-aug)", "CF-PointNet (clean, 24 feats) TTA", "RF (aug, 24 feats)",
             "PointNet (aug)", "PCA-PointNet (aug) TTA", MAIN)
fig, ax = plt.subplots(figsize=(11, 4.6)); x = np.arange(len(rows2)); w = 0.38
ax.bar(x - w / 2, [SYS[r]["clean"] for r in rows2], w, color=TEAL, label="clean test")
ax.bar(x + w / 2, [SYS[r]["mca"] for r in rows2], w, color=AMB, label="mean of 10 corrupted sets")
for i, r in enumerate(rows2):
    ax.text(i - w / 2, SYS[r]["clean"] + 1, f"{SYS[r]['clean']:.1f}", ha="center", fontsize=9); ax.text(i + w / 2, SYS[r]["mca"] + 1, f"{SYS[r]['mca']:.1f}", ha="center", fontsize=9)
ax.set_xticks(x); ax.set_xticklabels([r.replace(" (", "\n(") for r in rows2], fontsize=8.5); ax.set_ylim(0, 105); ax.set_ylabel("accuracy (%)"); ax.legend(loc="upper left", frameon=False)
fig.tight_layout(); fig.savefig(f"{OUT}/clean_vs_corrupt.png", dpi=160); plt.close(fig)

# ---- 3. per-family robustness curves
show = have("RF (clean, 24 feats)", "PointNet (clean, rot-aug)", "CF-PointNet (clean, 24 feats) TTA", "PointNet (aug)", MAIN)
cols = {"RF (clean, 24 feats)": GREY, "PointNet (clean, rot-aug)": PURP, "CF-PointNet (clean, 24 feats) TTA": RED, "PointNet (aug)": AMB, MAIN: TEAL}
fig, axs = plt.subplots(1, 5, figsize=(15, 3.6), sharey=True)
for a, f in zip(axs, FAMS):
    for r in show:
        a.plot([0, 1, 2], [SYS[r]["acc"]["clean"], SYS[r]["acc"][f + "1"], SYS[r]["acc"][f + "2"]], "-o", color=cols[r], lw=2.4 if r == MAIN else 1.4, label=r)
    a.set_title(f); a.set_xticks([0, 1, 2]); a.set_xticklabels(["clean", "mild", "strong"]); a.set_ylim(15, 100)
axs[0].set_ylabel("accuracy (%)"); fig.legend(*axs[0].get_legend_handles_labels(), loc="lower center", ncol=5, fontsize=9, frameon=False)
fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.savefig(f"{OUT}/family_curves.png", dpi=160); plt.close(fig)

# ---- 4. data scaling (feature models) + deep
sc = R["data_scaling_features"]; ns = sorted(int(k) for k in sc)
fig, ax = plt.subplots(figsize=(7.5, 4.2))
ax.plot(ns, [100 * sc[str(n)]["RF"] for n in ns], "-o", color=TEAL, label="Random Forest (clean)")
ax.plot(ns, [100 * sc[str(n)]["SVM"] for n in ns], "-s", color=AMB, label="SVM (clean)")
ax.set_xscale("log"); ax.set_xlabel("training particles"); ax.set_ylabel("clean test accuracy (%)"); ax.legend(frameon=False); ax.set_ylim(80, 96)
ax.set_title("More clean data saturates near 92-93%")
fig.tight_layout(); fig.savefig(f"{OUT}/data_scaling.png", dpi=160); plt.close(fig)

# ---- 5. ablation bars (mean corrupted accuracy and clean)
abl = [("PCA-PointNet\n(aug) single", "PCA-PointNet (aug) single pose"), ("PCA-PointNet\n(aug) TTA", "PCA-PointNet (aug) TTA"),
       ("CF-A no\nsign-aug, single", "CF-PointNet-A no sign-aug, single"), ("CF-A no\nsign-aug, TTA", "CF-PointNet-A no sign-aug, TTA"),
       ("CF-R (18 feats)\nTTA", "CF-PointNet-R (aug, 18 feats) TTA"), ("CF-A\nsingle pose", "CF-PointNet-A (aug, 24 feats) single pose"),
       ("CF-A (main)\nTTA", MAIN)]
abl = [(a, b) for a, b in abl if b in SYS]
fig, ax = plt.subplots(figsize=(11, 4.4)); x = np.arange(len(abl))
ax.bar(x, [SYS[b]["mca"] for a, b in abl], yerr=[SYS[b]["mca_sd"] for a, b in abl], color=[TEAL if b == MAIN else GREY for a, b in abl], capsize=4)
for i, (a, b) in enumerate(abl): ax.text(i, SYS[b]["mca"] + 1.2, f"{SYS[b]['mca']:.1f}", ha="center", fontsize=10)
ax.set_xticks(x); ax.set_xticklabels([a for a, b in abl], fontsize=9); ax.set_ylabel("mean corrupted accuracy (%)")
lo = min(SYS[b]["mca"] for a, b in abl); ax.set_ylim(max(0, lo - 12), max(SYS[b]["mca"] for a, b in abl) + 6)
fig.tight_layout(); fig.savefig(f"{OUT}/ablation.png", dpi=160); plt.close(fig)

# ---- 6. conformal
C = S["conformal"]; key = "cfa_aug_s0|tta"
if key in C:
    fig, axs = plt.subplots(1, 3, figsize=(15, 4))
    for a, (metric, lab) in zip(axs, [("coverage", "coverage (target 0.90)"), ("mean_set_size", "mean set size"), ("acc_when_accepted", "accuracy when auto-accepted")]):
        xx = np.arange(len(SETS)); a.bar(xx - 0.2, [C[key]["clean_cal"][s][metric] for s in SETS], 0.4, color=GREY, label="clean-calibrated")
        a.bar(xx + 0.2, [C[key]["mix_cal"][s][metric] for s in SETS], 0.4, color=TEAL, label="mix-calibrated")
        a.set_xticks(xx); a.set_xticklabels(SETS, rotation=60, ha="right", fontsize=8); a.set_title(lab)
        if metric == "coverage": a.axhline(0.9, color=RED, ls="--", lw=1); a.set_ylim(0.3, 1.02)
    axs[0].legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(f"{OUT}/conformal.png", dpi=160); plt.close(fig)
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.plot([100 * C[key]["clean_cal"][s]["auto_accept"] for s in SETS], [100 * C[key]["clean_cal"][s]["acc_when_accepted"] for s in SETS], "o", color=GREY, label="clean-calibrated")
    ax.plot([100 * C[key]["mix_cal"][s]["auto_accept"] for s in SETS], [100 * C[key]["mix_cal"][s]["acc_when_accepted"] for s in SETS], "s", color=TEAL, label="mix-calibrated")
    ax.set_xlabel("auto-accept rate (%)"); ax.set_ylabel("accuracy of accepted (%)"); ax.legend(frameon=False); ax.set_title("Accept rate vs accuracy, one point per test set")
    fig.tight_layout(); fig.savefig(f"{OUT}/selective.png", dpi=160); plt.close(fig)

# ---- 7. confusion matrices of main model (clean and strong noise) + per-class recall
def cm_plot(p, title, path):
    cm = confusion_matrix(y, p.argmax(1)); n = cm / cm.sum(1, keepdims=True)
    fig, ax = plt.subplots(figsize=(4.6, 4.2)); ax.imshow(n, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(5)); ax.set_xticklabels(NAMES, rotation=40, ha="right"); ax.set_yticks(range(5)); ax.set_yticklabels(NAMES)
    for i in range(5):
        for j in range(5): ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=8, color="white" if n[i, j] > .5 else "black")
    ax.set_title(title, fontsize=11); ax.set_xlabel("predicted"); ax.set_ylabel("true"); fig.tight_layout(); fig.savefig(path, dpi=160); plt.close(fig)
pm = "results/probs_cfa_aug_s0_tta.npz"
if os.path.exists(pm):
    P = np.load(pm)
    for s in ["clean", "noise2", "sparse2", "occlusion2"]: cm_plot(P[s], f"CF-PointNet-A, {s}", f"{OUT}/cm_main_{s}.png")
    fig, ax = plt.subplots(figsize=(9, 4)); x = np.arange(5); w = 0.2
    for k, (s, c) in enumerate([("clean", TEAL), ("noise2", AMB), ("sparse2", RED), ("occlusion2", PURP)]):
        rec = [(P[s].argmax(1)[y == c_] == c_).mean() * 100 for c_ in range(5)]; ax.bar(x + (k - 1.5) * w, rec, w, color=c, label=s)
    ax.set_xticks(x); ax.set_xticklabels(NAMES); ax.set_ylabel("per-class recall (%)"); ax.legend(frameon=False, ncol=4, fontsize=9); ax.set_ylim(0, 105)
    fig.tight_layout(); fig.savefig(f"{OUT}/recall_by_class.png", dpi=160); plt.close(fig)

# ---- 8. training curves of main models
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
for nm, c in [("cfa_aug_s0", TEAL), ("cfr_aug_s0", RED), ("pca_aug_s0", AMB), ("rot_aug_s0", PURP), ("cf_s0", GREY)]:
    p = f"results/models/{nm}.json"
    if os.path.exists(p):
        h = json.load(open(p))["hist"]; axs[0].plot(h["train_loss"], color=c, label=nm); axs[1].plot(100 * np.array(h["val_acc"]), color=c, label=nm)
axs[0].set_title("training loss"); axs[1].set_title("validation accuracy (%)"); axs[0].set_xlabel("epoch"); axs[1].set_xlabel("epoch"); axs[1].legend(frameon=False, fontsize=8)
fig.tight_layout(); fig.savefig(f"{OUT}/training_curves.png", dpi=160); plt.close(fig)
print("result figures done")
