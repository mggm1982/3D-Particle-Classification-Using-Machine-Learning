const fs = require("fs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");
const { makePres, L } = require("./deck_lib");
const S = JSON.parse(fs.readFileSync("results/summary.json"));
const THEME = { name: "ParticleCT", headFontFace: "Cambria", bodyFontFace: "Calibri",
  colors: { dk1: "17262F", lt1: "FFFFFF", dk2: "0F3D47", lt2: "EDF3F4", accent1: "1F8A83", accent2: "E39A2D", accent3: "3C6E91", accent4: "D2603F", accent5: "6B5B7B", accent6: "7FA66F", hlink: "1F8A83", folHlink: "6B5B7B" } };
const pres = makePres(); const H = L(pres);
require("./deck_part1")(pres, H, S);
require("./deck_part2")(pres, H, S);
const out = "deliverables/Project55_Extended_Deck.pptx";
(async () => { await pres.writeFile({ fileName: out }); await applyTheme(out, THEME); console.log("slides:", pres.slides.length); })();
