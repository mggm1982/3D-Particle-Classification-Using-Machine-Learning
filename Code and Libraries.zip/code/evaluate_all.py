"""
Evaluate every trained model and the RF/SVM baselines on clean + ParticleCT-C corrupted test sets,
then run conformal abstention analysis. Writes results/eval_results.json and results/probs_<name>.npz.
"""
import glob, json, os, sys
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score
import cfpn
import corruptions as cr

SETS = ["clean"] + [f"{f}{s}" for f in cr.FAMILIES for s in (1, 2)]
ALPHA = 0.1


def macro_f1(y, p): return float(f1_score(y, p, average="macro"))


def load_sets():
    z = np.load("results/corrupt_sets.npz")
    return z


def fit_baselines(Ftr, ytr):
    rf = RandomForestClassifier(n_estimators=300, random_state=0, n_jobs=2).fit(np.nan_to_num(Ftr), ytr)
    sv = make_pipeline(StandardScaler(), SVC(C=10, gamma="scale", random_state=0)).fit(np.nan_to_num(Ftr), ytr)
    return rf, sv


def conformal_lac(p_cal, y_cal, alpha):
    s = 1.0 - p_cal[np.arange(len(y_cal)), y_cal]
    n = len(s); k = int(np.ceil((n + 1) * (1 - alpha)))
    return float(np.sort(s)[min(k, n) - 1])


def conf_eval(p, y, q):
    sets = p >= (1.0 - q)
    cov = float(sets[np.arange(len(y)), y].mean()); size = float(sets.sum(1).mean())
    single = sets.sum(1) == 1
    acc_single = float((p.argmax(1)[single] == y[single]).mean()) if single.any() else float("nan")
    return dict(coverage=cov, mean_set_size=size, auto_accept=float(single.mean()), acc_when_accepted=acc_single,
                abstain=float(1 - single.mean()))


def main():
    Z = load_sets(); y = Z["y"]
    ft = np.load("results/features_large.npz")
    res = {"sets": SETS, "n_test": int(len(y)), "models": {}}

    # ---- baselines (feature-only learners), clean-trained and corruption-augmented
    print("fitting RF / SVM variants ...", flush=True)
    bk = np.load("results/train_bank.npz"); Fb = bk["F"].reshape(-1, 24); yb = np.repeat(ft["y_train"], 2)
    Fall = np.concatenate([ft["F_train"], Fb]); yall = np.concatenate([ft["y_train"], yb])
    mu = np.nanmean(ft["F_train"], 0)
    fill = lambda F: np.where(np.isnan(F), mu, F)
    rob = cfpn.ROBUST_IDX; allidx = list(range(24))
    rs = np.random.default_rng(3); sub_svm = rs.permutation(len(Fall))[:30000]
    def rf_fit(F, y): return RandomForestClassifier(n_estimators=300, random_state=0, n_jobs=2).fit(F, y)
    def sv_fit(F, y): return make_pipeline(StandardScaler(), SVC(C=10, gamma="scale", random_state=0)).fit(F, y)
    specs = [
        ("RandomForest", rf_fit, ft["F_train"], ft["y_train"], allidx),
        ("RandomForest_robustfeats", rf_fit, ft["F_train"], ft["y_train"], rob),
        ("SVM_RBF", sv_fit, ft["F_train"], ft["y_train"], allidx),
        ("RandomForest_aug", rf_fit, Fall, yall, allidx),
        ("RandomForest_aug_robustfeats", rf_fit, Fall, yall, rob),
        ("SVM_RBF_aug_robustfeats", sv_fit, Fall[sub_svm], yall[sub_svm], rob),
    ]
    rf, sv = None, None
    for nm, fit, Ftr_, ytr_, idx_ in specs:
        mdl = fit(fill(Ftr_)[:, idx_], ytr_); r = {}; pr_ = {}
        for s_ in SETS:
            F = ft["F_test"] if s_ == "clean" else Z[f"{s_}_F"]
            pred = mdl.predict(fill(F)[:, idx_]); pr_[s_] = pred; r[s_] = dict(acc=float((pred == y).mean()), f1=macro_f1(y, pred))
        np.savez_compressed(f"results/preds_{nm}.npz", **pr_)
        res["models"][nm] = {"meta": dict(mode="features", aug="aug" in nm, feats="robust" if idx_ is rob else "all"), "runs": {"seed0": r}}
        print(nm, "clean", r["clean"]["acc"], "mean-corrupt", np.mean([r[s_]["acc"] for s_ in SETS[1:]]).round(4), flush=True)
        if nm == "RandomForest": rf = mdl
        if nm == "SVM_RBF": sv = mdl
    # data-scaling curves for the feature models
    rng = np.random.default_rng(0); scal = {}
    for n in [500, 1000, 2500, 5000, 10000, 28000]:
        idx = rng.permutation(len(ft["y_train"]))[:n]
        rf_n, sv_n = fit_baselines(fill(ft["F_train"])[idx], ft["y_train"][idx])
        scal[n] = dict(RF=float((rf_n.predict(fill(ft["F_test"])) == y).mean()),
                       SVM=float((sv_n.predict(fill(ft["F_test"])) == y).mean()))
    res["data_scaling_features"] = scal
    print("scaling", scal, flush=True)

    # ---- calibration inputs
    cal = np.load("data_large/training data/cal.npz")
    sub = np.random.default_rng(999).choice(1024, 256, replace=False)
    Xcal = cal["points"][:, sub].astype(np.float32); ycal = cal["labels"]

    # ---- neural models
    names = sorted(os.path.basename(p)[:-5] for p in glob.glob("results/models/*.json"))
    conf_all = {}
    for nm in names:
        meta = json.load(open(f"results/models/{nm}.json")); W = np.load(f"results/models/{nm}.npz")
        P = {k: W[k] for k in W.files}; fused = meta["fused"]; mode = meta["mode"]
        fi = cfpn.feat_idx(meta.get("feats", "all")); sc = cfpn.FeatScaler(ft["F_train"][:, fi])
        variants = [("tta", True), ("single", False)] if mode == "pca" else [("plain", False)]
        for vname, tta in variants:
            key = f"{nm}|{vname}"; r = {}; probs = {}
            for s in SETS:
                X = Z["clean_X"] if s == "clean" else Z[f"{s}_X"]; X = X.astype(np.float32)
                F = None
                if fused:
                    F = sc((ft["F_test"] if s == "clean" else Z[f"{s}_F"])[:, fi])
                p = cfpn.predict_proba(P, X, F, mode, tta=tta); probs[s] = p
                pred = p.argmax(1); r[s] = dict(acc=float((pred == y).mean()), f1=macro_f1(y, pred))
            res["models"][key] = {"meta": dict(mode=mode, fused=fused, seed=meta["seed"], best_val=meta["best_val"],
                                               epochs_run=meta["epochs_run"], nosignaug=meta.get("nosignaug", False),
                                               aug=meta.get("aug", False), feats=meta.get("feats", "all"), holdout=meta.get("holdout", "")),
                                  "runs": {"seed0": r}}
            print(key, "clean", r["clean"], "mean-corrupt", np.mean([r[s]["acc"] for s in SETS[1:]]).round(4), flush=True)
            # ---- conformal
            if vname in ("tta", "plain"):
                pc = cfpn.predict_proba(P, Xcal, sc(ft["F_cal"][:, fi]) if fused else None, mode, tta=tta)
                q_clean = conformal_lac(pc, ycal, ALPHA)
                pm, ym = [], []
                for fam in cr.FAMILIES:
                    Xm = Z[f"calmix_{fam}_X"].astype(np.float32); Fm = sc(Z[f"calmix_{fam}_F"][:, fi]) if fused else None
                    pm.append(cfpn.predict_proba(P, Xm, Fm, mode, tta=tta)); ym.append(Z[f"calmix_{fam}_y"])
                q_mix = conformal_lac(np.concatenate(pm), np.concatenate(ym), ALPHA)
                conf_all[key] = dict(q_clean=q_clean, q_mix=q_mix,
                                     clean_cal={s: conf_eval(probs[s], y, q_clean) for s in SETS},
                                     mix_cal={s: conf_eval(probs[s], y, q_mix) for s in SETS})
            np.savez_compressed(f"results/probs_{nm}_{vname}.npz", **{s: probs[s].astype(np.float32) for s in SETS})
    res["conformal"] = conf_all
    json.dump(res, open("results/eval_results.json", "w"), indent=1)
    print("saved eval_results.json")


if __name__ == "__main__":
    main()
