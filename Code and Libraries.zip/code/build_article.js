const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType, AlignmentType,
  SectionType, BorderStyle, ShadingType, VerticalAlign,
} = require("docx");

const base = JSON.parse(fs.readFileSync("results/baseline_metrics.json"));
const pn = JSON.parse(fs.readFileSync("results/pointnet_metrics.json"));
const RF = base.RandomForest, SV = base.SVM_RBF;
const p1 = (x) => (100 * x).toFixed(1);
const recall = (cm) => cm.map((r, i) => (100 * r[i] / r.reduce((a, b) => a + b, 0)).toFixed(1));
const names = ["Rounded", "Elongated", "Platy", "Angular", "Irregular"];
const rRF = recall(RF.confusion_matrix), rSV = recall(SV.confusion_matrix), rPN = recall(pn.confusion_matrix);

const FONT = "Times New Roman";
const T = (text, o = {}) => new TextRun({ text, font: FONT, size: 20, ...o });
const body = (runs) =>
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 100, line: 240 }, indent: { firstLine: 200 },
    children: typeof runs === "string" ? [T(runs)] : runs });
const h1 = (text) =>
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 160, after: 80 }, keepNext: true,
    children: [T(text.toUpperCase(), { size: 18 })] });
const h2 = (text) =>
  new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 80, after: 60 }, keepNext: true,
    children: [T(text, { italics: true })] });
const caption = (text, keep) =>
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120 }, keepNext: !!keep, children: [T(text, { size: 16 })] });
const img = (path, wPx, hPx) =>
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 40 }, keepNext: true,
    children: [new ImageRun({ type: "png", data: fs.readFileSync(path), transformation: { width: wPx, height: hPx },
      altText: { title: path, description: path, name: path } })] });
const ref = (n, text) =>
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 50 }, indent: { left: 360, hanging: 360 },
    children: [T(`[${n}]  ${text}`, { size: 16 })] });

// ---- table ----
const bd = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const borders = { top: bd, bottom: bd, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } };
const cw = [1500, 1240, 1240, 1240];
const cell = (t, i, bold, shade) =>
  new TableCell({ width: { size: cw[i], type: WidthType.DXA }, borders, verticalAlign: VerticalAlign.CENTER,
    margins: { top: 30, bottom: 30, left: 60, right: 60 },
    shading: shade ? { type: ShadingType.CLEAR, fill: "EDEDED", color: "auto" } : undefined,
    children: [new Paragraph({ alignment: i ? AlignmentType.CENTER : AlignmentType.LEFT, children: [T(t, { size: 16, bold })] })] });
const row = (arr, bold, shade) => new TableRow({ children: arr.map((t, i) => cell(t, i, bold, shade)) });
const table = new Table({
  width: { size: 5220, type: WidthType.DXA }, columnWidths: cw,
  rows: [
    row(["Class", "RF", "SVM", "PointNet"], true, true),
    ...names.map((n, i) => row([n, rRF[i], rSV[i], rPN[i]])),
    row(["Accuracy", p1(RF.test_accuracy), p1(SV.test_accuracy), p1(pn.test_accuracy)], true, true),
    row(["Macro-F1", p1(RF.test_macro_f1), p1(SV.test_macro_f1), p1(pn.test_macro_f1)], true, true),
  ],
});

// ---------------- title block (single column) ----------------
const titleBlock = [
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 },
    children: [T("3D Particle Classification Using Machine Learning: PointNet versus Random Forest and SVM on Synthetic Point Clouds", { size: 44 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: [T("Virender", { size: 22 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 },
    children: [T("Enrolment No. 24324027, email: talaniyavirender@gmail.com", { size: 18, italics: true })] }),
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 100 }, indent: { left: 360, right: 360 },
    children: [
      T("Abstract", { bold: true, italics: true, size: 18 }),
      T("—Particle shape controls how powders and granular materials flow, pack and fail, yet sorting thousands of micro-CT particles by eye is slow and subjective. We build a fully synthetic, seeded dataset of 8,000 particle point clouds in five morphology classes (rounded, elongated, platy, angular, irregular) with exact labels, and compare three classifiers on 1,200 held-out particles: a Random Forest and an RBF support vector machine on 24 rotation-invariant geometric features, and a PointNet-style network trained directly on raw points. The SVM and Random Forest reach " +
        `${p1(SV.test_accuracy)}% and ${p1(RF.test_accuracy)}% accuracy (macro-F1 ${p1(SV.test_macro_f1)}% and ${p1(RF.test_macro_f1)}%), and our simplified NumPy PointNet reaches ${p1(pn.test_accuracy)}% (macro-F1 ${p1(pn.test_macro_f1)}%). ` +
        "Errors concentrate among the deliberately overlapping rounded, platy and irregular classes. Results are for synthetic data only and should not be read as real-scanner accuracy.", { bold: true, italics: true, size: 18 }),
    ] }),
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120 }, indent: { left: 360, right: 360 },
    children: [T("Index Terms", { bold: true, italics: true, size: 18 }),
      T("—particle morphology, point cloud classification, PointNet, random forest, support vector machine, synthetic data, micro-CT.", { bold: true, italics: true, size: 18 })] }),
];

// ---------------- body (two columns) ----------------
const bodyContent = [
  h1("I. Introduction"),
  body("Particulate materials such as powders, sands, catalyst pellets and additive-manufacturing feedstock are made of many small grains. Grain shape affects packing density, flowability, permeability and mechanical strength. X-ray micro-computed tomography (micro-CT) captures each grain in three dimensions, but assigning a shape class to thousands of grains by eye is slow and differs between observers."),
  body("This work asks whether a model can assign a morphology class to a single particle from its 3D surface points alone, regardless of orientation or size, and how a deep point-cloud network compares with classical learners on hand-designed features."),
  h2("A. Problem and objectives"),
  body("Given a point cloud of one particle, predict one of five classes: rounded, elongated, platy, angular or irregular. Our objectives are: (1) build a reproducible synthetic dataset with exact labels; (2) train a Random Forest and an SVM on rotation-invariant features; (3) train a PointNet-style network on raw points; (4) compare all three using accuracy, macro-F1 and confusion matrices."),
  h2("B. Why the problem needs solving"),
  body("Manual shape grading does not scale and is subjective. Automatic, repeatable labels support quality control and faster materials research. Synthetic data is attractive because ground truth is exact and no scanner time or manual annotation is needed, which also allows controlled studies of noise and class overlap."),

  h1("II. Theory"),
  h2("A. Feature-based classification"),
  body("Each particle is summarised by numbers that do not change under rotation: eigenvalues of the point covariance matrix (principal component analysis), from which elongation and flatness follow; convex-hull volume, area and a compactness index 36πV²/A³ that equals 1 for a sphere; statistics of the normalised radial distance; the number of hull facets; and the D2 shape distribution, i.e. distances between random point pairs [5]. A Random Forest averages many randomised decision trees [3]; an SVM with a radial basis function kernel learns a maximum-margin non-linear boundary [4]."),
  h2("B. PointNet"),
  body("A point cloud is an unordered set, so a classifier must be invariant to point order. PointNet [1] applies a shared function h to every point, aggregates with a symmetric max operation, and classifies the result: f(P) = g(max_i h(p_i)). Because max is symmetric, permuting the points leaves the output unchanged. Invariance to rotation is not built in and must be learned from rotated examples or provided by alignment networks."),

  h1("III. Previous Work"),
  body("PointNet [1] introduced direct learning on raw point sets, and PointNet++ [2] added hierarchical local grouping to capture fine structure. The ModelNet benchmark from 3D ShapeNets [6] made 3D shape classification a standard task. Classical shape descriptors, notably shape distributions [5], remain strong baselines. Random Forests [3] and SVMs [4] are widely used on tabular descriptors. For CT imaging, open datasets such as the Digital Rocks Portal hold real particulate scans, but they rarely carry per-particle morphology labels, which motivates synthetic generation with exact ground truth. To our knowledge we did not find a prior study using this exact five-class synthetic setup, so we do not claim a direct benchmark comparison."),

  h1("IV. Method"),
  h2("A. Synthetic dataset"),
  body("All particles are generated by code with a fixed seed (42). Each class has 1,600 particles, each represented by 1,024 surface points. Rounded particles are near-spherical (axis scales 0.7–1.0). Elongated particles are prolate ellipsoids (aspect 1.25–2.6). Platy particles are oblate (thickness 0.3–0.7 of the in-plane axes). Angular particles are random convex hulls of 14–44 vertices with mild anisotropy, sampled uniformly by facet area. Irregular particles are ellipsoids with a smooth random radial perturbation. Smooth perturbations of small amplitude are also added to the first three classes. Each cloud is centred, scaled so the farthest point lies on the unit sphere (removing absolute size), randomly rotated, and perturbed with Gaussian surface noise (σ = 0.02). Parameter ranges overlap between classes on purpose; a first, easier version gave the baselines 99.8% and was therefore replaced."),
  img("results/particle_gallery.png", 336, 146),
  caption("Fig. 1. Two example particles per class (columns: rounded, elongated, platy, angular, irregular) in random orientation."),
  body("The split is by particle identity and stratified by class: 5,600 training, 1,200 validation and 1,200 test particles. No particle occurs in more than one set."),
  h2("B. Random Forest and SVM"),
  body("Twenty-four features (Section II-A) are computed per particle. The Random Forest uses 400 trees. The SVM uses an RBF kernel with C = 10 and standardised features. Both are implemented with scikit-learn [8]."),
  h2("C. PointNet"),
  body("Our PointNet is implemented from scratch in NumPy with manual back-propagation, because a deep-learning framework was unavailable in the build environment; the gradients were checked against finite differences. The per-point shared MLP has layers 3–64–128–256 with ReLU, followed by max pooling over points and a 256–128–5 classifier. It omits the alignment networks, batch normalisation and dropout of the original [1]. Training uses 512 randomly drawn points per particle, random rotation and Gaussian jitter (σ = 0.005) as augmentation, softmax cross-entropy, Adam [7] with cosine-decayed learning rate (initial 2×10⁻³), batch size 32 and 60 epochs. The epoch with the best validation accuracy is kept."),
  h2("D. Evaluation"),
  body("Model selection uses only the validation set. The test set is evaluated once. We report accuracy, macro-averaged F1 and confusion matrices."),

  h1("V. Results"),
  body(`On the 1,200 test particles the SVM reaches ${p1(SV.test_accuracy)}% accuracy (macro-F1 ${p1(SV.test_macro_f1)}%), the Random Forest ${p1(RF.test_accuracy)}% (${p1(RF.test_macro_f1)}%) and PointNet ${p1(pn.test_accuracy)}% (${p1(pn.test_macro_f1)}%) (Table I). Chance level is 20%. The SVM and Random Forest differ by 0.1 percentage points, which is not meaningful for one split and one seed. PointNet is about four points lower.`),
  caption("TABLE I. Test-set per-class recall and overall scores (%), 240 test particles per class.", true),
  table,
  new Paragraph({ spacing: { after: 100 }, children: [] }),
  body("Elongated and angular particles are recognised almost perfectly by all models. Nearly all errors are among rounded, platy and irregular particles. PointNet is weakest on irregular particles (72.5% recall), which it most often calls rounded (34 of 240) or platy (21 of 240). The Random Forest ranks the hull facet count, the fraction of points lying on the hull surface and the second PCA eigenvalue highest."),
  img("results/cm_PointNet.png", 250, 225),
  caption("Fig. 2. PointNet confusion matrix on the test set."),
  img("results/pointnet_curves.png", 336, 130),
  caption("Fig. 3. PointNet training loss and validation accuracy per epoch."),

  h1("VI. Conclusion"),
  body(`The classification problem is solved to a useful level on this synthetic benchmark: five shape classes are separated with ${p1(SV.test_accuracy)}% (SVM) and ${p1(RF.test_accuracy)}% (Random Forest) accuracy using 24 rotation-invariant features, and a simplified PointNet reaches ${p1(pn.test_accuracy)}% from raw points with no hand-made features. Here simple geometric features slightly outperformed our PointNet, and the residual errors lie where classes overlap by construction.`),

  h1("VII. Limitations"),
  body("(1) All data are synthetic; no real CT scans were tested, so real-world accuracy is unknown. (2) The PointNet is simplified (no alignment networks, no batch normalisation, 512 points, NumPy implementation) and a full PointNet or PointNet++ may score higher, so the ranking should not be generalised to those architectures. (3) One seed and one split were used, so small differences are within noise. (4) Particles are isolated and already segmented, with no reconstruction artefacts. (5) Class definitions and overlap were chosen by the author and influence the results."),
  h2("Ethical risks and biases"),
  body("The model reflects only the shapes we generated, so it may overstate performance on real material. Design choices (classes, ranges, noise) bias the comparison. Mislabelling could cause defective batches to pass inspection; such a model should support, not replace, human checks, and its confusions should be reported."),
  h2("Reproducibility"),
  body("A fixed seed regenerates the identical dataset; code, training and testing data are provided to the course instructor. No external code or data were used."),

  h1("References"),
  ref(1, "C. R. Qi, H. Su, K. Mo and L. J. Guibas, “PointNet: Deep learning on point sets for 3D classification and segmentation,” in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR), 2017, pp. 652–660."),
  ref(2, "C. R. Qi, L. Yi, H. Su and L. J. Guibas, “PointNet++: Deep hierarchical feature learning on point sets in a metric space,” in Adv. Neural Inf. Process. Syst. (NeurIPS), 2017, pp. 5099–5108."),
  ref(3, "L. Breiman, “Random forests,” Mach. Learn., vol. 45, no. 1, pp. 5–32, 2001."),
  ref(4, "C. Cortes and V. Vapnik, “Support-vector networks,” Mach. Learn., vol. 20, no. 3, pp. 273–297, 1995."),
  ref(5, "R. Osada, T. Funkhouser, B. Chazelle and D. Dobkin, “Shape distributions,” ACM Trans. Graph., vol. 21, no. 4, pp. 807–832, 2002."),
  ref(6, "Z. Wu et al., “3D ShapeNets: A deep representation for volumetric shapes,” in Proc. IEEE CVPR, 2015, pp. 1912–1920."),
  ref(7, "D. P. Kingma and J. Ba, “Adam: A method for stochastic optimization,” in Proc. Int. Conf. Learn. Represent. (ICLR), 2015."),
  ref(8, "F. Pedregosa et al., “Scikit-learn: Machine learning in Python,” J. Mach. Learn. Res., vol. 12, pp. 2825–2830, 2011."),
];

const page = { size: { width: 12240, height: 15840 }, margin: { top: 1080, bottom: 1080, left: 900, right: 900 } };
const doc = new Document({
  creator: "Virender", title: "3D Particle Classification Using Machine Learning",
  styles: { default: { document: { run: { font: FONT, size: 20 } } } },
  sections: [
    { properties: { page }, children: titleBlock },
    { properties: { type: SectionType.CONTINUOUS, page, column: { count: 2, space: 360 } }, children: bodyContent },
  ],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync("deliverables/Project55_IEEE_Article.docx", b); console.log("ok"); });
