const pptxgen = require("pptxgenjs");
const fs = require("fs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const base = JSON.parse(fs.readFileSync("results/baseline_metrics.json"));
const pn = JSON.parse(fs.readFileSync("results/pointnet_metrics.json"));
const pct = (x) => (100 * x).toFixed(1) + "%";
const RF = base.RandomForest, SV = base.SVM_RBF;

const THEME = {
  name: "ParticleCT",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "17262F", lt1: "FFFFFF", dk2: "0F3D47", lt2: "EDF3F4",
    accent1: "1F8A83", accent2: "E39A2D", accent3: "3C6E91",
    accent4: "D2603F", accent5: "6B5B7B", accent6: "7FA66F",
    hlink: "1F8A83", folHlink: "6B5B7B",
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
pres.title = "3D Particle Classification Using Machine Learning";
const C = pres.SchemeColor;

pres.defineSlideMaster({
  title: "DARK",
  background: { color: "0F3D47" },
  objects: [],
  slideNumber: { x: 12.4, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: "9FC2C6" },
});
pres.defineSlideMaster({
  title: "LIGHT",
  background: { color: "FFFFFF" },
  objects: [],
  slideNumber: { x: 12.4, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: "6B7F86" },
  slideNumber_: null,
});

const DK = "17262F", TEAL = "1F8A83", AMB = "E39A2D", PALE = "EDF3F4", MUT = "5B6E75", DEEP = "0F3D47";

function title(slide, text, color) {
  slide.addText(text, {
    x: 0.6, y: 0.4, w: 12.1, h: 0.9, fontFace: "Cambria", fontSize: 34, bold: true,
    color: color || DK, margin: 0, valign: "top", isTextBox: true, objectName: "Title",
  });
}
function bullets(slide, items, o) {
  const arr = items.map((t, i) => ({
    text: t, options: { bullet: { indent: 16 }, breakLine: i < items.length - 1, paraSpaceAfter: 8 },
  }));
  slide.addText(arr, Object.assign({
    fontFace: "Calibri", fontSize: 16, color: DK, valign: "top", margin: 0, isTextBox: true,
  }, o));
}
function card(slide, x, y, w, h, head, body, o = {}) {
  slide.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.08, fill: { color: o.fill || PALE }, line: { color: o.fill || PALE },
  });
  slide.addText(head, {
    x: x + 0.25, y: y + 0.18, w: w - 0.5, h: 0.4, fontFace: "Cambria", fontSize: 18, bold: true,
    color: o.headColor || TEAL, margin: 0, isTextBox: true,
  });
  slide.addText(body, {
    x: x + 0.25, y: y + 0.65, w: w - 0.5, h: h - 0.8, fontFace: "Calibri", fontSize: o.size || 20,
    color: o.bodyColor || DK, margin: 0, valign: "top", isTextBox: true,
  });
}
const SRC = (slide, text) =>
  slide.addText(text, { x: 0.6, y: 6.95, w: 11.5, h: 0.3, fontSize: 10, color: MUT, margin: 0, isTextBox: true });

// ---------- 1. Title ----------
let s = pres.addSlide({ masterName: "DARK" });
s.addText("3D Particle Classification Using Machine Learning", {
  x: 0.8, y: 1.7, w: 11.5, h: 1.9, fontFace: "Cambria", fontSize: 44, bold: true, color: "FFFFFF", margin: 0, isTextBox: true, valign: "top",
});
s.addText("PointNet versus Random Forest and SVM on synthetic particle point clouds", {
  x: 0.8, y: 3.75, w: 11, h: 0.8, fontSize: 22, color: "BFE0DC", margin: 0, isTextBox: true,
});
s.addText("Virender   |   Enrolment No. 24324027   |   AI for 3D Morphology and Material Characterization", {
  x: 0.8, y: 5.6, w: 11.5, h: 0.4, fontSize: 16, color: "FFFFFF", margin: 0, isTextBox: true,
});
s.addNotes("Hello, and welcome to my project. I classify the three-dimensional shape of particles using machine learning, and I compare a deep learning model called PointNet with two classical methods, Random Forest and Support Vector Machine. Everything you will see runs on synthetic data that I generated myself, so the correct answer for every particle is known exactly.");

// ---------- 2. Intro ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Introduction: can a computer read a particle's shape?");
bullets(s, [
  "Powders, grains and pellets are made of many tiny particles; their shape changes how they flow, pack and behave.",
  "Micro-CT scanners produce 3D data, but sorting thousands of particles by eye is slow and subjective.",
  "This project teaches a model to assign each particle to one of five shape classes.",
], { x: 0.6, y: 1.5, w: 6.4, h: 4.8, fontSize: 21 });
const stats = [["8,000", "synthetic particles"], ["5", "shape classes"], ["3", "models compared"]];
stats.forEach(([n, l], i) => {
  const y = 1.5 + i * 1.75;
  s.addShape(pres.ShapeType.roundRect, { x: 7.8, y, w: 4.9, h: 1.55, rectRadius: 0.08, fill: { color: i === 0 ? DEEP : PALE }, line: { color: i === 0 ? DEEP : PALE } });
  s.addText(n, { x: 8.0, y: y + 0.15, w: 2.2, h: 1.25, fontFace: "Cambria", fontSize: 50, bold: true, color: i === 0 ? "FFFFFF" : TEAL, margin: 0, valign: "middle", isTextBox: true });
  s.addText(l, { x: 10.2, y: y + 0.15, w: 2.4, h: 1.25, fontSize: 18, color: i === 0 ? "FFFFFF" : DK, margin: 0, valign: "middle", isTextBox: true });
});
s.addNotes("Particles in powders, sands and pellets come in many shapes, and that shape matters: it changes how a material flows, packs and how strong it ends up. A micro-CT scanner can capture each particle in 3D, but deciding by eye which shape each of thousands of particles has is slow and depends on who is looking. So the goal is to let a model do it. I created eight thousand synthetic particles in five shape classes and compare three models.");

// ---------- 3. Problem ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Problem, objectives and why it matters");
card(s, 0.6, 1.5, 3.9, 4.9, "The problem", "Given only the 3D surface points of one particle, decide its morphology class: rounded, elongated, platy, angular or irregular. The particle can be in any orientation and any size.");
card(s, 4.7, 1.5, 3.9, 4.9, "Objectives", "1. Build a seeded, fully labelled synthetic dataset.\n2. Train Random Forest and SVM on hand-made shape features.\n3. Train PointNet directly on raw points.\n4. Compare with accuracy, macro-F1 and confusion matrices.", { fill: "FFFFFF", size: 19 });
card(s, 8.8, 1.5, 3.9, 4.9, "Why solve it", "Manual shape grading does not scale and differs between people. Reliable automatic labels support quality control of powders and faster materials research. Synthetic data gives exact ground truth with no scanner time.", { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF" });
s.addNotes("The problem is simple to state. Given only the surface points of one particle, decide which of five shape classes it belongs to. The particle may be rotated in any direction, so the model must recognise shape, not orientation. My objectives are to build a seeded synthetic dataset with exact labels, train two classical models on shape features, train PointNet on raw points, and compare all three with accuracy, macro F1 and confusion matrices. This matters because manual grading does not scale and varies between people, and because synthetic data gives exact ground truth without any scanner time.");

// ---------- 4. Theory ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Theory: two ways to turn points into a label");
card(s, 0.6, 1.5, 5.9, 4.9, "Classical: describe, then classify",
  "Compute rotation-invariant numbers: PCA eigenvalues (elongation, flatness), convex-hull volume and area, compactness, radial distance statistics, and the D2 distribution of random point-pair distances.\n\nRandom Forest votes across many decision trees. SVM with an RBF kernel finds a smooth boundary between classes in feature space.", { size: 17 });
card(s, 6.8, 1.5, 5.9, 4.9, "Deep: PointNet learns the description",
  "A point cloud has no order, so the model must not care about point order. PointNet applies the same small network h to every point, takes a max over points, then classifies:\n\nf(P) = g( max over i of h(p_i) )\n\nMax is symmetric, so shuffling points changes nothing. Rotation is not built in; it must be learned from rotated examples.", { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF", size: 17 });
s.addNotes("There are two routes from points to a label. The classical route first turns each particle into a handful of numbers that do not change when the particle is rotated: how stretched or flat it is from principal component analysis, convex hull volume and area, how close the shape is to a sphere, and statistics of distances between random point pairs. Random Forest and SVM then classify those numbers. The deep route is PointNet. A point cloud has no natural order, so PointNet applies the same small network to every point and then takes the maximum across points. Taking a maximum is symmetric, so shuffling the points changes nothing. Rotation is not built in, so the network has to learn it from rotated examples.");

// ---------- 5. Previous work ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Previous work");
const prev = [
  ["PointNet, 2017", "Qi et al. showed a network can classify raw, unordered point sets with a shared per-point network and max pooling."],
  ["PointNet++, 2017", "Qi et al. added local neighbourhood grouping to capture fine geometric detail that PointNet misses."],
  ["Random Forests, 2001", "Breiman's ensemble of randomised decision trees: a strong, robust baseline on tabular features."],
  ["Support vector machines, 1995", "Cortes and Vapnik's maximum-margin classifier; with kernels it handles non-linear boundaries."],
  ["Shape distributions, 2002", "Osada et al. described 3D shapes by histograms such as the D2 pairwise-distance distribution, used here as features."],
  ["3D ShapeNets, 2015", "Wu et al. introduced the ModelNet benchmark that made 3D shape classification a standard learning task."],
];
prev.forEach(([h, b], i) => {
  const col = i % 2, row = Math.floor(i / 2);
  card(s, 0.6 + col * 6.2, 1.5 + row * 1.8, 5.9, 1.65, h, b, { size: 17 });
});
SRC(s, "Full references are listed in the accompanying article.");
s.addNotes("This work builds on a few well-known results. PointNet by Qi and colleagues in 2017 showed that a network can classify raw unordered point sets. PointNet plus plus added local neighbourhoods to capture finer detail. Breiman's Random Forests from 2001 and the support vector machine of Cortes and Vapnik from 1995 are the classical baselines. Osada and colleagues proposed shape distributions such as the pairwise distance histogram, which I use as features. And 3D ShapeNets introduced the ModelNet benchmark that made 3D shape classification a standard task.");

// ---------- 6. Method: data ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Method 1: a synthetic dataset with exact labels");
s.addImage({ path: "results/particle_gallery.png", x: 0.6, y: 1.45, w: 7.6, h: 3.29 });
bullets(s, [
  "Surface points sampled on shapes built by code: ellipsoids, a random convex hull, and a smooth random radial bumpiness.",
  "Size removed, random 3D rotation, and Gaussian surface noise added.",
  "Class parameters overlap on purpose, so the task is not trivial.",
], { x: 8.5, y: 1.5, w: 4.3, h: 3.5, fontSize: 16 });
s.addText("1,600 particles per class, 1,024 points each, seed 42. Split by particle ID: 70% train, 15% validation, 15% test.", {
  x: 0.6, y: 5.2, w: 12.1, h: 0.8, fontSize: 18, bold: true, color: DEEP, margin: 0, isTextBox: true,
});
SRC(s, "Top and bottom rows show two different particles of each class, in random orientation.");
s.addNotes("Here is the data. Every particle is generated by code, so its class is known exactly with no manual labelling. Rounded particles are near spheres, elongated ones are stretched, platy ones are flattened, angular ones are random convex polyhedra, and irregular ones have a bumpy surface. I remove absolute size, rotate every particle randomly, and add small surface noise. I deliberately made the class parameters overlap. My first version was too easy, with the baselines scoring almost ninety nine point eight percent, so I made it harder. There are sixteen hundred particles per class, split by particle, never by point, into train, validation and test.");

// ---------- 7. Method: workflow ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Method 2: the workflow, step by step");
const steps = [
  ["1", "Generate", "Build particles from code with a fixed seed"],
  ["2", "Normalise", "Centre, scale to unit sphere, random rotation, add noise"],
  ["3", "Split", "By particle ID: train, validation, test"],
  ["4", "Represent", "24 features for RF and SVM; raw points for PointNet"],
  ["5", "Train", "Choose settings on validation data only"],
  ["6", "Test once", "Report accuracy, macro-F1, confusion matrix"],
];
steps.forEach(([n, h, b], i) => {
  const x = 0.6 + i * 2.05;
  s.addShape(pres.ShapeType.ellipse, { x: x + 0.55, y: 1.6, w: 0.8, h: 0.8, fill: { color: i % 2 ? AMB : TEAL }, line: { color: i % 2 ? AMB : TEAL } });
  s.addText(n, { x: x + 0.55, y: 1.6, w: 0.8, h: 0.8, align: "center", valign: "middle", fontSize: 22, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
  s.addText(h, { x, y: 2.65, w: 1.95, h: 0.5, align: "center", fontFace: "Cambria", fontSize: 18, bold: true, color: DK, margin: 0, isTextBox: true });
  s.addText(b, { x, y: 3.2, w: 1.95, h: 1.7, align: "center", valign: "top", fontSize: 16, color: DK, margin: 0, isTextBox: true });
});
card(s, 0.6, 5.0, 12.1, 1.55, "Why this order matters",
  "Splitting by particle (not by point) stops information leaking between train and test. The test set is used exactly once, so the reported numbers are an honest estimate on unseen particles.", { size: 18 });
s.addNotes("The workflow has six steps, and each is simple. One, generate the particles with a fixed random seed. Two, normalise: centre each particle, scale it to a unit sphere, rotate it randomly and add noise. Three, split by particle so that no particle appears in more than one set. Four, represent the data: twenty four hand-made features for Random Forest and SVM, or the raw points for PointNet. Five, train, choosing settings using validation data only. Six, evaluate on the test set exactly once. Doing it in this order keeps the final numbers honest.");

// ---------- 8. Method: models ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Method 3: the three models");
card(s, 0.6, 1.5, 3.9, 4.9, "Random Forest", "400 trees on 24 rotation-invariant features: PCA eigenvalues, elongation, flatness, hull volume and area, compactness, radial statistics, hull facet count, D2 distances.");
card(s, 4.7, 1.5, 3.9, 4.9, "SVM (RBF)", "Same 24 features, standardised. RBF kernel with C = 10. Gives a smooth non-linear boundary between the five classes.");
card(s, 8.8, 1.5, 3.9, 4.9, "PointNet", "Shared per-point MLP 3-64-128-256 with ReLU, max pooling over 512 points, then 256-128-5 classifier. Trained 60 epochs with Adam, random rotations and jitter. Implemented from scratch in NumPy; no T-Net or batch-norm.", { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF" });
s.addNotes("Here are the three models. Random Forest uses four hundred trees on the twenty four rotation-invariant features. The SVM uses the same features after standardising them, with an RBF kernel. PointNet takes the raw points: a shared network of sizes sixty four, one hundred twenty eight and two hundred fifty six on every point, a max pooling step over five hundred twelve points, then a small classifier. I trained it for sixty epochs with random rotations and jitter. I wrote it from scratch in NumPy, so it is a simplified PointNet without the alignment networks or batch normalisation.");

// ---------- 9. Results ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Results on 1,200 unseen test particles");
const labels = ["Random Forest", "SVM (RBF)", "PointNet"];
s.addChart(pres.charts.BAR, [
  { name: "Accuracy", labels, values: [RF.test_accuracy, SV.test_accuracy, pn.test_accuracy].map((v) => +(v * 100).toFixed(1)) },
  { name: "Macro-F1", labels, values: [RF.test_macro_f1, SV.test_macro_f1, pn.test_macro_f1].map((v) => +(v * 100).toFixed(1)) },
], {
  x: 0.6, y: 1.45, w: 7.4, h: 4.9, barDir: "col", barGrouping: "clustered",
  chartColors: [TEAL, AMB], showLegend: true, legendPos: "b", legendFontSize: 14, legendColor: DK,
  showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 14, dataLabelColor: DK, dataLabelFormatCode: "0.0",
  valAxisMinVal: 60, valAxisMaxVal: 100, valAxisLabelFontSize: 12, catAxisLabelFontSize: 14,
  valAxisLabelColor: MUT, catAxisLabelColor: DK, valGridLine: { color: "D9E3E5", size: 0.5 }, catGridLine: { style: "none" },
  showTitle: true, title: "Test score (%)", titleFontSize: 14, titleColor: DK, valAxisLabelFormatCode: "0",
});
card(s, 8.3, 1.5, 4.4, 4.9, "What the numbers say",
  `SVM ${pct(SV.test_accuracy)} and Random Forest ${pct(RF.test_accuracy)} are level.\n\nPointNet reaches ${pct(pn.test_accuracy)}: about 4 points lower, using no hand-made features.\n\nAll three are far above the 20% chance level for five balanced classes.`, { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF", size: 19 });
s.addNotes(`These are the test results on twelve hundred particles the models never saw. The SVM reaches ${pct(SV.test_accuracy)} accuracy and Random Forest ${pct(RF.test_accuracy)}, essentially a tie. PointNet reaches ${pct(pn.test_accuracy)}, about four points lower, even though it was given only raw points and no hand-made features. All three are far above the twenty percent you would get by guessing among five balanced classes. So on this task, well-designed features are slightly better than my simplified PointNet.`);

// ---------- 10. Confusion matrices ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Where the models get confused");
["cm_RandomForest.png", "cm_SVM_RBF.png", "cm_PointNet.png"].forEach((f, i) =>
  s.addImage({ path: "results/" + f, x: 0.6 + i * 4.1, y: 1.45, w: 3.9, h: 3.51 }));
bullets(s, [
  "Elongated and angular particles are almost always correct in all three models.",
  "Nearly all errors are among rounded, platy and irregular: these shapes overlap by design, and surface noise blurs fine bumps.",
  "PointNet confuses irregular with rounded most often (34 of 240 particles).",
], { x: 0.6, y: 5.15, w: 12.1, h: 1.8, fontSize: 18 });
s.addNotes("The confusion matrices show where the mistakes are. Elongated and angular particles are almost always correct for every model, because they have a very distinctive stretch or flat facets. Nearly all the errors are among rounded, platy and irregular particles. That is expected: I made those classes overlap, and surface noise hides fine bumps. PointNet's most frequent mistake is calling an irregular particle rounded, thirty four times out of two hundred forty.");

// ---------- 11. Explain for non-experts ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "In plain words: how each model decides");
card(s, 0.6, 1.5, 3.9, 4.9, "Random Forest", "Like asking 400 inspectors, each with a short checklist: \"Is it long? Is it flat? Does it have sharp faces?\" The class with most votes wins.");
card(s, 4.7, 1.5, 3.9, 4.9, "SVM", "Imagine plotting every particle on a map of shape measurements and drawing smooth borders so that each class lives in its own region.");
card(s, 8.8, 1.5, 3.9, 4.9, "PointNet", "Looks at every surface point on its own, notes the strongest signals it saw anywhere on the particle, and decides from that summary. It was never told what \"long\" or \"flat\" means; it learned it.", { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF" });
s.addNotes("For anyone who is not an AI specialist: Random Forest is like asking four hundred inspectors, each with a short checklist such as, is it long, is it flat, does it have sharp faces, and letting the majority decide. The SVM is like plotting every particle on a map of shape measurements and drawing smooth borders around each class. PointNet looks at every surface point individually, keeps the strongest signal it saw anywhere on the particle, and decides from that summary. Nobody told it what long or flat means; it learned that from examples.");

// ---------- 12. Ethics ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Ethical risks and inherent biases");
card(s, 0.6, 1.5, 3.9, 4.9, "Data bias", "The model only knows the shapes I generated. Real particles are messier, so scores here can overstate real-world accuracy.", { size: 20 });
card(s, 4.7, 1.5, 3.9, 4.9, "Design bias", "I chose the five classes, their parameter ranges and the noise level. A different choice changes the ranking of the models, so results are relative to this setup.", { size: 20 });
card(s, 8.8, 1.5, 3.9, 4.9, "Misuse risk", "Wrong labels could pass bad powder or material batches. Use as decision support with human checks, and report errors honestly, including the classes it confuses.", { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF", size: 20 });
s.addNotes("Ethics and bias. First, data bias: the model only knows the shapes I generated, and real particles are messier, so these scores may overstate real-world accuracy. Second, design bias: I chose the five classes, their parameter ranges and the noise level, and a different choice could change which model wins. Third, misuse: wrong labels could let bad material batches pass. So this should support human decisions, not replace them, and errors, like the rounded versus irregular confusion, should be reported openly.");

// ---------- 13. Conclusion ----------
s = pres.addSlide({ masterName: "DARK" });
title(s, "Conclusion", "FFFFFF");
bullets(s, [
  `The problem is solved to a useful level: ${pct(SV.test_accuracy)} accuracy (SVM) and ${pct(RF.test_accuracy)} (Random Forest) on five shape classes.`,
  `PointNet learned shape from raw points alone, reaching ${pct(pn.test_accuracy)} with no hand-made features.`,
  "On this synthetic task, simple geometric features were slightly better than the simplified PointNet.",
  "Errors concentrate where classes overlap: rounded, platy and irregular.",
], { x: 0.8, y: 1.6, w: 11.6, h: 4.8, fontSize: 26, color: "FFFFFF" });
s.addNotes(`To conclude: the problem is solved to a useful level. The SVM and Random Forest reach ${pct(SV.test_accuracy)} and ${pct(RF.test_accuracy)} accuracy on five shape classes, and PointNet reaches ${pct(pn.test_accuracy)} from raw points alone with no hand-made features. On this synthetic task, simple geometric features were slightly better than my simplified PointNet. Almost all errors happen where the classes overlap, which are rounded, platy and irregular.`);

// ---------- 14. Limitations ----------
s = pres.addSlide({ masterName: "LIGHT" });
title(s, "Limitations and next steps");
card(s, 0.6, 1.5, 5.9, 4.9, "Limitations", "Synthetic particles only; no real CT scans were tested.\n\nPointNet is simplified (no T-Net, no batch-norm, 512 points, NumPy implementation); a full PyTorch PointNet or PointNet++ may score higher.\n\nSingle seed and single split, so small differences (RF vs SVM) are within noise.\n\nParticles are single, isolated and already segmented.", { size: 17 });
card(s, 6.8, 1.5, 5.9, 4.9, "Next steps", "Run a full PyTorch PointNet and PointNet++ with the same split.\n\nRepeat with several seeds and report mean and spread.\n\nCheck sim-to-real on an open particle CT dataset such as the Digital Rocks Portal (qualitative check).\n\nAdd simulated CT reconstruction and noise before extracting points.", { fill: DEEP, headColor: "F2C777", bodyColor: "FFFFFF", size: 17 });
s.addNotes("Finally, the limitations. I tested only synthetic particles, so I do not know how well this transfers to real CT scans. My PointNet is simplified, with no alignment networks, no batch normalisation and only five hundred twelve points, so a full PyTorch PointNet or PointNet plus plus might score higher. I used one random seed and one split, so the tiny difference between Random Forest and SVM is within noise. And the particles are isolated and already segmented. Next steps are a full PointNet and PointNet plus plus on the same split, several random seeds, a qualitative check on an open real particle dataset, and simulating CT reconstruction before extracting points. Thank you for watching.");

(async () => {
  await pres.writeFile({ fileName: "deliverables/Project55_Particle_Classification.pptx" });
  await applyTheme("deliverables/Project55_Particle_Classification.pptx", THEME);
  console.log("done");
})();
