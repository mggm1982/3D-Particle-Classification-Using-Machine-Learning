#!/bin/bash
# Training queue (sequential; 2 CPU cores). 20 epochs each, 256 points, batch 64.
cd /home/claude/project55
E=20
python3 cfpn.py --name cf_s0   --mode pca --fused 1 --seed 0 --epochs $E
python3 cfpn.py --name pca_s0  --mode pca --fused 0 --seed 0 --epochs $E
python3 cfpn.py --name rot_s0  --mode rot --fused 0 --seed 0 --epochs $E
python3 cfpn.py --name cf_nosign_s0 --mode pca --fused 1 --seed 0 --epochs $E --nosignaug 1
python3 cfpn.py --name cf_s1   --mode pca --fused 1 --seed 1 --epochs $E
python3 cfpn.py --name pca_s1  --mode pca --fused 0 --seed 1 --epochs $E
python3 cfpn.py --name rot_s1  --mode rot --fused 0 --seed 1 --epochs $E
echo ALLDONE
