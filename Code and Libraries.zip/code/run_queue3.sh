#!/bin/bash
# Queue 3: ablations and seeds around the main model (CF-PointNet-A: PCA frame + 24 features + corruption-aware training)
cd /home/claude/project55
E=20
run() { name=$1; shift; [ -f results/models/$name.json ] || python3 cfpn.py --name $name --epochs $E "$@"; }
run cfa_aug_s1       --mode pca --fused 1 --feats all --aug 1 --seed 1
run cfa_nosign_s0    --mode pca --fused 1 --feats all --aug 1 --nosignaug 1 --seed 0
run cfa_aug_nozblur_s0 --mode pca --fused 1 --feats all --aug 1 --holdout zblur --seed 0
run pca_aug_s1       --mode pca --fused 0 --aug 1 --seed 1
run rot_aug_s1       --mode rot --fused 0 --aug 1 --seed 1
echo ALLDONE
