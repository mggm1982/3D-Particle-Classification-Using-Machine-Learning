"""Re-evaluate saved NumPy PointNet weights (used after a JSON-serialisation crash at the end of training)."""
import json, re, numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import pointnet_numpy as pn
W = np.load("results/pointnet_numpy_weights.npz"); P = {k: W[k] for k in W.files}
Xva, yva = pn.load("val", "training data"); Xte, yte = pn.load("test", "testing data")
hist = dict(train_loss=[], val_acc=[])
for l in open("results/pointnet_log.txt"):
    m = re.match(r"epoch\s+\d+/\d+ loss ([\d.]+) val_acc ([\d.]+)", l)
    if m: hist["train_loss"].append(float(m[1])); hist["val_acc"].append(float(m[2]))
pred = pn.predict(P, Xte, 512); cm = confusion_matrix(yte, pred)
metrics = dict(implementation="NumPy PointNet (no T-Net/BN)", epochs=len(hist["val_acc"]),
    best_val_accuracy=float(accuracy_score(yva, pn.predict(P, Xva, 512))),
    test_accuracy=float(accuracy_score(yte, pred)), test_macro_f1=float(f1_score(yte, pred, average="macro")),
    test_accuracy_1024pts=float(accuracy_score(yte, pn.predict(P, Xte, 1024))),
    confusion_matrix=cm.tolist(), history=hist)
json.dump(metrics, open("results/pointnet_metrics.json", "w"), indent=2)
print({k: v for k, v in metrics.items() if k not in ("confusion_matrix", "history")}); print(cm)
names = pn.CLASS_NAMES
fig, ax = plt.subplots(figsize=(5, 4.5)); cmn = cm / cm.sum(1, keepdims=True)
ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(5)); ax.set_xticklabels(names, rotation=40, ha="right"); ax.set_yticks(range(5)); ax.set_yticklabels(names)
for r in range(5):
    for c in range(5): ax.text(c, r, cm[r, c], ha="center", va="center", color="white" if cmn[r, c] > .5 else "black", fontsize=8)
ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title("PointNet (test)")
fig.tight_layout(); fig.savefig("results/cm_PointNet.png", dpi=160); plt.close(fig)
fig, ax = plt.subplots(1, 2, figsize=(9, 3.5))
ax[0].plot(hist["train_loss"]); ax[0].set_title("Training loss"); ax[0].set_xlabel("epoch")
ax[1].plot(hist["val_acc"]); ax[1].set_title("Validation accuracy"); ax[1].set_xlabel("epoch")
fig.tight_layout(); fig.savefig("results/pointnet_curves.png", dpi=160)
