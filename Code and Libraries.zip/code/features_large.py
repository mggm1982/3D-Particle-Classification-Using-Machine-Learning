"""Compute the 24 rotation-invariant features for every clean particle of the large dataset (parallel)."""
import os, sys
from multiprocessing import Pool
import numpy as np
import baselines as b


def f(P):
    try:
        return b.features(P.astype(np.float64))
    except Exception:
        return [np.nan] * len(b.FEATURE_NAMES)


def feats(X, procs=2):
    with Pool(procs) as p:
        return np.array(p.map(f, list(X), chunksize=64), dtype=np.float64)


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    out = {}
    for split, folder in [("train", "training data"), ("val", "training data"), ("cal", "training data"), ("test", "testing data")]:
        z = np.load(os.path.join("data_large", folder, f"{split}.npz"))
        F = feats(z["points"])
        out[f"F_{split}"] = F; out[f"y_{split}"] = z["labels"]
        print(split, F.shape, "nan rows:", int(np.isnan(F).any(1).sum()), flush=True)
    np.savez_compressed("results/features_large.npz", **out)
