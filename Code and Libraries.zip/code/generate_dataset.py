"""
Project 55 - 3D Particle Classification Using Machine Learning
Step 1: synthetic dataset generator (fully procedural, seeded, no external data).

Five particle morphology classes, each a 3D point cloud sampled on the particle
surface (N_POINTS points, centred and scaled to the unit sphere, randomly rotated):

  0 rounded    - near-spherical grain, mild axis variation, smooth surface
  1 elongated  - rod/needle-like prolate ellipsoid
  2 platy      - flake/disc-like oblate ellipsoid
  3 angular    - faceted convex polyhedron (random convex hull), mild anisotropy
  4 irregular  - rough, bumpy particle (random low-frequency radial perturbation)

Ground truth (class label) is exact because it is the generator parameter.
Parameter ranges deliberately overlap between classes so the task is not trivial.

Split is by particle ID (each particle appears in exactly one split), with a fixed seed.

Usage:  python generate_dataset.py --n_per_class 1600 --n_points 1024 --seed 42
"""
import argparse
import json
import os

import numpy as np
from scipy.spatial import ConvexHull

CLASS_NAMES = ["rounded", "elongated", "platy", "angular", "irregular"]


def random_rotation(rng):
    """Uniform random 3D rotation matrix via QR of a Gaussian matrix."""
    q, r = np.linalg.qr(rng.normal(size=(3, 3)))
    q *= np.sign(np.diag(r))
    if np.linalg.det(q) < 0:
        q[:, 0] *= -1
    return q


def sphere_dirs(n, rng):
    v = rng.normal(size=(n, 3))
    return v / np.linalg.norm(v, axis=1, keepdims=True)


def radial_perturbation(dirs, rng, n_waves, amp, freq_range):
    """Smooth random radial field r(d) = 1 + sum_k a_k cos(w_k . d + phi_k)."""
    r = np.ones(len(dirs))
    for _ in range(n_waves):
        w = rng.normal(size=3)
        w = w / np.linalg.norm(w) * rng.uniform(*freq_range)
        phi = rng.uniform(0, 2 * np.pi)
        a = rng.uniform(-amp, amp)
        r += a * np.cos(dirs @ w + phi)
    return np.clip(r, 0.3, None)


def sample_hull_surface(verts, n, rng):
    """Uniform-by-area surface sampling of a convex hull."""
    hull = ConvexHull(verts)
    tri = verts[hull.simplices]  # (F,3,3)
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    areas = 0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1)
    idx = rng.choice(len(tri), size=n, p=areas / areas.sum())
    u = rng.random((n, 2))
    flip = u.sum(1) > 1
    u[flip] = 1 - u[flip]
    return a[idx] + u[:, :1] * (b[idx] - a[idx]) + u[:, 1:] * (c[idx] - a[idx])


def make_particle(cls, n_points, rng):
    d = sphere_dirs(n_points, rng)
    if cls == 0:  # rounded
        ax = rng.uniform(0.7, 1.0, 3)
        r = radial_perturbation(d, rng, 4, 0.07, (0.5, 2.5))
        pts = d * r[:, None] * ax
    elif cls == 1:  # elongated (prolate)
        ratio = rng.uniform(1.25, 2.6)
        ax = np.array([ratio, rng.uniform(0.7, 1.0), rng.uniform(0.7, 1.0)])
        r = radial_perturbation(d, rng, 4, 0.08, (0.5, 2.5))
        pts = d * r[:, None] * ax
    elif cls == 2:  # platy (oblate)
        flat = rng.uniform(0.3, 0.7)
        ax = np.array([rng.uniform(0.8, 1.0), rng.uniform(0.7, 1.0), flat])
        r = radial_perturbation(d, rng, 4, 0.08, (0.5, 2.5))
        pts = d * r[:, None] * ax
    elif cls == 3:  # angular / faceted
        nv = int(rng.integers(14, 45))
        v = sphere_dirs(nv, rng) * rng.uniform(0.85, 1.0, (nv, 1))
        v = v * rng.uniform(0.65, 1.0, 3)
        pts = sample_hull_surface(v, n_points, rng)
    else:  # irregular / rough
        ax = rng.uniform(0.65, 1.0, 3)
        r = radial_perturbation(d, rng, int(rng.integers(5, 10)), 0.11, (1.0, 3.5))
        pts = d * r[:, None] * ax

    # centre, normalise to unit sphere (removes absolute size as a cue), random rotation
    pts = pts - pts.mean(0)
    pts = pts / np.linalg.norm(pts, axis=1).max()
    pts = pts @ random_rotation(rng).T
    # acquisition-like surface jitter (simulates segmentation/scan noise)
    pts = pts + rng.normal(scale=0.02, size=pts.shape)
    return pts.astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_per_class", type=int, default=1600)
    ap.add_argument("--n_points", type=int, default=1024)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", type=str, default="data")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    n_cls = len(CLASS_NAMES)
    N = args.n_per_class * n_cls

    X = np.zeros((N, args.n_points, 3), np.float32)
    y = np.zeros(N, np.int64)
    k = 0
    for c in range(n_cls):
        for _ in range(args.n_per_class):
            X[k] = make_particle(c, args.n_points, rng)
            y[k] = c
            k += 1
    ids = np.arange(N)

    # split by particle ID: 70 / 15 / 15, stratified
    split = np.empty(N, dtype="<U5")
    for c in range(n_cls):
        idx = rng.permutation(np.where(y == c)[0])
        n_tr = int(0.70 * len(idx))
        n_va = int(0.15 * len(idx))
        split[idx[:n_tr]] = "train"
        split[idx[n_tr:n_tr + n_va]] = "val"
        split[idx[n_tr + n_va:]] = "test"

    # "training data" holds train+val; "testing data" holds the held-out test set (names as required)
    os.makedirs(os.path.join(args.out, "training data"), exist_ok=True)
    os.makedirs(os.path.join(args.out, "testing data"), exist_ok=True)
    for name, folder, mask in [
        ("train", "training data", split == "train"),
        ("val", "training data", split == "val"),
        ("test", "testing data", split == "test"),
    ]:
        np.savez_compressed(
            os.path.join(args.out, folder, f"{name}.npz"),
            points=X[mask], labels=y[mask], particle_ids=ids[mask],
        )

    meta = dict(
        seed=args.seed, n_per_class=args.n_per_class, n_points=args.n_points,
        class_names=CLASS_NAMES,
        counts={s: int((split == s).sum()) for s in ["train", "val", "test"]},
    )
    with open(os.path.join(args.out, "dataset_info.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
