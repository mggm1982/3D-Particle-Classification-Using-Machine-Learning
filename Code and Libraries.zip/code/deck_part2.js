// Sections 6-7: results and discussion. All numbers are read from results/summary.json at build time.
const { DK, TEAL, AMB, PALE, MUT, DEEP, RED } = require("./deck_lib");

module.exports = function part2(pres, H, S) {
  const Y = S.systems, C = S.conformal || {}, BS = S.bootstrap || {};
  const MAIN = "CF-PointNet-A (aug, 24 feats) TTA";
  const num = (n, k, d = 1) => (Y[n] && Y[n][k] != null ? Number(Y[n][k]).toFixed(d) : "n/a");
  const acc = (n, s, d = 1) => (Y[n] && Y[n].acc && Y[n].acc[s] != null ? Number(Y[n].acc[s]).toFixed(d) : "n/a");
  const f1 = (n, s, d = 1) => (Y[n] && Y[n].f1 && Y[n].f1[s] != null ? Number(Y[n].f1[s]).toFixed(d) : "n/a");
  const pm = (n, k) => (Y[n] ? `${Number(Y[n][k]).toFixed(1)}${Y[n].n_seeds > 1 ? " +/- " + Number(Y[n][k + "_sd"] != null ? Y[n][k + "_sd"] : Y[n]["mca_sd"]).toFixed(1) : ""}` : "n/a");
  const diff = (a, b, k = "mca") => (Y[a] && Y[b] ? Number(Y[a][k]) - Number(Y[b][k]) : NaN);
  const sg = (x, d = 1) => (isNaN(x) ? "n/a" : (x >= 0 ? "+" : "") + x.toFixed(d));
  const bs = (a, b) => BS[`${a} - ${b}`];
  const ci = (r) => (r ? `${r.diff >= 0 ? "+" : ""}${r.diff} [${r.lo}, ${r.hi}]` : "n/a");
  const sev = (n) => Y[n] && Y[n].n_seeds;
  let s;

  const RFc = "RF (clean, 24 feats)", SVc = "SVM (clean, 24 feats)", PNc = "PointNet (clean, rot-aug)", PPc = "PCA-PointNet (clean) TTA", CFc = "CF-PointNet (clean, 24 feats) TTA";
  const RFa = "RF (aug, 24 feats)", PNa = "PointNet (aug)", PPa = "PCA-PointNet (aug) TTA", CRa = "CF-PointNet-R (aug, 18 feats) TTA";
  const sMain = "CF-PointNet-A (aug, 24 feats) single pose", sPP = "PCA-PointNet (aug) single pose";
  const nsMain = "CF-PointNet-A no sign-aug, TTA", nsSingle = "CF-PointNet-A no sign-aug, single";
  const hoA = "CF-PointNet-A (aug w/o zblur) TTA";
  const gainRF = diff(MAIN, RFa), gainTTA = diff(MAIN, sMain);

  // ================================================================ SECTION 6
  H.divider(6, "Results", "What the experiments show, one research question at a time", "Section six: the results. I will go research question by research question.");

  s = H.slide(`The headline. Clean-trained models look excellent on clean data, around ninety-two percent, but across the ten corrupted test sets they average only ${num(RFc, "mca")} percent for Random Forest and ${num(CFc, "mca")} percent for the fused network. The same architecture trained with corruption-aware data averages ${num(MAIN, "mca")} percent on the corrupted sets while keeping ${num(MAIN, "clean")} percent on clean data.`);
  H.title(s, "Headline result");
  H.stat(s, 0.6, 1.5, 3.9, 2.0, `${num(RFc, "clean")}%`, "Random Forest, clean-trained: clean test", false);
  H.stat(s, 4.7, 1.5, 3.9, 2.0, `${num(RFc, "mca")}%`, "same model: mean over 10 corrupted sets");
  H.stat(s, 8.8, 1.5, 3.9, 2.0, `${num(MAIN, "mca")}%`, "CF-PointNet-A, corruption-aware: corrupted sets", true);
  H.bullets(s, [`Clean-trained models lose roughly ${Math.round(Number(num(RFc, "clean")) - Number(num(RFc, "mca")))} points on average (RQ1).`, `Corruption-aware training recovers most of it: ${num(MAIN, "mca")}% mean corrupted accuracy with ${num(MAIN, "clean")}% on clean data.`, "All numbers: 4,000 held-out test particles, 10 corrupted sets built from the same particles."], { x: 0.6, y: 3.9, w: 12.1, h: 2.9, fontSize: 19 });

  s = H.slide("This table gives accuracy and macro-F1 on the clean test set for every system. On clean data, the feature-based models and the clean-trained fused network are best, around ninety-two to ninety-three percent. Point-only networks are lower: the simplified PointNet reaches about eighty-eight percent. Training with corruptions costs a little clean accuracy for most models, and a lot for point-only networks.");
  H.title(s, "Clean-data results");
  const rowsClean = [RFc, SVc, PNc, PPc, CFc, RFa, PNa, PPa, CRa, MAIN].filter((n) => Y[n]).map((n) => [n, `${num(n, "clean")}${Y[n].n_seeds > 1 ? " (" + pm(n, "clean_sd").split("+/-")[1] + ")" : ""}`, f1(n, "clean"), num(n, "mca")]);
  H.table(s, ["System", "Clean acc (%)", "Clean macro-F1 (%)", "Mean corrupted acc (%)"], rowsClean, { x: 0.6, y: 1.5, w: 12.1, colW: [5.6, 2.0, 2.3, 2.2], fs: 14, rowH: 0.46, align: "center" });
  H.src(s, "(...) = standard deviation over 2 seeds where available. Chance level: 20%.");

  s = H.slide("This is the confusion matrix of the main model on clean test data. Elongated and angular particles are almost perfectly recognised. The errors are among rounded, platy and irregular, which overlap by design, so about seven to eight percent error is close to the ceiling set by the data, as the data-scaling result on the next slide also suggests.");
  H.title(s, "Where the main model errs on clean data");
  H.img(s, "figs/cm_main_clean.png", 0.6, 1.4, 5.8, 5.3);
  H.bullets(s, ["Elongated and angular: near-perfect.", "Errors concentrate among rounded, platy and irregular, which overlap by construction.", `Clean macro-F1: ${f1(MAIN, "clean")}%.`, "The remaining ~8% error is close to the overlap ceiling set by the generator."], { x: 6.8, y: 1.6, w: 6, h: 4.8, fontSize: 19 });

  s = H.slide("Does more data help? For Random Forest and SVM on clean features, going from five hundred to twenty-eight thousand training particles lifts accuracy from about ninety percent to about ninety-two or ninety-three percent, and the curve flattens. That is evidence that on clean data the limit is the overlap between classes, not the amount of data. The large dataset is still important because it supports the corruption-aware training and the calibration sets.");
  H.title(s, "Does more data help?");
  H.img(s, "figs/data_scaling.png", 0.6, 1.4, 7.4, 4.9);
  H.bullets(s, ["500 to 28,000 training particles: gains of only ~3 points.", "Clean accuracy saturates near 92-93%.", "More data matters for robustness: corrupted copies and calibration sets need volume."], { x: 8.3, y: 1.6, w: 4.5, h: 5, fontSize: 18 });

  s = H.slide("RQ1. This heat map shows accuracy for every system on every test condition. The top five rows are clean-trained and they turn from dark to pale as soon as any corruption appears, especially noise and z-blur. The lower rows are corruption-trained, and the last row, the main model, stays dark across most sets and degrades gracefully on sparse and occluded data.");
  H.title(s, "RQ1: clean-trained models collapse");
  H.img(s, "figs/heatmap.png", 0.4, 1.35, 12.5, 5.5);

  s = H.slide("The same data in bar form. For each system, the teal bar is clean accuracy and the amber bar is the mean over the ten corrupted sets. For clean-trained models the amber bar is less than half the teal bar. Corruption-trained models keep both bars high, and the main model has the highest amber bar.");
  H.title(s, "Clean vs corrupted accuracy");
  H.img(s, "figs/clean_vs_corrupt.png", 0.5, 1.4, 12.3, 5.3);

  s = H.slide("Why do they collapse? Two reasons. First, hull-based features such as the number of facets change by tens of percent under mild noise, so a tree or a network that relies on them is fooled. Second, the clean-trained fused network learned to rely almost entirely on the feature branch: when I zero the features on clean data the accuracy drops to chance, twenty percent. So the point branch added little in that regime.");
  H.title(s, "Why the collapse?");
  H.img(s, "figs/feature_fragility.png", 0.5, 1.4, 7.3, 5.2);
  H.bullets(s, ["Solidity proxy and hull facet count change by 40-50% under mild noise.", "Clean-trained fused network: zeroing the features gives 20% (chance); the point branch contributed little.", "Clean-trained point-only networks also drop, to ~50% on average: they overfit to clean surface detail."], { x: 8.1, y: 1.6, w: 4.7, h: 5, fontSize: 17 });

  s = H.slide("By corruption family. Each panel shows accuracy going from clean to mild to strong. For noise and z-blur, clean-trained models fall off a cliff at the first step. For sparse and occluded data the fall is more gradual, because the global shape survives. The main model, in teal, is on top in every panel, but note it also declines on sparse and occluded data at the strong level, where information has really been lost.");
  H.title(s, "Robustness by corruption family");
  H.img(s, "figs/family_curves.png", 0.4, 1.5, 12.5, 4.9);

  s = H.slide("This table isolates the effect of corruption-aware training for each architecture, with everything else the same. Random Forest gains a huge amount on corrupted data and loses almost nothing on clean data. The point-only networks gain on corrupted data but lose clean accuracy. The fused network gains the most and keeps clean accuracy nearly unchanged.");
  H.title(s, "Effect of corruption-aware training");
  const trainRows = [["Random Forest", RFc, RFa], ["PointNet", PNc, PNa], ["PCA-PointNet", PPc, PPa], ["CF-PointNet (24 features)", CFc, MAIN]].map(([nm, c, a]) => [nm, `${num(c, "clean")} -> ${num(a, "clean")}`, `${num(c, "mca")} -> ${num(a, "mca")}`, sg(diff(a, c))]);
  H.table(s, ["Architecture", "Clean acc (%): clean-trained -> aug", "Mean corrupted acc (%)", "Gain on corrupted (pts)"], trainRows, { x: 0.6, y: 1.6, w: 12.1, colW: [3.2, 3.5, 3.0, 2.4], fs: 17, rowH: 0.75, align: "center" });
  H.src(s, "Aug = trained on clean + two random corrupted copies per particle; test corruptions use different seeds and fixed severities.");

  s = H.slide(`The robust subset was my hypothesis for RQ2, and the evidence does not support it. After corruption-aware training, dropping the six hull-derived features lowers clean accuracy and also lowers corrupted accuracy. For the fused network, 24 features give ${num(MAIN, "clean")} clean and ${num(MAIN, "mca")} corrupted, against ${num(CRa, "clean")} and ${num(CRa, "mca")} with 18 features. So hull features are fragile when a model is trained only on clean data, but valuable once the model has seen corruptions. I report this as a negative result.`);
  H.title(s, "Robust subset: a negative result");
  H.table(s, ["Model", "Features", "Clean (%)", "Mean corrupted (%)"], [
    ["Random Forest (aug)", "24", num(RFa, "clean"), num(RFa, "mca")],
    ["Random Forest (aug)", "18 robust", num("RF (aug, 18 robust feats)", "clean"), num("RF (aug, 18 robust feats)", "mca")],
    ["CF-PointNet (aug)", "24", num(MAIN, "clean"), num(MAIN, "mca")],
    ["CF-PointNet (aug)", "18 robust", num(CRa, "clean"), num(CRa, "mca")],
  ], { x: 0.6, y: 1.6, w: 12.1, colW: [4.0, 2.4, 2.4, 3.3], fs: 18, rowH: 0.55, align: "center" });
  H.bullets(s, ["Dropping hull features costs accuracy in both model families (hull features carry real signal).", "Lesson: fragility depends on how the model is trained, not only on the feature."], { x: 0.6, y: 5.2, w: 12.1, h: 1.6, fontSize: 19 });

  s = H.slide(`RQ3: sign poses. Averaging over four sign poses at test time changes mean corrupted accuracy of the main model by ${sg(gainTTA)} points compared with a single canonical pose, and changes the point-only PCA network by ${sg(diff(PPa, sPP))} points. Training without sign augmentation gives ${num(nsMain, "mca")} with averaging and ${num(nsSingle, "mca")} with a single pose. The bootstrap confidence intervals on the next slide say whether these gaps are larger than test-set noise.`);
  H.title(s, "RQ3: sign poses and test-time averaging");
  H.img(s, "figs/ablation.png", 0.5, 1.4, 8.2, 5.3);
  H.bullets(s, [`4-pose averaging vs single pose (main model): ${sg(gainTTA)} pts on corrupted data.`, `Point-only PCA network: ${sg(diff(PPa, sPP))} pts.`, "Gains are small for the fused model because most signal comes from rotation-invariant features."], { x: 9.0, y: 1.6, w: 3.8, h: 5, fontSize: 16 });

  s = H.slide("Are the differences real? I used a paired bootstrap on the 4,000 test particles. The table gives the mean difference in accuracy, in percentage points, with a ninety-five percent interval. If the interval excludes zero the difference is larger than test-set sampling noise. This only measures sampling noise on this test set; it does not capture seed-to-seed variation, which I report on the next slide.");
  H.title(s, "Significance: paired bootstrap (95% CI)");
  H.table(s, ["Comparison (A vs B)", "Clean: A - B (pts)", "Corrupted mean: A - B (pts)"], [
    ["CF-PointNet-A vs RF (aug)", ci(bs("cfa_aug_s0|tta", "RandomForest_aug") && bs("cfa_aug_s0|tta", "RandomForest_aug").clean ? { diff: bs("cfa_aug_s0|tta", "RandomForest_aug").clean.diff, lo: bs("cfa_aug_s0|tta", "RandomForest_aug").clean.lo, hi: bs("cfa_aug_s0|tta", "RandomForest_aug").clean.hi } : null), ci(bs("cfa_aug_s0|tta", "RandomForest_aug") && bs("cfa_aug_s0|tta", "RandomForest_aug").corrupted_mean)],
    ["CF-PointNet-A vs PointNet (aug)", ci((bs("cfa_aug_s0|tta", "rot_aug_s0|plain") || {}).clean), ci((bs("cfa_aug_s0|tta", "rot_aug_s0|plain") || {}).corrupted_mean)],
    ["CF-PointNet-A vs PCA-PointNet (aug)", ci((bs("cfa_aug_s0|tta", "pca_aug_s0|tta") || {}).clean), ci((bs("cfa_aug_s0|tta", "pca_aug_s0|tta") || {}).corrupted_mean)],
    ["24 features vs 18 features", ci((bs("cfa_aug_s0|tta", "cfr_aug_s0|tta") || {}).clean), ci((bs("cfa_aug_s0|tta", "cfr_aug_s0|tta") || {}).corrupted_mean)],
    ["TTA vs single pose (main)", ci((bs("cfa_aug_s0|tta", "cfa_aug_s0|single") || {}).clean), ci((bs("cfa_aug_s0|tta", "cfa_aug_s0|single") || {}).corrupted_mean)],
    ["Sign-aug vs no sign-aug (main)", ci((bs("cfa_aug_s0|tta", "cfa_nosign_s0|tta") || {}).clean), ci((bs("cfa_aug_s0|tta", "cfa_nosign_s0|tta") || {}).corrupted_mean)],
  ], { x: 0.6, y: 1.5, w: 12.1, colW: [5.0, 3.4, 3.7], fs: 16, rowH: 0.7, align: "center" });
  H.src(s, "Seed-0 models; bootstrap over the 4,000 test particles (1,000 resamples). n/a = comparison not available.");

  s = H.slide("Seed variation. For models with two seeds, I report mean and standard deviation across seeds. The main model's advantage over the neural baselines is far larger than the seed spread. The comparison with the corruption-trained Random Forest is closer, which is why I rely on the bootstrap and seed results together and avoid claiming a large win over it.");
  H.title(s, "Seed variation");
  const seedRows = [RFa, PNa, PPa, MAIN].filter((n) => Y[n]).map((n) => [n, Y[n].n_seeds, `${num(n, "clean")}${Y[n].n_seeds > 1 ? " +/- " + num(n, "clean_sd") : ""}`, `${num(n, "mca")}${Y[n].n_seeds > 1 ? " +/- " + num(n, "mca_sd") : ""}`, num(n, "worst")]);
  H.table(s, ["System", "Seeds", "Clean acc (%)", "Mean corrupted (%)", "Worst set (%)"], seedRows, { x: 0.6, y: 1.6, w: 12.1, colW: [4.6, 1.2, 2.2, 2.4, 1.7], fs: 16, rowH: 0.7, align: "center" });
  H.src(s, "Random Forest and SVM are single runs (fixed seed); neural models use seeds 0 and 1 where available.");

  s = H.slide(`Generalising to an unseen corruption. I trained a variant whose augmentation bank excludes z-blur, and tested it on z-blur. On mild z-blur it scores ${acc(hoA, "zblur1")} percent and on strong z-blur ${acc(hoA, "zblur2")} percent, compared with ${acc(MAIN, "zblur1")} and ${acc(MAIN, "zblur2")} when z-blur was in training, and ${acc(CFc, "zblur1")} and ${acc(CFc, "zblur2")} for the clean-trained model. So training on other corruptions transfers to z-blur to a large extent, which suggests the benefit is not just memorising the test families.`);
  H.title(s, "Unseen corruption family (z-blur)");
  H.table(s, ["Model", "zblur mild (%)", "zblur strong (%)"], [
    ["Clean-trained CF-PointNet", acc(CFc, "zblur1"), acc(CFc, "zblur2")],
    ["Aug WITHOUT z-blur (unseen family)", acc(hoA, "zblur1"), acc(hoA, "zblur2")],
    ["Aug WITH z-blur (seen family)", acc(MAIN, "zblur1"), acc(MAIN, "zblur2")],
  ], { x: 0.6, y: 1.6, w: 12.1, colW: [6.1, 3.0, 3.0], fs: 19, rowH: 0.85, align: "center" });
  H.src(s, "Single seed for the hold-out variant.");

  s = H.slide("RQ4: conformal sets. With a clean calibration set, the threshold gives the promised ninety percent coverage on clean data, but coverage falls on corrupted data, down to about sixty percent on the sparsest set. Calibrating on mildly corrupted data moves coverage towards ninety percent on most corrupted sets. It does not fully fix the strongest sparse case, which is a reminder that the guarantee holds only under exchangeability.");
  H.title(s, "RQ4: conformal coverage under shift");
  H.img(s, "figs/conformal.png", 0.4, 1.4, 12.5, 4.1);
  const cm = C["cfa_aug_s0|tta"];
  if (cm) H.bullets(s, [`Clean-calibrated: coverage ${(100 * cm.clean_cal.clean.coverage).toFixed(0)}% on clean, ${(100 * cm.clean_cal.sparse2.coverage).toFixed(0)}% on the sparsest set.`, `Mix-calibrated: ${(100 * cm.mix_cal.sparse2.coverage).toFixed(0)}% on the sparsest set, closer to 90% on most others.`], { x: 0.6, y: 5.7, w: 12.1, h: 1.2, fontSize: 18 });

  s = H.slide("The same result as numbers for selected test sets. Coverage is the share of particles whose true class is in the prediction set. Auto-accept is the share with exactly one class. Abstain is everything else, including empty sets. Calibration on corrupted data raises coverage and, as a side effect, increases the number of cases sent to review a little, which is the desired behaviour.");
  H.title(s, "Conformal numbers (main model, alpha = 0.1)");
  if (cm) {
    const sel = ["clean", "noise2", "sparse2", "zblur2", "occlusion2", "voxel2"];
    const rr = sel.map((x) => [x, (100 * cm.clean_cal[x].coverage).toFixed(1), (100 * cm.mix_cal[x].coverage).toFixed(1), (100 * cm.mix_cal[x].auto_accept).toFixed(1), (100 * cm.mix_cal[x].acc_when_accepted).toFixed(1), (100 * cm.mix_cal[x].abstain).toFixed(1)]);
    H.table(s, ["Test set", "Coverage, clean-cal (%)", "Coverage, mix-cal (%)", "Auto-accept (%)", "Accuracy if accepted (%)", "Abstain (%)"], rr, { x: 0.6, y: 1.5, w: 12.1, colW: [1.9, 2.3, 2.1, 1.9, 2.2, 1.7], fs: 15, rowH: 0.62, align: "center" });
  }
  H.src(s, "Auto-accept / accuracy / abstain columns are for the mix-calibrated threshold. Target coverage 90%.");

  s = H.slide("A warning about clean-trained models. The clean-trained fused network is confidently wrong on corrupted data: with clean calibration the prediction set is almost always a single class, so it never abstains, yet its coverage is only twenty to forty percent. With mixed calibration the threshold becomes so large that every set contains all five classes, which is useless. In other words, calibration cannot rescue a model that was never exposed to the shift.");
  H.title(s, "Clean-trained models fail silently");
  const cc = C["cf_s0|tta"];
  if (cc) H.table(s, ["Test set", "Accuracy (%)", "Coverage (%)", "Mean set size", "Abstain (%)"], ["clean", "noise1", "noise2", "zblur2", "voxel2"].map((x) => [x, acc(CFc, x), (100 * cc.clean_cal[x].coverage).toFixed(1), cc.clean_cal[x].mean_set_size.toFixed(2), (100 * cc.clean_cal[x].abstain).toFixed(1)]), { x: 0.6, y: 1.6, w: 12.1, colW: [2.4, 2.5, 2.5, 2.5, 2.2], fs: 18, rowH: 0.52, align: "center" });
  H.bullets(s, ["Set size ~1 and ~0% abstention with 20-30% coverage = confident wrong answers.", "Clean-trained fused network, clean-calibrated."], { x: 0.6, y: 5.5, w: 12.1, h: 1.3, fontSize: 19 });

  s = H.slide("What does abstention buy in practice? Each point is one test set. Accuracy of the automatically accepted particles stays close to ninety percent for most sets under mix calibration while a modest share is sent to review, whereas accuracy on the sparsest set is lower. This is the quality-control trade-off: you choose alpha to balance review workload and error rate.");
  H.title(s, "Accept rate versus accuracy");
  H.img(s, "figs/selective.png", 0.6, 1.4, 7.6, 5.1);
  H.bullets(s, ["Accepted particles keep high accuracy on most sets.", "A smaller alpha means more review, higher purity.", "The hardest case (sparse, strong) remains the weakest."], { x: 8.5, y: 1.6, w: 4.3, h: 5, fontSize: 18 });

  s = H.slide("Which classes suffer under corruption? Per-class recall for the main model on clean data and three strong corruptions. Elongated and angular particles stay high. Platy and irregular particles fall most under noise, because noise hides the thin dimension and the surface bumps respectively. Occlusion hurts platy and rounded particles, where removing a cap changes the apparent proportions.");
  H.title(s, "Per-class robustness");
  H.img(s, "figs/recall_by_class.png", 0.6, 1.4, 8.4, 5.3);
  H.bullets(s, ["Distinctive classes stay robust.", "Noise hides thin and bumpy structure.", "Occlusion changes apparent proportions."], { x: 9.3, y: 1.6, w: 3.5, h: 5, fontSize: 17 });

  s = H.slide("These are the confusion matrices of the main model on clean data and on three strong corruptions. They show that errors are not random: noise pushes platy and irregular towards rounded, and sparsity makes classes collapse into the two broadest categories.");
  H.title(s, "Confusion under strong corruption");
  ["cm_main_clean.png", "cm_main_noise2.png", "cm_main_sparse2.png", "cm_main_occlusion2.png"].forEach((f, i) => H.img(s, "figs/" + f, 0.4 + i * 3.2, 1.6, 3.1, 3.3));
  H.bullets(s, ["Left to right: clean, strong noise, strong sparsity, strong occlusion."], { x: 0.6, y: 5.3, w: 12.1, h: 1, fontSize: 18 });

  s = H.slide("Training curves. The main model, in teal, converges quickly and its validation accuracy is highest because its validation set includes corrupted particles. The point-only networks are still improving at the end of twenty epochs, which tells us they are under-trained and could improve with more epochs or a larger architecture. I list that as a limitation, not as a claim about PointNet in general.");
  H.title(s, "Training curves");
  H.img(s, "figs/training_curves.png", 0.6, 1.4, 12, 4.5);
  H.src(s, "Validation sets differ: models trained with augmentation validate on clean + corrupted particles.");

  s = H.slide(`Answers to the research questions. RQ1: clean-trained models lose about ${Math.round(Number(num(RFc, "clean")) - Number(num(RFc, "mca")))} points on corrupted data. RQ2: corruption-aware training recovers most of it, and keeping all twenty-four features works better than the robust subset. RQ3: four-pose averaging gives about one point to the point-only PCA network and almost nothing to the fused model; sign augmentation did not help the fused model. RQ4: conformal sets lose coverage under shift, and corruption-aware calibration restores much of it but not all.`);
  H.title(s, "Answers to the research questions");
  H.card(s, 0.6, 1.5, 5.9, 2.35, "RQ1", `Clean-trained models lose ~${Math.round(Number(num(RFc, "clean")) - Number(num(RFc, "mca")))} points on corrupted data.`, { size: 18 });
  H.card(s, 6.8, 1.5, 5.9, 2.35, "RQ2", "Corruption-aware training closes most of the gap; all 24 features beat the 18-feature subset.", { size: 18, fill: "FFFFFF" });
  H.card(s, 0.6, 4.1, 5.9, 2.35, "RQ3", `4-pose averaging: ${sg(gainTTA)} pts for the fused model; about +1 for point-only.`, { size: 18, fill: "FFFFFF" });
  H.card(s, 6.8, 4.1, 5.9, 2.35, "RQ4", "Clean calibration under-covers under shift; mixed calibration restores most of the coverage.", H.dark({ size: 18 }));

  // ================================================================ SECTION 7
  H.divider(7, "Discussion and conclusion", "What it means, ethics, limitations, novelty and next steps", "Section seven: discussion and conclusion.");

  s = H.slide(`Interpretation. Three effects stack up. Training on corrupted copies teaches every model what degraded data look like. Fusing global descriptors with a point branch gives complementary evidence. And pose canonicalisation with four-pose averaging removes some orientation noise. The main model is ${sg(gainRF)} points above the corruption-trained Random Forest on corrupted data, a modest margin that the bootstrap interval should be read against.`);
  H.title(s, "Interpretation");
  H.bullets(s, ["Corruption-aware training is the dominant factor: tens of points.", "Fusion of descriptors and points adds a smaller margin over the corruption-trained RF.", "Four-pose averaging helps the point-only PCA network (about +1 point) but is negligible for the fused model; sign augmentation did not help the fused model.", "Feature fragility depends on the training regime: hull features are risky for clean-trained models but useful otherwise."], { x: 0.6, y: 1.5, w: 12.1, h: 5, fontSize: 21 });

  s = H.slide("Why does the point-only network lag behind the feature models? Probably three reasons. My network is a simplified PointNet without alignment networks or batch normalisation. It sees only 256 points. And twenty epochs on a CPU is short. The descriptor features, on the other hand, give it global geometry for free. So I do not conclude that PointNet is poor for this task, only that this small NumPy version is under-powered compared with descriptors.");
  H.title(s, "Why do point-only networks lag?");
  H.card(s, 0.6, 1.5, 3.9, 4.9, "Simplified model", "No T-Nets, no batch-norm, no dropout; about 85k parameters.", { size: 18 });
  H.card(s, 4.7, 1.5, 3.9, 4.9, "Short training", "20 epochs, 256 points per cloud; validation curves were still improving.", { size: 18, fill: "FFFFFF" });
  H.card(s, 8.8, 1.5, 3.9, 4.9, "Global descriptors help", "Hull, PCA and D2 features give global geometry that a shallow point network has to learn from scratch.", H.dark({ size: 18 }));

  s = H.slide("What is new here, stated carefully. The ingredients are known: PCA canonical poses, corruption augmentation, conformal prediction, and PointNet. What I add is the particle-specific corruption benchmark, the measurement that PCA sign poses are unstable under perturbation for these symmetric particles, the evidence that hull features flip from fragile to useful depending on the training regime, and the analysis of conformal coverage under CT-style shift with corruption-aware calibration. I do not claim a state-of-the-art number, since no shared benchmark exists.");
  H.title(s, "What is new, and what is not");
  H.card(s, 0.6, 1.5, 5.9, 4.9, "Known ingredients", "PointNet and PCA canonical poses; corruption augmentation; split conformal prediction; hand-crafted shape descriptors; random forests.", { size: 18 });
  H.card(s, 6.8, 1.5, 5.9, 4.9, "Our additions (on synthetic data)", "ParticleCT-C benchmark.\nPose-instability measurement for symmetric particles.\nFeature fragility depends on the training regime.\nCoverage under CT-style shift and corruption-aware calibration.", H.dark({ size: 17 }));

  s = H.slide("About the patent and preprint question. A patent needs novelty and an inventive step, and I cannot judge that from a limited web search. Several ingredients are already known, so a claim would have to rest on a specific combination applied to a technical process such as scanner-based particle sorting with abstention. In India, algorithms and computer programs per se are excluded under section 3(k) of the Patents Act, so claims normally need a technical effect. Publishing the preprint can affect novelty, so decide the order with a patent attorney before the preprint goes up.");
  H.title(s, "Patent and preprint: practical notes");
  H.bullets(s, ["Novelty and inventive step are unproven: a prior-art search by a professional is needed.", "Candidate technical framing: a measurement and sorting system that scans particles, classifies shape, and routes uncertain particles to review.", "India: algorithms or programs per se are excluded (Patents Act s. 3(k)); technical effect matters.", "Public disclosure (preprint, video) before filing can harm novelty: check timing and grace-period rules.", "This is general information, not legal advice."], { x: 0.6, y: 1.5, w: 12.1, h: 5.2, fontSize: 18 });

  s = H.slide("Ethics and bias. The data are synthetic and the five classes and their ranges were chosen by me, so the results describe this benchmark. Real material has more variety, different noise and unknown classes. A deployed system could pass defective batches if its abstention is mis-calibrated, as the clean-trained example showed. So it should support human review, be recalibrated for each scanner, and report its failure modes openly.");
  H.title(s, "Ethical risks and biases");
  H.card(s, 0.6, 1.5, 3.9, 4.9, "Data and design bias", "Synthetic classes and overlap chosen by the author; real material differs. Reported scores are benchmark-specific.", { size: 18 });
  H.card(s, 4.7, 1.5, 3.9, 4.9, "Silent failure", "Clean-trained models were confidently wrong under artifacts. Calibration alone cannot fix a model never exposed to the shift.", { size: 18, fill: "FFFFFF" });
  H.card(s, 8.8, 1.5, 3.9, 4.9, "Responsible use", "Human review for abstentions; per-scanner recalibration; transparent reporting of failures and limits.", H.dark({ size: 18 }));

  s = H.slide("Limitations. Everything is synthetic, so real CT scans might behave differently. The point networks are simplified NumPy models trained briefly. I used one dataset seed and at most two model seeds. The corruption families are my approximations of CT artifacts, not a physics-based reconstruction. The conformal guarantee needs exchangeability and holds only marginally, not per class. And the corruption-aware advantage over the corruption-trained Random Forest is modest.");
  H.title(s, "Limitations");
  H.bullets(s, ["Synthetic data only; no real CT scans.", "Simplified NumPy PointNet, 20 epochs; a full PointNet/PointNet++ may do better.", "One dataset seed; at most two model seeds.", "Corruptions approximate CT artifacts; no reconstruction physics.", "Conformal guarantee is marginal and needs exchangeability.", "Margin over corruption-trained Random Forest is modest."], { x: 0.6, y: 1.5, w: 12.1, h: 5.2, fontSize: 20 });

  s = H.slide("Next steps. Validate on real micro-CT particles, for example the F50 sand grain dataset that provides real grains and synthetic ones. Train a full PointNet and PointNet plus plus in PyTorch with the same splits. Add physics-based CT simulation. Try adaptive conformal methods designed for distribution shift. And measure the link between predicted shape class and a physical property such as flowability.");
  H.title(s, "Future work");
  H.bullets(s, ["Real data: F50 sand grains (1,551 real grains, 50,000 synthetic; CC BY 4.0).", "Full PointNet / PointNet++ in PyTorch on the same splits.", "Physics-based CT simulation and reconstruction artifacts.", "Adaptive conformal prediction under distribution shift.", "Link shape class to measured flowability or packing density."], { x: 0.6, y: 1.5, w: 12.1, h: 5.2, fontSize: 21 });

  s = H.slide(`Conclusion. I built a forty-thousand-particle synthetic benchmark with five CT-style corruption families. Clean-trained models score about ninety-two percent on clean data but collapse on corrupted data. Corruption-aware training with a fused PCA-canonical PointNet reaches ${num(MAIN, "clean")} percent on clean data and ${num(MAIN, "mca")} percent on average over corrupted sets. Conformal abstention helps, especially with corruption-aware calibration, but cannot rescue a model that was not trained for the shift. Thank you.`, true);
  H.title(s, "Conclusion", "FFFFFF");
  H.bullets(s, [`Clean-trained models: ~${num(RFc, "clean")}% clean, but ~${num(RFc, "mca")}% on corrupted data (RF).`, `CF-PointNet-A with corruption-aware training: ${num(MAIN, "clean")}% clean, ${num(MAIN, "mca")}% on corrupted data.`, "Four-pose averaging helps only the point-only network; the 18-feature robust subset did not help.", "Conformal abstention with corruption-aware calibration restores much of the coverage; calibration cannot fix an unprepared model.", "All results are on synthetic data: validate on real scans next."], { x: 0.8, y: 1.6, w: 11.6, h: 5, fontSize: 24, color: "FFFFFF" });

  s = H.slide("References, part one.");
  H.title(s, "References (1/2)");
  H.bullets(s, [
    "[1] C. R. Qi, H. Su, K. Mo, L. J. Guibas, PointNet: Deep learning on point sets for 3D classification and segmentation, CVPR 2017.",
    "[2] C. R. Qi, L. Yi, H. Su, L. J. Guibas, PointNet++: Deep hierarchical feature learning on point sets in a metric space, NeurIPS 2017.",
    "[3] F. Li, K. Fujiwara, F. Okura, Y. Matsushita, A closer look at rotation-invariant deep point cloud analysis, ICCV 2021.",
    "[4] PaRI-Conv: The devil is in the pose: ambiguity-free 3D rotation-invariant learning via pose-aware convolution, arXiv:2205.15210 (2022).",
    "[5] J. Ren, L. Pan, Z. Liu, Benchmarking and analyzing point cloud classification under corruptions, ICML 2022 (arXiv:2202.03377).",
    "[6] R. Osada, T. Funkhouser, B. Chazelle, D. Dobkin, Shape distributions, ACM Trans. Graphics 21(4), 2002.",
  ], { x: 0.6, y: 1.5, w: 12.1, h: 5.3, fontSize: 15 });

  s = H.slide("References, part two.");
  H.title(s, "References (2/2)");
  H.bullets(s, [
    "[7] L. Breiman, Random forests, Machine Learning 45(1), 2001.",
    "[8] C. Cortes, V. Vapnik, Support-vector networks, Machine Learning 20(3), 1995.",
    "[9] A. N. Angelopoulos, S. Bates, A gentle introduction to conformal prediction and distribution-free uncertainty quantification, arXiv:2107.07511 (2021).",
    "[10] E. Akeweje et al., High-throughput unsupervised profiling of the morphology of 316L powder particles for use in additive manufacturing, arXiv:2512.06012 (2025).",
    "[11] N. N. Vlassis, W. Sun, K. A. Alshibli, R. A. Regueiro, Real and synthetic 3D models of F50 sand grains, Mendeley Data, v1 (2024), doi:10.17632/fh8h4859nh.1.",
    "[12] D. P. Kingma, J. Ba, Adam: A method for stochastic optimization, ICLR 2015.",
    "[13] F. Pedregosa et al., Scikit-learn: Machine learning in Python, JMLR 12, 2011.",
  ], { x: 0.6, y: 1.5, w: 12.1, h: 5.3, fontSize: 15 });
  H.src(s, "Check each reference against the original source before submission.");

  s = H.slide("Thank you. I am happy to take questions. Before the questions, a short live demonstration of the code is in the video: generating particles, evaluating on a corrupted set, and producing a conformal set.", true);
  s.addText("Thank you", { x: 0.8, y: 2.2, w: 11.7, h: 1.4, fontFace: "Cambria", fontSize: 64, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
  s.addText("Questions?", { x: 0.8, y: 3.8, w: 11.7, h: 0.9, fontSize: 28, color: "F2C777", margin: 0, isTextBox: true });
  s.addText("Virender   |   Enrolment No. 24324027", { x: 0.8, y: 5.4, w: 11.7, h: 0.5, fontSize: 18, color: "BFE0DC", margin: 0, isTextBox: true });
};
