"""Quick live demo for the video (about 1-2 minutes, CPU only).
Loads the sample data, computes the 24 rotation-invariant features, trains a Random Forest on the
training particles, tests on held-out test particles, prints accuracy, macro-F1 and the confusion matrix.
Usage: python3 code/demo_live.py   (run from the Project55_Submission folder)"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from baselines import features
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
root = "data_large" if os.path.exists("data_large/training data/train.npz") else "data_large_sample"
tr = np.load(f"{root}/training data/train.npz"); te = np.load(f"{root}/testing data/test.npz")
n_tr, n_te = min(len(tr["labels"]), 3000), min(len(te["labels"]), 1000)
print(f"data: {root}; train {n_tr}, test {n_te} particles")
F = lambda z, n: np.nan_to_num(np.stack([features(p.astype(np.float32)) for p in z["points"][:n]]))
Xtr, Xte = F(tr, n_tr), F(te, n_te); ytr, yte = tr["labels"][:n_tr], te["labels"][:n_te]
rf = RandomForestClassifier(300, random_state=0, n_jobs=2).fit(Xtr, ytr); p = rf.predict(Xte)
print("accuracy", round(accuracy_score(yte, p), 4), " macro-F1", round(f1_score(yte, p, average="macro"), 4))
print("classes: rounded, elongated, platy, angular, irregular\n", confusion_matrix(yte, p))
