"""
Project 55 - PointNet in pure NumPy (fallback used because PyTorch could not be installed
in the build environment). Same architecture idea as PointNet: a per-point shared MLP
(3-64-128-256, ReLU) -> symmetric max-pool over points -> FC head (256-128-5).
Differences from the original paper: no input/feature T-Nets, no batch-norm, no dropout.
Rotation robustness is learned through random-rotation augmentation instead.
Manual backprop + Adam. Outputs the same files as pointnet_train.py.
"""
import argparse, json, os, time
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CLASS_NAMES = ["rounded", "elongated", "platy", "angular", "irregular"]
DIMS = [3, 64, 128, 256]


def load(split, folder):
    z = np.load(os.path.join("data", folder, f"{split}.npz"))
    return z["points"].astype(np.float32), z["labels"]


def init(rng):
    P = {}
    sizes = [(3, 64), (64, 128), (128, 256), (256, 128), (128, 5)]
    for i, (a, b) in enumerate(sizes, 1):
        P[f"W{i}"] = (rng.normal(size=(a, b)) * np.sqrt(2.0 / a)).astype(np.float32)
        P[f"b{i}"] = np.zeros(b, np.float32)
    return P


def forward(P, X, cache=False):
    B, N, _ = X.shape
    x = X.reshape(B * N, 3)
    h1 = np.maximum(x @ P["W1"] + P["b1"], 0)
    h2 = np.maximum(h1 @ P["W2"] + P["b2"], 0)
    h3 = np.maximum(h2 @ P["W3"] + P["b3"], 0)
    h3r = h3.reshape(B, N, -1)
    arg = h3r.argmax(1)                     # B,256
    g = np.take_along_axis(h3r, arg[:, None, :], 1)[:, 0, :]
    f = np.maximum(g @ P["W4"] + P["b4"], 0)
    logits = f @ P["W5"] + P["b5"]
    if cache:
        return logits, (x, h1, h2, h3, arg, g, f)
    return logits


def backward(P, cache, logits, y):
    x, h1, h2, h3, arg, g, f = cache
    B = len(y)
    N = h3.shape[0] // B
    p = np.exp(logits - logits.max(1, keepdims=True)); p /= p.sum(1, keepdims=True)
    loss = -np.log(p[np.arange(B), y] + 1e-9).mean()
    d = p.copy(); d[np.arange(B), y] -= 1; d /= B
    G = {}
    G["W5"] = f.T @ d; G["b5"] = d.sum(0)
    df = (d @ P["W5"].T) * (f > 0)
    G["W4"] = g.T @ df; G["b4"] = df.sum(0)
    dg = df @ P["W4"].T                      # B,256
    dh3 = np.zeros((B, N, dg.shape[1]), np.float32)
    bi = np.arange(B)[:, None]; ci = np.arange(dg.shape[1])[None, :]
    dh3[bi, arg, ci] = dg
    dh3 = dh3.reshape(B * N, -1) * (h3 > 0)
    G["W3"] = h2.T @ dh3; G["b3"] = dh3.sum(0)
    dh2 = (dh3 @ P["W3"].T) * (h2 > 0)
    G["W2"] = h1.T @ dh2; G["b2"] = dh2.sum(0)
    dh1 = (dh2 @ P["W2"].T) * (h1 > 0)
    G["W1"] = x.T @ dh1; G["b1"] = dh1.sum(0)
    return loss, G


def rand_rot(B, rng):
    q, r = np.linalg.qr(rng.normal(size=(B, 3, 3)))
    q = q * np.sign(np.diagonal(r, axis1=1, axis2=2))[:, None, :]
    return q.astype(np.float32)


def predict(P, X, npts, bs=200):
    out = []
    for i in range(0, len(X), bs):
        out.append(forward(P, X[i:i + bs, :npts]).argmax(1))
    return np.concatenate(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--npts", type=int, default=512)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    os.makedirs("results", exist_ok=True)
    Xtr, ytr = load("train", "training data")
    Xva, yva = load("val", "training data")
    Xte, yte = load("test", "testing data")

    P = init(rng)
    m = {k: np.zeros_like(v) for k, v in P.items()}
    v = {k: np.zeros_like(x) for k, x in P.items()}
    t = 0
    best, bestP = -1, None
    hist = dict(train_loss=[], val_acc=[])
    steps_per_ep = len(Xtr) // a.bs
    total = steps_per_ep * a.epochs
    for ep in range(a.epochs):
        t0 = time.time()
        perm = rng.permutation(len(Xtr))
        tot = 0.0
        for i in range(steps_per_ep):
            idx = perm[i * a.bs:(i + 1) * a.bs]
            pts = np.stack([Xtr[j][rng.choice(1024, a.npts, replace=False)] for j in idx])
            pts = np.einsum("bnk,bjk->bnj", pts, rand_rot(len(idx), rng))
            pts = pts + 0.005 * rng.normal(size=pts.shape).astype(np.float32)
            logits, cache = forward(P, pts, cache=True)
            loss, G = backward(P, cache, logits, ytr[idx])
            tot += loss
            t += 1
            lr = a.lr * 0.5 * (1 + np.cos(np.pi * t / total))
            for k in P:
                m[k] = 0.9 * m[k] + 0.1 * G[k]
                v[k] = 0.999 * v[k] + 0.001 * G[k] ** 2
                mh = m[k] / (1 - 0.9 ** t); vh = v[k] / (1 - 0.999 ** t)
                P[k] -= (lr * mh / (np.sqrt(vh) + 1e-8)).astype(np.float32)
        va = accuracy_score(yva, predict(P, Xva, a.npts))
        hist["train_loss"].append(float(tot / steps_per_ep)); hist["val_acc"].append(float(va))
        if va > best:
            best = va; bestP = {k: x.copy() for k, x in P.items()}
        print(f"epoch {ep+1:3d}/{a.epochs} loss {tot/steps_per_ep:.4f} val_acc {va:.4f} ({time.time()-t0:.0f}s)", flush=True)

    P = bestP
    np.savez("results/pointnet_numpy_weights.npz", **P)
    pred = predict(P, Xte, a.npts)
    cm = confusion_matrix(yte, pred)
    metrics = dict(implementation="NumPy PointNet (no T-Net/BN)", best_val_accuracy=float(best),
                   test_accuracy=float(accuracy_score(yte, pred)),
                   test_macro_f1=float(f1_score(yte, pred, average="macro")),
                   test_accuracy_1024pts=float(accuracy_score(yte, predict(P, Xte, 1024))),
                   confusion_matrix=cm.tolist(), epochs=a.epochs, history=hist)
    json.dump(metrics, open("results/pointnet_metrics.json", "w"), indent=2)
    print({k: x for k, x in metrics.items() if k not in ("confusion_matrix", "history")})

    fig, ax = plt.subplots(figsize=(5, 4.5))
    cmn = cm / cm.sum(1, keepdims=True)
    ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(5)); ax.set_xticklabels(CLASS_NAMES, rotation=40, ha="right")
    ax.set_yticks(range(5)); ax.set_yticklabels(CLASS_NAMES)
    for r in range(5):
        for c in range(5):
            ax.text(c, r, cm[r, c], ha="center", va="center",
                    color="white" if cmn[r, c] > 0.5 else "black", fontsize=8)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title("PointNet (test)")
    fig.tight_layout(); fig.savefig("results/cm_PointNet.png", dpi=160); plt.close(fig)
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.5))
    ax[0].plot(hist["train_loss"]); ax[0].set_title("Training loss"); ax[0].set_xlabel("epoch")
    ax[1].plot(hist["val_acc"]); ax[1].set_title("Validation accuracy"); ax[1].set_xlabel("epoch")
    fig.tight_layout(); fig.savefig("results/pointnet_curves.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
