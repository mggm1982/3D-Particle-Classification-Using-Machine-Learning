const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType, AlignmentType,
  SectionType, BorderStyle, ShadingType, VerticalAlign } = require("docx");

const S = JSON.parse(fs.readFileSync("results/summary.json"));
const SY = S.systems, C = S.conformal, B = S.bootstrap;
const MAINN = "CF-PointNet-A (aug, 24 feats) TTA", CRN = "CF-PointNet-R (aug, 18 feats) TTA";
const sys = (n) => SY[n];
const f1 = (x) => (x == null ? "n/a" : Number(x).toFixed(1));
const f2 = (x) => (x == null ? "n/a" : Number(x).toFixed(2));
const sg = (x) => (x >= 0 ? "+" : "") + Number(x).toFixed(1);
const M = sys(MAINN), RFa = sys("RF (aug, 24 feats)"), RFc = sys("RF (clean, 24 feats)"), SVc = sys("SVM (clean, 24 feats)");
const PNa = sys("PointNet (aug)"), PPa = sys("PCA-PointNet (aug) TTA"), CFc = sys("CF-PointNet (clean, 24 feats) TTA"), CRa = sys(CRN);
const bs = (k, g) => { const r = B[k]; return r ? `${sg(r[g].diff)} [${sg(r[g].lo)}, ${sg(r[g].hi)}]` : "n/a"; };
const excl0 = (k, g) => { const r = B[k]; return r ? (r[g].lo > 0 || r[g].hi < 0) : false; };

const FONT = "Times New Roman";
const T = (text, o = {}) => new TextRun({ text, font: FONT, size: 20, ...o });
const body = (runs) => new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 100, line: 240 }, indent: { firstLine: 200 }, children: typeof runs === "string" ? [T(runs)] : runs });
const h1 = (t) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 160, after: 80 }, keepNext: true, children: [T(t.toUpperCase(), { size: 18 })] });
const h2 = (t) => new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 80, after: 60 }, keepNext: true, children: [T(t, { italics: true })] });
const caption = (t, keep) => new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120 }, keepNext: !!keep, children: [T(t, { size: 16 })] });
const png = (p) => { const b = fs.readFileSync(p); return [b.readUInt32BE(16), b.readUInt32BE(20), b]; };
const img = (path, wPx) => { const [w, h, data] = png(path); return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 40 }, keepNext: true,
  children: [new ImageRun({ type: "png", data, transformation: { width: wPx, height: Math.round(wPx * h / w) }, altText: { title: path, description: path, name: path } })] }); };
const ref = (n, t) => new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 50 }, indent: { left: 360, hanging: 360 }, children: [T(`[${n}]  ${t}`, { size: 16 })] });

const bd = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const borders = { top: bd, bottom: bd, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } };
function mkTable(header, rows, cw, boldRows = []) {
  const cell = (t, i, bold, shade) => new TableCell({ width: { size: cw[i], type: WidthType.DXA }, borders, verticalAlign: VerticalAlign.CENTER,
    margins: { top: 25, bottom: 25, left: 50, right: 50 }, shading: shade ? { type: ShadingType.CLEAR, fill: "EDEDED", color: "auto" } : undefined,
    children: [new Paragraph({ alignment: i ? AlignmentType.CENTER : AlignmentType.LEFT, children: [T(String(t), { size: 15, bold })] })] });
  const row = (a, bold, shade) => new TableRow({ children: a.map((t, i) => cell(t, i, bold, shade)) });
  return new Table({ width: { size: cw.reduce((a, b) => a + b, 0), type: WidthType.DXA }, columnWidths: cw,
    rows: [row(header, true, true), ...rows.map((r, i) => row(r, boldRows.includes(i), false))] });
}
const gap = new Paragraph({ spacing: { after: 100 }, children: [] });

// Table I
const t1names = [["RF (clean)", "RF (clean, 24 feats)"], ["SVM (clean)", "SVM (clean, 24 feats)"], ["PointNet (clean)", "PointNet (clean, rot-aug)"],
  ["CF-PointNet (clean)", "CF-PointNet (clean, 24 feats) TTA"], ["RF (aug)", "RF (aug, 24 feats)"], ["PointNet (aug)", "PointNet (aug)"],
  ["PCA-PointNet (aug)", "PCA-PointNet (aug) TTA"], ["CF-PointNet-R (aug)", CRN], ["CF-PointNet-A (aug)", MAINN]];
const t1rows = t1names.filter(([, k]) => SY[k]).map(([d, k]) => [d, f1(SY[k].clean), f1(SY[k].mca), f1(SY[k].mild), f1(SY[k].strong), f1(SY[k].worst)]);
const t1 = mkTable(["Model", "Clean", "Mean corr.", "Mild", "Strong", "Worst"], t1rows, [1560, 620, 800, 620, 640, 620], [t1rows.length - 1]);

// Table II conformal
const cm = C["cfa_aug_s0|tta"];
const sets2 = ["clean", "noise2", "sparse2", "zblur2", "occlusion2", "voxel2"];
const t2rows = cm ? sets2.map((s) => [s, f1(100 * cm.clean_cal[s].coverage), f1(100 * cm.mix_cal[s].coverage), f1(100 * cm.mix_cal[s].auto_accept),
  cm.mix_cal[s].acc_when_accepted == null ? "n/a" : f1(100 * cm.mix_cal[s].acc_when_accepted)]) : [];
const t2 = mkTable(["Test set", "Cov. clean-cal", "Cov. mix-cal", "Auto-accept", "Acc. accepted"], t2rows, [1000, 820, 820, 820, 860]);

// Table III bootstrap
const bk = [["cfa_aug_s0|tta - RandomForest_aug", "vs RF (aug)"], ["cfa_aug_s0|tta - rot_aug_s0|plain", "vs PointNet (aug)"], ["cfa_aug_s0|tta - pca_aug_s0|tta", "vs PCA-PointNet (aug)"],
  ["cfa_aug_s0|tta - cfr_aug_s0|tta", "vs 18-feature CF-R"], ["cfa_aug_s0|tta - cfa_aug_s0|single", "TTA vs single pose"], ["cfa_aug_s0|tta - cfa_nosign_s0|tta", "vs no sign-aug"], ["cfa_aug_s0|tta - cf_s0|tta", "vs clean-trained CF"]];
const t3rows = bk.filter(([k]) => B[k]).map(([k, d]) => [d, bs(k, "clean"), bs(k, "corrupted_mean")]);
const t3 = mkTable(["Main model minus ...", "Clean (pts)", "Mean corrupted (pts)"], t3rows, [1500, 1500, 1560]);

const ttaTxt = B["cfa_aug_s0|tta - cfa_aug_s0|single"] ? ((B["cfa_aug_s0|tta - cfa_aug_s0|single"].corrupted_mean.lo > 0.5)
  ? `a small gain (${bs("cfa_aug_s0|tta - cfa_aug_s0|single", "corrupted_mean")} points)` : `a negligible gain, practically zero (${bs("cfa_aug_s0|tta - cfa_aug_s0|single", "corrupted_mean")} points)`) : "n/a";
const ppTxt = B["pca_aug_s0|tta - pca_aug_s0|single"] ? bs("pca_aug_s0|tta - pca_aug_s0|single", "corrupted_mean") : "n/a";
const seedTxt = M.n_seeds > 1 ? `Over ${M.n_seeds} training seeds the main model has mean corrupted accuracy ${f1(M.mca)} ± ${f1(M.mca_sd)} (s.d.), so the ranking against the point-only networks is far larger than seed noise, while gaps of a few tenths of a point should not be interpreted.` : "Only one training seed was run, so seed-to-seed variation is unknown.";

const title = [
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 }, children: [T("Corruption-Aware Fusion of PCA-Canonical PointNet and Shape Descriptors, with Conformal Abstention, for 3D Particle Classification under CT-Style Artifacts", { size: 40 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: [T("Virender", { size: 22 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 }, children: [T("Enrolment No. 24324027, email: talaniyavirender@gmail.com", { size: 18, italics: true })] }),
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 100 }, indent: { left: 360, right: 360 }, children: [
    T("Abstract", { bold: true, italics: true, size: 18 }),
    T(`—Automatic shape classification of micro-CT particles is easy on clean data and fragile under scanner artifacts. We build a seeded synthetic benchmark of 40,000 particle point clouds in five morphology classes, together with ParticleCT-C, a set of ten corrupted test sets (noise, sparsity, z-blur, occlusion, voxelisation at two severities). Clean-trained Random Forest, SVM and PointNet-style models reach ${f1(RFc.clean)}–${f1(SVc.clean)}% on clean data (feature models) but fall to ${f1(RFc.mca)}% mean accuracy on corrupted sets. Training with corrupted copies and fusing a PCA-canonical point branch with 24 rotation-invariant shape descriptors (CF-PointNet-A) gives ${f1(M.clean)}% clean and ${f1(M.mca)}% mean corrupted accuracy, against ${f1(RFa.clean)}% and ${f1(RFa.mca)}% for a corruption-trained Random Forest and ${f1(PNa.clean)}% and ${f1(PNa.mca)}% for a corruption-trained PointNet. A hypothesised robust 18-feature subset did not help. Split conformal prediction calibrated on mixed corruptions restores most of the nominal 90% coverage that clean calibration loses under shift. All results are on synthetic data; real-scan validation remains open.`, { bold: true, italics: true, size: 18 })] }),
  new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120 }, indent: { left: 360, right: 360 }, children: [T("Index Terms", { bold: true, italics: true, size: 18 }),
    T("—particle morphology, point cloud classification, PointNet, robustness to corruptions, PCA canonical pose, conformal prediction, micro-CT.", { bold: true, italics: true, size: 18 })] }),
];

const content = [
  h1("I. Introduction"),
  body("The shape of powder grains, sand and catalyst particles affects packing, flowability, permeability and strength. Micro-computed tomography (micro-CT) records each grain in 3D, but grading thousands of grains by eye is slow and observer dependent. Automatic classifiers can do this at scale, yet a model that is accurate on clean reconstructions may fail when the scanner adds noise, has low resolution, produces blur along the rotation axis, or loses part of a grain."),
  body("This paper makes the following contributions, all on synthetic data: (1) a seeded 40,000-particle benchmark with exact five-class labels; (2) ParticleCT-C, ten corrupted test sets derived from five CT-style corruption families; (3) a controlled comparison of Random Forest, SVM, PointNet, PCA-canonical PointNet and a fused network, each trained clean or with corrupted copies; (4) a measurement showing that the PCA canonical pose is stable under exact rotation but unstable under resampling, which motivates four-pose training and averaging; (5) evidence that a robust-feature subset hypothesis was false once models are trained with corruptions; and (6) an evaluation of split conformal abstention under shift with clean versus mixed-corruption calibration."),
  body("We stress what is not claimed. The ingredients (PointNet, PCA alignment, corruption augmentation, conformal prediction, shape descriptors) are known. The corruptions are simplified imitations of CT artifacts, not physics-based reconstructions, and no real scan is used."),

  h1("II. Problem and Objectives"),
  body("Given the surface points of one particle, predict one of five classes (rounded, elongated, platy, angular, irregular) regardless of orientation and size, and decide whether the prediction is reliable enough to accept automatically. The research questions are: RQ1, how much accuracy do clean-trained models lose under CT-style corruption; RQ2, how much does corruption-aware training recover and does a subset of robust features help; RQ3, does averaging over canonical sign poses help; RQ4, does conformal prediction keep its coverage under shift, and does calibrating on corrupted data help."),

  h1("III. Theory"),
  h2("A. Rotation-invariant descriptors"),
  body("Twenty-four numbers are computed per particle: eigenvalues of the point covariance (principal component analysis) and the elongation and flatness ratios; statistics of the normalised radial distance; convex-hull volume, area, compactness 36πV²/A³, a solidity proxy, facet count and facet-normal variance; and the D2 shape distribution of random point-pair distances [6]. Random Forests [7] and RBF support vector machines [8] are trained on them."),
  h2("B. PointNet and canonical pose"),
  body("PointNet [1] applies a shared per-point function, aggregates with a symmetric max, and classifies, f(P) = g(max_i h(p_i)), which makes it invariant to point order but not to rotation. One remedy is to rotate each cloud into a PCA frame. The frame is defined up to the signs of the axes, and the sign is often fixed from the third moment along each axis; for near-symmetric particles this moment is close to zero and the sign is decided by noise, a known pose ambiguity [3], [4]. We therefore keep the four proper (determinant +1) sign poses, train on all of them and average the class probabilities over them at test time."),
  h2("C. Split conformal prediction"),
  body("Given a calibration set with exchangeable data, the threshold q is the ⌈(n+1)(1−α)⌉-th smallest of the scores s_i = 1 − p(y_i | x_i). The prediction set for a new particle contains every class with p ≥ 1 − q, and covers the true class with probability at least 1 − α marginally [5]. Particles whose set has exactly one class are accepted automatically; others (including empty sets) are sent to review. Coverage is guaranteed only if calibration and test data are exchangeable, which a scanner shift breaks."),

  h1("IV. Previous Work"),
  body("PointNet [1] and PointNet++ [2] learn directly from point sets. Rotation-invariant point networks that align clouds with PCA face sign and axis ambiguity; Li et al. [3] analyse it and select among candidate poses, and pose-aware convolution [4] avoids the ambiguity by construction. ModelNet-C [9] benchmarks point-cloud classifiers under corruptions such as noise, density change and occlusion, and finds that standard architectures differ widely in robustness; our ParticleCT-C follows this idea for particles with CT-motivated corruptions. Conformal prediction [5] gives distribution-free prediction sets and is used here for abstention. For particulate materials, Akeweje et al. [10] profile powder particle morphology, and open data such as the F50 sand-grain dataset [11] provide real and synthetic 3D grains. We did not find a study that combines these elements on this problem, but a systematic prior-art search has not been done, so no novelty claim is made."),

  h1("V. Method"),
  h2("A. Synthetic benchmark"),
  body("Each particle is generated by code with a seed. Rounded particles are near-spherical ellipsoids; elongated are prolate; platy are oblate; angular are random convex hulls; irregular are ellipsoids with a random radial perturbation field. Parameter ranges overlap on purpose. Each cloud has 1,024 surface points, is centred, scaled to the unit sphere, randomly rotated and given Gaussian noise. The split is by particle: 28,000 training, 4,000 validation, 4,000 calibration and 4,000 test particles, stratified by class."),
  img("figs/corruption_gallery.png", 330),
  caption("Fig. 1. One test particle under the clean condition and the ten ParticleCT-C corruptions."),
  h2("B. ParticleCT-C corruptions"),
  body("Five families at two severities, applied to the test clouds: additive noise; sparsity (few points); z-blur (smoothing along one axis, imitating cone-beam blur); occlusion (a cap or slab removed); and voxelisation (coordinates snapped to a grid). Test corruptions use seeds not seen in training. Inputs are 256 points (fewer for the sparse sets)."),
  h2("C. Models"),
  body("PointNet uses a shared MLP 3–64–128–256, max pooling and a 256–128–5 head. It is implemented from scratch in NumPy with manual back-propagation, since no deep-learning framework could be installed in the build environment; it has no alignment network, batch normalisation or dropout, about 85 thousand parameters and 20 epochs, so it is a deliberately small model. PCA-PointNet feeds the cloud in the PCA frame with sign-pose augmentation and four-pose averaging. CF-PointNet adds a feature branch: the 24 descriptors, standardised, pass through a 24–64 dense layer and are concatenated with the 256-dimensional pooled vector (320 dimensions) before a 128–5 head. CF-PointNet-A uses all 24 descriptors; CF-PointNet-R uses an 18-feature subset without the hull-derived descriptors that we found to be most sensitive to noise."),
  img("figs/architecture.png", 330),
  caption("Fig. 2. CF-PointNet architecture."),
  h2("D. Training regimes and evaluation"),
  body("In the clean regime models see only clean training particles. In the corruption-aware regime each training particle is accompanied by two corrupted copies drawn from the five families with continuous severity, and 75% of sampled training items are corrupted. Random Forest and SVM variants use the same corrupted bank. Models are selected on validation accuracy. We report accuracy and macro-F1 on the clean test set and on ParticleCT-C, with paired bootstrap 95% intervals over the 4,000 test particles. Conformal sets use α = 0.1, with a clean calibration set or a mixed-corruption calibration set of mild severity."),

  h1("VI. Results"),
  h2("A. Clean-trained models are brittle (RQ1)"),
  body(`On clean test data the Random Forest and SVM reach ${f1(RFc.clean)}% and ${f1(SVc.clean)}%. On the ten corrupted sets the Random Forest averages ${f1(RFc.mca)}% and the SVM ${f1(SVc.mca)}% (Table I), a loss of about ${Math.round(RFc.clean - RFc.mca)} points. The clean-trained fused network scores ${f1(CFc.clean)}% on clean data but ${f1(CFc.mca)}% on corrupted data.`),
  caption("TABLE I. Accuracy (%) on the clean test set and on the ten ParticleCT-C sets (mean, mean over mild sets, mean over strong sets, worst set).", true),
  t1, gap,
  img("figs/clean_vs_corrupt.png", 330),
  caption("Fig. 3. Clean versus mean corrupted accuracy by model and training regime."),
  h2("B. Corruption-aware training and fusion (RQ2)"),
  body(`Training with corrupted copies lifts the Random Forest to ${f1(RFa.mca)}% and PointNet to ${f1(PNa.mca)}%. The proposed fused network CF-PointNet-A reaches ${f1(M.clean)}% clean and ${f1(M.mca)}% mean corrupted accuracy, with a worst-set accuracy of ${f1(M.worst)}%. Its margin over the corruption-trained Random Forest is ${bs("cfa_aug_s0|tta - RandomForest_aug", "corrupted_mean")} points on corrupted data and ${bs("cfa_aug_s0|tta - RandomForest_aug", "clean")} on clean data (95% bootstrap interval in brackets; Table III). ${seedTxt}`),
  body(`The 18-feature subset, chosen because the dropped hull features changed most under noise, was worse after corruption-aware training: ${f1(CRa.clean)}% clean and ${f1(CRa.mca)}% corrupted for CF-PointNet-R, against ${f1(M.clean)}% and ${f1(M.mca)}% for CF-PointNet-A. Hull features are fragile for clean-trained models but informative for models that have seen corruptions, so this hypothesis is refuted. The dominant factor is the training regime, not the feature choice.`),
  img("figs/family_curves.png", 330),
  caption("Fig. 4. Accuracy by corruption family and severity."),
  caption("TABLE III. Paired bootstrap differences in accuracy (percentage points, 95% interval).", true),
  t3, gap,
  h2("C. Sign poses (RQ3)"),
  body(`Resampling 256 points from the same particle changes the PCA canonical pose in roughly two thirds of particles, although an exact rotation never does, so the pose is fragile in practice. Averaging over four sign poses gives ${ttaTxt} for the main model and ${ppTxt} points for the point-only PCA network. Training without sign augmentation scored ${f1(sys("CF-PointNet-A no sign-aug, TTA") ? sys("CF-PointNet-A no sign-aug, TTA").mca : null)}% mean corrupted accuracy (one seed), no worse than with it, so for the fused model neither sign augmentation nor four-pose averaging is supported by our data; they matter, if at all, for the point-only network. The fused model gets most of its rotation-invariant information from descriptors, which plausibly explains the small effect.`),
  img("figs/pose_ambiguity.png", 300),
  caption("Fig. 5. Share of particles whose canonical pose changes under resampling or corruption."),
  h2("D. Conformal abstention (RQ4)"),
  body(`With clean calibration, the main model covers the true class for ${cm ? f1(100 * cm.clean_cal.clean.coverage) : "n/a"}% of clean test particles but substantially fewer under strong corruption (Table II); the threshold calibrated on clean data is too optimistic once the input shifts. Calibrating on mixed mild corruptions raises coverage on every shifted set at the cost of more review; the sparsest set remains the hardest. The auto-accepted particles are classified more accurately than the average. A clean-trained model is different: its softmax is confidently wrong, so its sets contain one class and it never abstains, and mixed calibration only makes the sets contain all five classes. Calibration cannot repair a model that was never exposed to the shift.`),
  caption("TABLE II. Main model, α = 0.1: coverage with clean and mixed calibration, and mixed-calibration auto-accept rate and accuracy of accepted particles (%).", true),
  t2, gap,
  img("figs/conformal.png", 330),
  caption("Fig. 6. Coverage under shift with clean and mixed calibration."),

  h1("VII. Discussion"),
  body("The main finding is practical: for this synthetic benchmark, exposing the model to corruptions matters far more than the architecture, and a fused model that mixes learned point features with hand-made descriptors gives a modest, measurable additional gain. The negative results (the robust subset, and a small effect of pose averaging on the fused model) are reported because they refine the story: fragility of a feature depends on how the model is trained. Point-only networks lag the descriptor-based models here; plausible reasons are the small, short-trained NumPy network and the fact that hull and shape-distribution features supply global geometry that a shallow point network must learn from scratch. We did not test this explanation."),

  h1("VIII. Conclusion"),
  body(`On a 40,000-particle synthetic benchmark with CT-style corruptions, clean-trained classifiers lose roughly ${Math.round(RFc.clean - RFc.mca)} points, corruption-aware training recovers most of it, and a fused PCA-canonical PointNet with 24 descriptors reaches ${f1(M.mca)}% mean corrupted accuracy. Conformal abstention with corruption-aware calibration restores most of the nominal coverage. These are synthetic results and the protocol, not the numbers, is the transferable part.`),

  h1("IX. Limitations, Ethics and Reproducibility"),
  body("(1) All data are synthetic; real-scan accuracy is unknown. (2) The corruptions are simple imitations, not reconstruction physics, and training and test corruptions come from the same families, so generalisation to new artifact types is only partly tested (a hold-out-family run is reported in the supplementary results). (3) The PointNet is simplified and a full PointNet or PointNet++ may do better; the ranking should not be generalised. (4) One dataset seed and at most two training seeds. (5) Conformal guarantees are marginal and need exchangeability. (6) Class definitions and overlap were chosen by the author. Ethically, a model that appears accurate on clean data can pass defective batches under artifacts; abstention must route uncertain particles to a person, scanners need recalibration, and failures should be reported. Code and data regeneration scripts are provided to the instructor; no external code was used."),

  h1("References"),
  ref(1, "C. R. Qi, H. Su, K. Mo and L. J. Guibas, “PointNet: Deep learning on point sets for 3D classification and segmentation,” in Proc. IEEE CVPR, 2017, pp. 652–660."),
  ref(2, "C. R. Qi, L. Yi, H. Su and L. J. Guibas, “PointNet++: Deep hierarchical feature learning on point sets in a metric space,” in Adv. Neural Inf. Process. Syst., 2017."),
  ref(3, "F. Li, K. Fujiwara, F. Okura and Y. Matsushita, “A closer look at rotation-invariant deep point cloud analysis,” in Proc. IEEE/CVF ICCV, 2021."),
  ref(4, "R. Chen and Y. Cong, “The devil is in the pose: Ambiguity-free 3D rotation-invariant learning via pose-aware convolution,” arXiv:2205.15210, 2022."),
  ref(5, "A. N. Angelopoulos and S. Bates, “A gentle introduction to conformal prediction and distribution-free uncertainty quantification,” arXiv:2107.07511, 2021."),
  ref(6, "R. Osada, T. Funkhouser, B. Chazelle and D. Dobkin, “Shape distributions,” ACM Trans. Graph., vol. 21, no. 4, 2002."),
  ref(7, "L. Breiman, “Random forests,” Mach. Learn., vol. 45, no. 1, pp. 5–32, 2001."),
  ref(8, "C. Cortes and V. Vapnik, “Support-vector networks,” Mach. Learn., vol. 20, no. 3, pp. 273–297, 1995."),
  ref(9, "J. Ren, L. Pan and Z. Liu, “Benchmarking and analyzing point cloud classification under corruptions,” in Proc. ICML, 2022 (arXiv:2202.03377)."),
  ref(10, "E. Akeweje et al., “High-throughput unsupervised profiling of the morphology of 316L powder particles for use in additive manufacturing,” arXiv:2512.06012, 2025."),
  ref(11, "N. N. Vlassis, W. Sun, K. A. Alshibli and R. A. Regueiro, “Real and synthetic 3D models of F50 sand grains,” Mendeley Data, v1, 2024, doi:10.17632/fh8h4859nh.1."),
  ref(12, "D. P. Kingma and J. Ba, “Adam: A method for stochastic optimization,” in Proc. ICLR, 2015."),
  ref(13, "F. Pedregosa et al., “Scikit-learn: Machine learning in Python,” J. Mach. Learn. Res., vol. 12, pp. 2825–2830, 2011."),
];

const page = { size: { width: 12240, height: 15840 }, margin: { top: 1080, bottom: 1080, left: 900, right: 900 } };
const doc = new Document({ creator: "Virender", title: "Corruption-aware fusion for 3D particle classification",
  styles: { default: { document: { run: { font: FONT, size: 20 } } } },
  sections: [{ properties: { page }, children: title },
    { properties: { type: SectionType.CONTINUOUS, page, column: { count: 2, space: 360 } }, children: content }] });
Packer.toBuffer(doc).then((b) => { fs.writeFileSync("deliverables/Project55_Extended_IEEE_Article.docx", b); console.log("ok"); });
